require("./catozolala").module;
require("./catozolala").variable;
const {
	name,
	owner,
	message,
	groupOnly,
	linkGroupWhatsapp,
	public
} = require("./catozolala");
const config = require("./catozolala");
const {
	FirebaseUserManager,
	db
} = require("./lib/firebase.js");
const dbFire = new FirebaseUserManager();
const {
	checkPremiumUser
} = require("./lib/premium_feature");
const sendButtonImage = require("./lib/button_image.js");
const {
	sendUrl
} = require("./lib/button_send.js");
const {
	rimuruCatozolala
} = require("./source/catozolala_rimuru_ai");
const {
	drawWelcomeCard
} = require('catozolala-card-canvas');
const {
	smsg
} = require("./source/smsg");
const store = makeInMemoryStore({
	logger: pino().child({
		level: 'silent',
		stream: 'store'
	})
});

async function getGroupData(groupMetadata) {
	const groupId = dbFire.encodePath(groupMetadata.id);
	global.db.data.groups = global.db.data.groups || {};
	return global.db.data.groups[groupId] || null;
}

async function isCatozolala(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo.catozolala === true;
}

async function isPromosi(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo.antipromosi === true;
}

async function isLinkgc(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo.antilinkgc === true;
}

async function isAntilink(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo.antilink === true;
}

async function isWelcome(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo.welcome === true;
}

async function isNsfw(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo?.nsfw === true;
};

async function isBot(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo?.bot_public === true;
};

async function isAntibot(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo?.antibot === true;
};

async function isAntipromosi(groupMetadata) {
	const groupInfo = await getGroupData(groupMetadata);
	if (!groupInfo) return false
	return groupInfo?.antipromosi === true;
};

const pluginDir = path.resolve(__dirname, './plugins');
const commandMap = new Map();
let plugins = [];

function loadSinglePlugin(file) {
	const pluginPath = path.join(pluginDir, file);
	try {
		delete require.cache[require.resolve(pluginPath)];
		const loaded = require(pluginPath);

		if (Array.isArray(loaded.command)) {
			for (const cmd of loaded.command) {
				const cmdLower = cmd.toLowerCase();
				if (commandMap.has(cmdLower)) {
					console.warn(`[⚠️] Duplicate command detected: '${cmdLower}' in ${file}`);
				}
				commandMap.set(cmdLower, loaded);
			}
		}

		return loaded;
	} catch (err) {
		console.error(`[❌ Plugin Error] Failed to load ${file}:\n`, err);
		return null;
	}
}

module.exports.loadPlugins = function () {
	const pluginFiles = fs.readdirSync(pluginDir).filter(file => file.endsWith('.js'));
	plugins = [];
	commandMap.clear();

	for (const file of pluginFiles) {
		const plugin = loadSinglePlugin(file);
		if (plugin) plugins.push(plugin);
	}

	console.log(`[✅] Total plugins loaded (tanpa cache): ${plugins.length}`);
};

let watch = false;

fs.watch(pluginDir, (eventType, filename) => {
	if (!filename || !filename.endsWith('.js')) return;
	if (watch) return;
	watch = true;

	console.log(`[👀] Perubahan terdeteksi pada plugin: ${filename}`);

	setTimeout(() => {
		const pluginPath = path.join(pluginDir, filename);

		try {
			const oldPlugin = plugins.find(p => p.__filename === pluginPath);
			if (oldPlugin) {
				const toDelete = [...commandMap.entries()].filter(([, mod]) => mod === oldPlugin);
				toDelete.forEach(([cmd]) => commandMap.delete(cmd));
				plugins = plugins.filter(p => p !== oldPlugin);
			}

			if (fs.existsSync(pluginPath)) {
				const plugin = loadSinglePlugin(filename);
				if (plugin) {
					plugins.push(plugin);
					console.log(`[🔁] Plugin berhasil dimuat ulang: ${filename}`);
				}
			} else {
				console.log(`[❌] Plugin dihapus: ${filename}`);
			}
		} catch (e) {
			console.error(`[❌ Error saat reload plugin '${filename}']:`, e);
		} finally {
			setTimeout(() => {
				watch = false;
			}, 2000);
		}
	}, 2000);
});

const groupMetaCache = global.groupMetaCache ||= new Map()

async function getGroupMetadataSafe(chatId) {
  if (groupMetaCache.has(chatId)) return groupMetaCache.get(chatId)

  try {
    const metadata = await conn.groupMetadata(chatId)
    groupMetaCache.set(chatId, metadata)

    setTimeout(() => groupMetaCache.delete(chatId), 2 * 60 * 1000)

    return metadata
  } catch (e) {
    console.error('❌ Gagal ambil metadata grup:', e.message)
    return {}
  }
}

module.exports.messageUpsert = async function (catozolala) {
	try {
	
		if (!catozolala?.messages?.[0]?.message) return;
		let m = catozolala.messages?.[0];
		if (!m?.message) return;

		m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ?
			m.message.ephemeralMessage.message :
			m.message;

		if (m.key.remoteJid === 'status@broadcast') return conn.readMessages([m.key]);
		if (m.key.id.startsWith('BAE5') && m.key.id.length === 16) return; 
		const isOwner = (((m.key.remoteJid.endsWith('@g.us') ? m.key.participant : m.key.remoteJid) || '') === owner + '@s.whatsapp.net') || m.key.fromMe
		if (conn.public && !isOwner && catozolala.type === 'notify') return
        
		m = smsg(conn, m, store);
        
		const budy = (typeof m.text == 'string' ? m.text : '')
		const from = m.key.remoteJid;
		const body = (
			m.mtype === "conversation" ? m.message.conversation :
			m.mtype === "imageMessage" ? m.message.imageMessage.caption :
			m.mtype === "videoMessage" ? m.message.videoMessage.caption :
			m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
			m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
			m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
			m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
			m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id : m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
			m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
		) || '';
		const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
		const isCmd = typeof body === 'string' && body.startsWith(prefix);
		const args = typeof body === 'string' ? body.trim().split(/ +/).slice(1) : [];
		const command = typeof body === 'string' ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
		const cmd = prefix + command

		const text = q = args.join(" ");
		const isGroup = from.endsWith('@g.us');
		const botNumber = conn.user?.id || '';
		const sender = m.sender;
		const senderNumber = m.sender.split('@')[0]
		const pushname = m.pushName || `${senderNumber}`
		
		const groupMetadata = isGroup ? await getGroupMetadataSafe(from) : {}
		const participants = isGroup ? groupMetadata.participants : [];
		const groupAdmins = m.isGroup ? conn.getGroupAdmins(participants) : [];
		const isAdmins = m?.isGroup ? groupAdmins.includes(m?.sender) : false;
		const isBotAdmins = m?.isGroup ? groupAdmins.includes(botNumber.split(":")[0] + "@s.whatsapp.net") : false;

		const newowner = JSON.parse(fs.readFileSync('./database/owner.json'));
		const isCreator = [...(Array.isArray(newowner) ? newowner : [newowner]), ...owner]
			.map(v => String(v).replace(/[^0-9]/g, '') + '@s.whatsapp.net')
			.includes(m.sender);
		const fatkuns = (m.quoted || m)
		const quoted = (fatkuns.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m


		let premium = JSON.parse(fs.readFileSync('./database/premium.json'))
		const isPremium = checkPremiumUser(m.sender, premium)


		const defaultGroups = {
			catozolala: true,
			antipromosi: true,
			bot_public: false,
			antilinkgc: true,
			welcome: false,
			antilink: false,
			nsfw: false,
			antibot: false,
			antipromosi: false,
			antilink: false
		};

		if (isGroup) {
			if (!(await isBot(groupMetadata))) {
				if (!isCreator) return;
			}

			const groupId = groupMetadata.id;
			const safeId = dbFire.encodePath(groupId);
			const groupData = await getGroupData(groupMetadata);

			if (!groupData) {
				const newGroup = {
					id: groupMetadata.id,
					name: groupMetadata.subject,
					...defaultGroups
				};

				global.db.data.groups[safeId] = newGroup;
				await dbFire.tambah("groups", newGroup, safeId)
					.then(() => console.log(`✅ Grup disimpan: ${newGroup.name}`))
					.catch(err => console.error(`❌ Gagal simpan grup:`, err));
			} else {
				const missingKeys = Object.keys(defaultGroups).filter(key => !(key in groupData));

				if (missingKeys.length > 0) {
					const updatedData = {
						...groupData,
						...missingKeys.reduce((obj, key) => {
							obj[key] = defaultGroups[key];
							return obj;
						}, {})
					};

					global.db.data.groups[safeId] = updatedData;

					await dbFire.update("groups", updatedData, safeId)
						.then(() => console.log(`🔄 Grup diupdate properti baru: ${updatedData.name}`))
						.catch(err => console.error(`❌ Gagal update grup:`, err));
				}
			}
		}

		const newUser = {
			id: m.sender,
			name: pushname,
			limit: 2,
			total_command: 0,
			ban: false
		};

		const safeId = dbFire.encodePath(newUser.id);
		const path1 = `users/${safeId}`;

		const existingUser = await dbFire.baca(path1);
		if (!existingUser) {
			await dbFire.tambah("users", newUser, safeId);
		}

		const pluginContext = {
			conn: this,
			command,
			cmd,
			isCmd,
			isCatozolala,
			isPromosi,
			dbFire,
			isLinkgc,
			db,
			isWelcome,
			isNsfw,
			isCreator,
			isBot,
			text,
			config,
			store,
			args,
			botNumber,
			prefix,
			froms: from,
			groupMetadata,
			budy,
			isAntipromosi,
			quoted,
			isAntibot,
			isBotAdmins,
			isAdmins,
			from,
			body,
			pushname,
			participants,
			isAntilink,
			getGroupData
		};

		const targetPlugin = commandMap.get(command?.toLowerCase());
		const autoTriggers = plugins.filter(plugin =>
			(!plugin.command || !Array.isArray(plugin.command)) && typeof plugin === 'function'
		);

		Promise.all(autoTriggers.map(plugin => {
			plugin(m, pluginContext).catch(e => {
				let messageError = `[PLUGIN ERROR] Command '${command}\n\n${e}`.trim();

				this.sendMessage(owner + "@s.whatsapp.net", {
					text: messageError
				});
			});
		}));
		
	    if (budy.startsWith("<")) {
			try {
				if (!isCreator) return
				let evaled = await eval(text)
				if (typeof evaled !== 'string') evaled = util.inspect(evaled)
				this.sendMessage(m.chat, {
					text: util.format(evaled)
				}, {
					quoted: m
				})
			} catch (e) {
				this.sendMessage(m.chat, {
					text: util.format(e)
				}, {
					quoted: m
				})
			}
		}
		
		if (targetPlugin && typeof targetPlugin === "function") {
			try {

				if (!dbFire.isBan && !isCreator) return sendUrl(m, this, `https://wa.me/${owner}`, "Chat Owner", message.ban, "Hubungi Owner");

				if (targetPlugin.owner && !isCreator) {
					return m.reply(message.owner);
					
				} else if (targetPlugin.group && !m.isGroup) {
					return sendUrl(m, this, `https://wa.me/${owner}`, "Chat Owner", message.group + `\n\nGroup: ${linkGroupWhatsapp}`, "");
					
				} else if (targetPlugin.admin && !isAdmins && !isCreator) {
					return m.reply(message.admin);
					
				} else if (targetPlugin.botAdmin && !isBotAdmins && !isCreator) {
				    return m.reply(message.botAdmins);
				    
				} else if (targetPlugin.nsfw && !(await isNsfw(groupMetadata))) {
					return m.reply(message.nsfw);
					
				} else if (targetPlugin.limit) {
					const adaLimit = await dbFire.isLimit(m.sender);
					if (!adaLimit) {
						return sendUrl(
							m,
							this,
							`https://wa.me/${owner}`,
							"Chat Owner",
							message.limit,
							"Anda Telah Mencapai Limit"
						);
					}

					await dbFire.kurangiLimit(m.sender);
					
				} else if (targetPlugin.premium && !isPremium) {
					return m.reply(message.premium);
					
				} else if (targetPlugin.disable) {
					 return m.reply(message.plugin);
					
				}

			    targetPlugin(m, pluginContext).catch(e => { console.log(color("red") + "[ Target plugin eror ] ", e) })
				const addpush = require('./lib/top_features');
				addpush(m, {
					db,
					command,
					jumlahPemakai: 1
				});
				dbFire.addCommand(m.sender)
			} catch (e) {
				console.error(`[PLUGIN ERROR] Command '${command}':`, e);

				let messageError = `[PLUGIN ERROR] Command '${command}\n\n${e}`.trim();

				this.sendMessage(owner + "@s.whatsapp.net", {
					text: messageError
				});
			}
		} else if (isCmd) {}

		if (m.message && !m.fromMe) {
			const fromUser = m.quoted ?
				m.quoted.sender :
				text ?
				(text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) :
				false;

			const username = pushname || senderNumber;
			const messageText = m.body || body || m.text || m.mtype;
			const currentDate = new Date().toLocaleString();

			console.log(color("yellow") + "┌──────────────────────────────────────────" + color("reset"));
			console.log(color("yellow") + "│ " + color("black") + background("yellow") + "           NEW MESSAGE RECEIVED          " + color("reset"));
			console.log(color("yellow") + "├──────────────────────────────────────────" + color("reset"));
			console.log(color("yellow") + "│ " + color("cyan") + "Username : " + color("reset") + username);
			console.log(color("yellow") + "│ " + color("cyan") + "Number   : " + color("reset") + m.sender);
			console.log(color("yellow") + "│ " + color("cyan") + "From     : " + color("reset") + fromUser);
			console.log(color("yellow") + "│ " + color("cyan") + "Message  : " + color("reset") + messageText);
			console.log(color("yellow") + "│ " + color("cyan") + "Date     : " + color("reset") + currentDate);
			console.log(color("yellow") + "└──────────────────────────────────────────\n\n" + color("reset"));

		}

	} catch (err) {
		console.error('[ERROR]', err);
		let messageError = `
╭─❖ 「 *Error Report* 」
│⿻ *Waktu*      : ${waktu}
│⿻ *Event*      : Terjadi Error Saat Eksekusi
│⿻ *Message*    : ${err.message}
│⿻ *Name*       : ${err.name}
│⿻ *Lokasi*     : ${err.stack?.split("\\n")[1]?.trim() || "Tidak diketahui"}
│⿻ *Stack Trace*:
│${err.stack?.split("\n").slice(1).map(line => "│ " + line.trim()).join("\n") || "Tidak tersedia"}
╰─────────────────────
`.trim()

		this.sendMessage(owner + "@s.whatsapp.net", {
			text: messageError
		});
	}

}
    
module.exports.participantsUpdate = async function (catozolala) {
	try {
	    const conn = this;
		let metadata = await this.groupMetadata(catozolala.id)
		let namagc = await metadata.subject
		let participants = catozolala.participants
		let totalmember = await metadata.participants.length
		if (!(await isWelcome(catozolala))) return;
		const today = new Date();
		const formattedDate = today.toLocaleDateString('en-US', {
			month: 'short',
			day: 'numeric',
			year: 'numeric'
		});
		for (let rimuru of participants) {
			if (!rimuru) continue;

			let userJid = typeof rimuru === 'string' ? rimuru : rimuru.id || rimuru.jid;
			if (!userJid || typeof userJid !== 'string') continue;

			let check = catozolala?.author !== rimuru && catozolala?.author?.length > 1

			let tag = check ? [catozolala.author, rimuru] : [rimuru]
			let nameUser = await this.getName(rimuru)

			let ppGroup, ppUser;
			try {
				ppGroup = await this.profilePictureUrl(catozolala.id, 'image');
			} catch {
				ppGroup = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60';
			}
			try {
				ppUser = await this.profilePictureUrl(rimuru, 'image');
			} catch {
				ppUser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg';
			}
			
			if (catozolala.action == 'add') {

				let simplemenu = ''
				simplemenu += `┌──❖ Welcome @${rimuru.split("@")[0]}! 👋\n`
				simplemenu += `│✧ ${check ? `@${catozolala.author.split("@")[0]} Hes added @${rimuru.split("@")[0]}` : `Welcome to the group ${namagc}`}\n`
				simplemenu += `└────────────⳹`

				const user = nameUser.slice(0, 10);
				const buffer = await drawWelcomeCard({
					username: `${user}`,
					tag: `#${totalmember}`,
					avatarURL: ppUser,
					backgroundURL: 'https://i.ibb.co/Ccg2ctT/background.png',
					date: formattedDate
				});

			    this.sendMessage(catozolala.id, {
					image: buffer,
					caption: simplemenu,
					mentions: [...tag]
				});

			} else if (catozolala.action == 'remove') {

				let simplemenu = ''
				simplemenu += `┌──❖ Sayonara @${rimuru.split("@")[0]}! 🚨\n`
				simplemenu += `│✧ ${check ? `@${catozolala.author.split("@")[0]} Has removed @${rimuru.split("@")[0]}` : `Left the groups ${namagc}`}\n`
				simplemenu += `└────────────⳹`

				const user = nameUser.slice(0, 10);
				const buffer = await drawWelcomeCard({
					username: `${user}`,
					tag: `#${totalmember}`,
					avatarURL: ppUser,
					backgroundURL: 'https://i.ibb.co/Ccg2ctT/background.png',
					date: formattedDate,
					isOnline: false
				});

				this.sendMessage(catozolala.id, {
					image: buffer,
					caption: simplemenu,
					mentions: [...tag]
				});

			} else if (catozolala.action == "promote") {
						   
			   this.sendMessage(catozolala.id, {text: `@${catozolala.author.split("@")[0]} has promoted @${rimuru.split("@")[0]} an admin of this group`, mentions: [...tag]});

			} else if (catozolala.action == "demote") {
			
			   this.sendMessage(catozolala.id, {text: `@${catozolala.author.split("@")[0]} has demoted @${rimuru.split("@")[0]}`, mentions: [...tag]});
			   
			}

		}
	} catch (err) {
		console.log(err)
	}
}

module.exports.contactsUpdate = async function (update) {
	if (!update || !Array.isArray(update)) return;

	for (let contact of update) {
		try {
			let id = this.decodeJid?.(contact.id);
			if (!id) continue;

			if (store && store.contacts) {
				store.contacts[id] = {
					id,
					name: contact.notify || contact.name || contact.vname || ''
				};
			}
		} catch (err) {
			console.error('Error updating contact:', err);
		}
	}
};
	
module.exports.scheduleNextCheck = async function () {
	const usersRef = db.ref('users');
	const metaRef = db.ref('metadata/lastResetDate');

	setInterval(async () => {
		try {
			const now = moment().tz("Asia/Jakarta");
			const jam = now.format("HH:mm");
			const hariIni = now.format("YYYY-MM-DD");

			const snapshot = await metaRef.once('value');
			const lastResetDate = snapshot.val();

			if (jam === "23:00" && lastResetDate !== hariIni) {
				console.log(`[${now.format()}] Reset limit harian dijalankan...`);

				const usersSnapshot = await usersRef.once('value');
				const usersData = usersSnapshot.val();

				let updated = false;

				for (const userId in usersData) {
					const user = usersData[userId];
					if (user.limit >= 0 && user.limit < 3) {
						usersData[userId].limit = 3;
						updated = true;
					}
				}

				if (updated) {
					await usersRef.set(usersData);
					console.log("Limit user berhasil direset.");
				} else {
					console.log("Tidak ada user yang perlu direset limit.");
				}
				await metaRef.set(hariIni);
			}
		} catch (err) {
			console.error('Error saat reset limit harian:', err);
		}
	}, 60 * 1000);
}

module.exports.handeCommandMap = async function () {
  if (commandMap.size === 0) {
    console.warn("[⚠️] Command map kosong. Reload plugin...");
    await handlerReq.loadPlugins();
  }
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
