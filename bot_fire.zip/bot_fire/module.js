const {
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    useMultiFileAuthState,
    makeWASocket,
    jidDecode,
    getAggregateVotesInPollMessage,
    jidNormalizedUser,
    makeCacheableSignalKeyStore
} = require("baileys");

global.makeCacheableSignalKeyStore = makeCacheableSignalKeyStore
global.jidNormalizedUser = jidNormalizedUser
global.useMultiFileAuthState = useMultiFileAuthState
global.makeWASocket = makeWASocket
global.jidDecode = jidDecode
global.getAggregateVotesInPollMessage = getAggregateVotesInPollMessage
global.downloadContentFromMessage = downloadContentFromMessage;
global.emitGroupParticipantsUpdate = emitGroupParticipantsUpdate;
global.emitGroupUpdate = emitGroupUpdate;
global.generateWAMessageContent = generateWAMessageContent;
global.generateWAMessage = generateWAMessage;
global.makeInMemoryStore = makeInMemoryStore;
global.prepareWAMessageMedia = prepareWAMessageMedia;
global.generateWAMessageFromContent = generateWAMessageFromContent;
global.MediaType = MediaType;
global.areJidsSameUser = areJidsSameUser;
global.WAMessageStatus = WAMessageStatus;
global.downloadAndSaveMediaMessage = downloadAndSaveMediaMessage;
global.AuthenticationState = AuthenticationState;
global.GroupMetadata = GroupMetadata;
global.initInMemoryKeyStore = initInMemoryKeyStore;
global.getContentType = getContentType;
global.MiscMessageGenerationOptions = MiscMessageGenerationOptions;
global.useSingleFileAuthState = useSingleFileAuthState;
global.BufferJSON = BufferJSON;
global.WAMessageProto = WAMessageProto;
global.MessageOptions = MessageOptions;
global.WAFlag = WAFlag;
global.WANode = WANode;
global.WAMetric = WAMetric;
global.ChatModification = ChatModification;
global.MessageTypeProto = MessageTypeProto;
global.WALocationMessage = WALocationMessage;
global.ReconnectMode = ReconnectMode;
global.WAContextInfo = WAContextInfo;
global.proto = proto;
global.WAGroupMetadata = WAGroupMetadata;
global.ProxyAgent = ProxyAgent;
global.waChatKey = waChatKey;
global.MimetypeMap = MimetypeMap;
global.MediaPathMap = MediaPathMap;
global.WAContactMessage = WAContactMessage;
global.WAContactsArrayMessage = WAContactsArrayMessage;
global.WAGroupInviteMessage = WAGroupInviteMessage;
global.WATextMessage = WATextMessage;
global.WAMessageContent = WAMessageContent;
global.WAMessage = WAMessage;
global.BaileysError = BaileysError;
global.WA_MESSAGE_STATUS_TYPE = WA_MESSAGE_STATUS_TYPE;
global.MediaConnInfo = MediaConnInfo;
global.URL_REGEX = URL_REGEX;
global.WAUrlInfo = WAUrlInfo;
global.WA_DEFAULT_EPHEMERAL = WA_DEFAULT_EPHEMERAL;
global.WAMediaUpload = WAMediaUpload;
global.mentionedJid = mentionedJid;
global.processTime = processTime;
global.Browser = Browser;
global.MessageType = MessageType;
global.Presence = Presence;
global.WA_MESSAGE_STUB_TYPES = WA_MESSAGE_STUB_TYPES;
global.Mimetype = Mimetype;
global.relayWAMessage = relayWAMessage;
global.Browsers = Browsers;
global.GroupSettingChange = GroupSettingChange;
global.DisconnectReason = DisconnectReason;
global.WASocket = WASocket;
global.getStream = getStream;
global.WAProto = WAProto;
global.isBaileys = isBaileys;
global.AnyMessageContent = AnyMessageContent;
global.fetchLatestBaileysVersion = fetchLatestBaileysVersion;
global.templateMessage = templateMessage;
global.InteractiveMessage = InteractiveMessage;
global.Header = Header;


const fs = require('fs');
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})
