let before = async function(m, {
	conn,
	config
}) {
	if (m.id.startsWith('BAE5') || m.id.startsWith('3EB0') || m.fromMe) return
	if (/^\.?(afk)/i.test(m.text)) return
	
	global.db.data.users[m.sender] = global.db.data.users[m.sender] || {
		afk: -1,
		afkReason: ''
	}

	let user = global.db.data.users[m.sender]

	if (user.afk > -1) {
		
		await conn.sendAds(m.chat, {text: `
@${m.sender.split('@')[0]} berhenti AFK${user.afkReason ? ' setelah ' + user.afkReason : ''}
Selama ${msToTime(new Date() - user.afk)}
`.trim(), title:`Powered by ${config.name}`})

		user.afk = -1
		user.afkReason = ''
	}

	let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
	for (let jid of jids) {
		let users = global.db.data.users[jid]
		if (!users || !users.afk || users.afk < 0) continue
		
		await conn.sendAds(m.chat, {text: `
    Jangan tag dia!
    Dia sedang AFK ${users.afkReason ? 'dengan alasan ' + users.afkReason : 'tanpa alasan'}
    Selama ${msToTime(new Date() - users.afk)}
    `.trim(), title:`Powered by ${config.name}`})
	}
    	

	return !0
}

function msToTime(duration) {
	let seconds = Math.floor((duration / 1000) % 60)
	let minutes = Math.floor((duration / (1000 * 60)) % 60)
	let hours = Math.floor((duration / (1000 * 60 * 60)) % 24)
	let days = Math.floor(duration / (1000 * 60 * 60 * 24))

	return `${days ? days + ' hari, ' : ''}${hours} jam, ${minutes} menit, ${seconds} detik`
}

module.exports = before