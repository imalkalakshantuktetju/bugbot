const nameWithAi = "Catozolala";
const nameWithBot = "Catozolala";

const regexTutup = /\b(tutup|close)\s?(group|gc|grup|grop)\b/i;
const regexBuka = /\b(buka|open)\s?(group|gc|grup|grop)\b/i;
const regexSearch = /\b(cari|carikan|search|bantu\s+cari)\b/i;

module.exports = async (m, {
	conn,
	text,
	command,
	cmd,
	config,
	prefix,
	isBotAdmins,
	isAdmins,
	isCreator,
	groupMetadata,
	botNumber,
	senderNumber,
	nick,
	pushname,
	isCatozolala
}) => {

    if (m.id.startsWith('BAE5') || m.id.startsWith('3EB0') || m.fromMe) return
	if (botNumber.includes(senderNumber)) return;
	if (/^[.#/!]/.test(m.text)) return;

	const normalizeJid = jid => jid?.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
	let mentions = [],
		isBotMention = false;

	try {
		const ctx = m?.message?.extendedTextMessage?.contextInfo;
		const botJidRaw = conn?.user?.id || conn?.user?.jid || conn?.user;

		if (ctx?.mentionedJid?.length > 0) mentions = ctx.mentionedJid;
		if (ctx?.participant && !mentions.includes(ctx.participant)) mentions.push(ctx.participant);

		const normalizedMentions = mentions.map(normalizeJid);
		const normalizedBotJid = normalizeJid(botJidRaw);
		isBotMention = normalizedMentions.includes(normalizedBotJid);
	} catch (e) {
		console.error("Mention check error:", e);
	}

	const textLower = m.text.toLowerCase();
	const isTriggered = (
		isBotMention ||
		textLower.startsWith(nick?.toLowerCase()) ||
		regexTutup.test(textLower) ||
		regexBuka.test(textLower) ||
		regexSearch.test(textLower)
	);

	if ((await isCatozolala(groupMetadata)) && isTriggered) {
		if (m.isBaileys && m.fromMe) return;

		switch (true) {

			case regexTutup.test(textLower):
				if (!isBotAdmins) return m.reply(`${nameWithBot} bukan admin!`);
				if (!isAdmins && !isCreator) return m.reply(`Fitur ini hanya untuk admin grup.`);
				await conn.groupSettingUpdate(m.chat, 'announcement');
				m.reply(`Grup berhasil ditutup oleh ${nameWithBot}`);
			break;
			
			case regexBuka.test(textLower):
				if (!isBotAdmins) return m.reply(`${nameWithBot} bukan admin!`);
				if (!isAdmins && !isCreator) return m.reply(`Fitur ini hanya untuk admin grup.`);
				await conn.groupSettingUpdate(m.chat, 'not_announcement');
				m.reply(`Grup berhasil dibuka oleh ${nameWithBot}`);
			break;

			case regexSearch.test(textLower):
				 m.reply(`🔍 Apa yang ingin kamu cari? Ketik dengan format lengkap.\n\nContoh: *cari anime One Piece*`);
			break;
			
			default:
				break;
		}
	}
};