module.exports = async (m, { conn, groupMetadata, isCreator, isAntibot, isAdmins, isBotAdmins }) => {
    if (!m.isGroup) return;
    if (m.fromMe) return;
    if (isAdmins || isCreator) return;

    if ((m.id.startsWith("BAE5") || m.id.startsWith("3EB0")) &&
       !(m.id.startsWith("false_") || m.id.startsWith("true_")) && 
       await isAntibot(groupMetadata)) {
        const senderId = m?.sender || m?.key?.participant;
        if (isBotAdmins) {
            if (!isAdmins) {
                conn.sendMessage(m.chat, {
				text: `\`\`\`「 Bot Detected 」\`\`\`\n\n@${senderId?.split("@")[0]} You are detected as a BOT and will be removed!`,
				contextInfo: {
					mentionedJid: [senderId]
				}
			});
                await conn.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.key.participant
                    }
                });
                await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            }
        } else {
            await conn.sendMessage(m.chat, {
				text: `\`\`\`「 Bot Detected 」\`\`\`\n\n@${senderId?.split("@")[0]} Detected as a BOT, but I'm not an admin.`,
				contextInfo: {
					mentionedJid: [senderId]
				}
			});
        }
    }
};