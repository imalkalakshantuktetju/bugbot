module.exports = async (m, {
	conn,
	budy,
	isAdmins,
	isCreator,
	isBotAdmins,
	groupMetadata,
	isLinkgc
}) => {
	if ((await isLinkgc(groupMetadata))) {
		if (budy.includes(`chat.whatsapp.com`)) {
			if (!isBotAdmins) return
			if (isAdmins) return
			if (m?.key?.id && m?.key?.participant) {
				await conn.sendMessage(m.chat, {
					delete: {
						remoteJid: m.chat,
						fromMe: false,
						id: m.key.id,
						participant: m.key.participant
					}
				});
			} else {
				console.log("Pesan tidak valid untuk dihapus:", m);
			}
			const senderId = m?.sender || m?.key?.participant;
			conn.sendMessage(m.chat, {
				text: `\`\`\`「 Link Detected 」\`\`\`\n\n@${senderId?.split("@")[0]} You Message Has been delete, sorry.`,
				contextInfo: {
					mentionedJid: [senderId]
				}
			});
		}
	}
}