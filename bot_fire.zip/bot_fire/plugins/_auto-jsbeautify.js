const beautify = require('js-beautify');
const fs = require('fs/promises');
const path = require('path');
/*
module.exports = async (m, { conn }) => {
  const docMsg = m.msg?.documentMessage || m.message?.documentMessage || m.quoted?.msg?.documentMessage;

  if (!docMsg) return

  const maxSize = 5 * 1024 * 1024; // 5MB
  const fileSize = Number(docMsg.fileLength?.low || docMsg.fileLength || 0);
  if (fileSize > maxSize) return

  try {
    const tempFile = './temp_code';
    const bufferPath = await conn.downloadAndSaveMediaMessage(m, tempFile);

    const ext = (docMsg.mimetype.includes('javascript')) ? 'js' :
                (docMsg.mimetype.includes('css')) ? 'css' :
                (docMsg.mimetype.includes('html')) ? 'html' :
                path.extname(docMsg.fileName || '').replace('.', '') || 'txt';

    if (!['js', 'css', 'html'].includes(ext)) {
      await fs.unlink(bufferPath);
      return
    }

    const code = await fs.readFile(bufferPath, 'utf8');
    await fs.unlink(bufferPath); // hapus file

    let beautified;
    if (ext === 'js') {
      beautified = beautify.js(code, { indent_size: 2 });
    } else if (ext === 'css') {
      beautified = beautify.css(code, { indent_size: 2 });
    } else {
      beautified = beautify.html(code, { indent_size: 2 });
    }

    if (beautified.length > 4000) {
      return m.reply('Hasil terlalu panjang untuk dikirim via chat, silakan kirim file lebih kecil.');
    }

    await m.reply(`Hasil beautify file *${docMsg.fileName || 'file'}*:\n\n` + beautified);
  } catch (err) {
    console.error('ERROR SAAT MEMPROSES FILE:', err);
    m.reply('Terjadi kesalahan saat memproses file.');
  }
};
*/