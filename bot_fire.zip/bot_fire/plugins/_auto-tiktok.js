const axios = require("axios");
require("../catozolala").variable;

module.exports = async (m, {
	conn,
	budy
}) => {
	if (
		budy.includes('https://vt.tiktok.com/') ||
		budy.includes('https://www.tiktok.com/') ||
		budy.includes('https://t.tiktok.com/') ||
		budy.includes('https://vm.tiktok.com/')
	) {
		try {
			const tiktok = budy.trim().match(/(?:http(?:s)?:\/\/)?(?:www\.)?(?:tiktok\.com\/@[^\/]+\/video\/\d+|vm\.tiktok\.com\/[^\s&]+|vt\.tiktok\.com\/[^\s&]+)/g);
			if (!tiktok) return;

			async function tiktok2(query) {
				return new Promise(async (resolve, reject) => {
					try {
						const encodedParams = new URLSearchParams();
						encodedParams.set('url', query);
						encodedParams.set('hd', '1');

						const response = await axios({
							method: 'POST',
							url: 'https://tikwm.com/api/',
							headers: {
								'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
								'Cookie': 'current_language=en',
								'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
							},
							data: encodedParams
						});

						const videos = response.data?.data;
						if (!videos || !videos.play) throw new Error("Video tidak ditemukan");

						const result = {
							title: videos.title,
							cover: videos.cover,
							origin_cover: videos.origin_cover,
							no_watermark: videos.play,
							watermark: videos.wmplay,
							music: videos.music
						};

						resolve(result);
					} catch (error) {
						reject(error);
					}
				});
			}

			await conn.sendMessage(m.chat, {
				react: {
					text: "🕘",
					key: m.key
				}
			});

			const res = await tiktok2(tiktok[0]);

			await conn.sendMessage(m.chat, {
				video: {
					url: res.no_watermark
				},
				fileName: 'tiktok.mp4',
				mimetype: 'video/mp4',
				caption: `• *Title* : ${res.title}`
			});

			await conn.sendMessage(m.chat, {
				audio: {
					url: res.music
				},
				fileName: 'tiktok.mp3',
				mimetype: 'audio/mp4'
			});

		} catch (err) {
			console.error('Error TikTok:', err);
			await conn.sendMessage(m.chat, {
				text: `Gagal mengambil video/audio TikTok. Coba lagi nanti atau pastikan link valid.\n\n${err.message}`
			});
		}
	}
};