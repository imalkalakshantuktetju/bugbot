const handler = async (m, { conn, budy }) => {
  if (!budy.includes('videy.co')) return;

  await conn.sendMessage(m.chat, {
    react: {
      text: "🕘",
      key: m.key
    }
  });

  try {
    const regExp = /(?:videy\.co\/v\/\?id=|videy\.co\/v\/|videy\.co\/)([a-zA-Z0-9]+)/;
    const match = budy.match(regExp);

    if (!match || !match[1]) return m.reply('❌ ID video tidak ditemukan dalam URL.');

    const id = match[1];
    const downloadUrl = `https://cdn.videy.co/${id}.mp4`;

    await conn.sendMessage(m.chat, {
      video: { url: downloadUrl },
      caption: `✅ Sukses download videos`
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply("❌ Terjadi kesalahan saat mengambil video.");
  }
};

module.exports = handler;