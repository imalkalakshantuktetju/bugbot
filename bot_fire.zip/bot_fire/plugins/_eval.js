const util = require("util");

module.exports = async (m, {
	conn,
	command,
	cmd,
	isCmd,
	isCatozolala,
	isPromosi,
	dbFire,
	isLinkgc,
	db,
	isWelcome,
	isNsfw,
	isCreator,
	isBot,
	text,
	config,
	store,
	args,
	botNumber,
	prefix,
	froms: from,
	groupMetadata,
	budy,
	quoted,
	isAntibot,
	isBotAdmins,
	pushname,
	participants,
	isAntilink,
	getGroupData
}) => {
	if (budy.startsWith("=>")) {
		try {
			if (!isCreator) return;

			if (!text) {
				return await conn.sendMessage(m.chat, {
					text: "🚫 Tidak ada kode yang dievaluasi!"
				}, {
					quoted: m
				});
			}

			const evaled = await eval(`(async () => { ${text} })()`);

			const output = typeof evaled === 'string' ?
				evaled :
				util.inspect(evaled, {
					depth: 1
				});

			await conn.sendMessage(m.chat, {
				text: util.format(output)
			}, {
				quoted: m
			});

		} catch (e) {
			await conn.sendMessage(m.chat, {
				text: `🚫 Error: ${util.format(e.message || e)}`
			}, {
				quoted: m
			});
		}
	}

};