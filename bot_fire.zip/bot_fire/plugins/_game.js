module.exports = async (m, { conn, config }) => {
  if (m.id.startsWith('BAE5') || m.id.startsWith('3EB0') || m.fromMe) return
  conn.game = conn.game || {}
  const game = conn.game[m.sender]

  const sendRespon = async (teks) => {
    await conn.sendAds(m.chat, {
      text: teks,
      title: config.name,
      body: game?.type,
      link: "https://mekonime.cloud",
      image: "./media/logo.jpg",
      newsletterName: config.nameBots,
      newsletterJid: config.saluranId,
      botNumber: "628xxx@s.whatsapp.net"
    });
  }

  if (game?.jawaban && game?.type === "tebaktebakan") {
    const jawabanUser = (m.text || m.body || "").toLowerCase().trim()
    const jawabanBenar = game.jawaban.toLowerCase().trim()

    if (jawabanUser === jawabanBenar) {
      clearTimeout(game.timeout)
      delete conn.game[m.sender]
      return sendRespon(`🎉 *Benar!* Jawabannya adalah *${game.jawaban}*`)
    } else if (/menyerah|nyerah|kalah/i.test(jawabanUser)) {
      clearTimeout(game.timeout)
      delete conn.game[m.sender]
      return sendRespon(`😔 *Yah, kamu menyerah!* Jawaban yang benar adalah *${game.jawaban}*`);
    } else {
      return sendRespon(`❌ Salah! Silahkan coba lagi\n\n🧠 Soal: *${game.soal}*`)
    }
  } else if (game?.jawaban && game?.type === "tebakbendera") {
    const jawabanUser = (m.text || m.body || "").toLowerCase().trim()
    const jawabanBenar = game.jawaban.toLowerCase().trim()
    
    if (jawabanUser === jawabanBenar) {
      clearTimeout(game.timeout)
      delete conn.game[m.sender]
      return sendRespon(`🎉 *Benar!* Jawabannya adalah *${game.jawaban}*`)
    } else if (/menyerah|nyerah|kalah/i.test(jawabanUser)) {
      clearTimeout(game.timeout)
      delete conn.game[m.sender]
      return sendRespon(`😔 *Yah, kamu menyerah!* Jawaban yang benar adalah *${game.jawaban}*`);
    } else {
      return conn.sendMessage(m.chat, {image: {url: game.soal}, caption: `❌ Salah! Silahkan coba lagi`}, {quoted:m})
    }
  }
}