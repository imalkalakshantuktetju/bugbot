const fetch = require('node-fetch');
const cheerio = require('cheerio');

async function animeVideo() {
	const url = 'https://shortstatusvideos.com/anime-video-status-download/';
	const response = await fetch(url);
	const html = await response.text();
	const $ = cheerio.load(html);
	const videos = [];

	$('a.mks_button.mks_button_small.squared').each((_, element) => {
		const href = $(element).attr('href');
		const title = $(element).closest('p').prevAll('p').find('strong').text();
		videos.push({
			title,
			source: href
		});
	});

	const randomIndex = Math.floor(Math.random() * videos.length);
	return videos[randomIndex];
}

async function handler(m, {
	conn,
	text,
	cmd
}) {

	await conn.sendMessage(m.chat, {
		react: {
			text: "🕘",
			key: m.key
		}
	});

	try {
		let cap = 'Nih Kak Videonya';

		let resl = await animeVideo();

		await conn.sendMessage(m.chat, {
			video: {
				url: resl.source,
			},
			caption: cap
		}, {
			quoted: m
		})
	} catch (error) {
		console.error(error);
		m.reply('Terjadi kesalahan saat memproses permintaan.');
	}
}

handler.command = ['amv'];
handler.tags = ['anime'];

module.exports = handler;