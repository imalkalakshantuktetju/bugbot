let catozolala = async (m, { conn, config, text, command }) => {
  conn.game = conn.game || {}

  const sendRespon = async (teks) => {
    await conn.sendAds(m.chat, {
      text: teks,
      title: config.name,
      body: config.name,
      link: "https://mekonime.cloud",
      image: "./media/logo.jpg",
      newsletterName: config.nameBots,
      newsletterJid: config.saluranId,
      botNumber: "628xxx@s.whatsapp.net"
    });
  }

  if (conn.game[m.sender]?.soal) {
    return sendRespon("❌ Masih ada sesi game. Ketik *menyerah* untuk mengakhiri permainan.");
  }

  const data = json[Math.floor(Math.random() * json.length)]

  conn.game[m.sender] = {
    type: command,
    soal: data.img,
    jawaban: data.name,
    timeout: setTimeout(async () => {
      if (conn.game[m.sender]) {
        const jawaban = conn.game[m.sender].jawaban
        await sendRespon(`⏰ Waktu habis!\nJawaban yang benar adalah *${jawaban || "Tidak tahu"}*`);
        delete conn.game[m.sender];
      }
    }, 60 * 1000)
  };

  await conn.sendMessage(m.chat, {image: {url: data.img}, caption: `⚡ Kuis Bendera! Tebak bendera ini milik negara mana?`}, {quoted:m})
};

catozolala.tags = ["game"];
catozolala.command = ["tebakbendera"];

module.exports = catozolala;

const json = [
    {
        "img": "https://flagpedia.net/data/flags/w702/af.png",
        "name": "Afghanistan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ax.png",
        "name": "Åland Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/al.png",
        "name": "Albania"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/dz.png",
        "name": "Algeria"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/as.png",
        "name": "American Samoa"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ad.png",
        "name": "Andorra"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ao.png",
        "name": "Angola"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ai.png",
        "name": "Anguilla"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/aq.png",
        "name": "Antarctica"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ag.png",
        "name": "Antigua and Barbuda"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ar.png",
        "name": "Argentina"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/am.png",
        "name": "Armenia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/aw.png",
        "name": "Aruba"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/au.png",
        "name": "Australia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/at.png",
        "name": "Austria"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/az.png",
        "name": "Azerbaijan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bs.png",
        "name": "Bahamas"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bh.png",
        "name": "Bahrain"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bd.png",
        "name": "Bangladesh"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bb.png",
        "name": "Barbados"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/by.png",
        "name": "Belarus"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/be.png",
        "name": "Belgium"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bz.png",
        "name": "Belize"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bj.png",
        "name": "Benin"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bm.png",
        "name": "Bermuda"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bt.png",
        "name": "Bhutan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bo.png",
        "name": "Bolivia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ba.png",
        "name": "Bosnia and Herzegovina"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bw.png",
        "name": "Botswana"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bv.png",
        "name": "Bouvet Island"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/br.png",
        "name": "Brazil"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/io.png",
        "name": "British Indian Ocean Territory"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bn.png",
        "name": "Brunei"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bg.png",
        "name": "Bulgaria"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bf.png",
        "name": "Burkina Faso"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bi.png",
        "name": "Burundi"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/kh.png",
        "name": "Cambodia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cm.png",
        "name": "Cameroon"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ca.png",
        "name": "Canada"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cv.png",
        "name": "Cape Verde"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bq.png",
        "name": "Caribbean Netherlands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ky.png",
        "name": "Cayman Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cf.png",
        "name": "Central African Republic"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/td.png",
        "name": "Chad"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cl.png",
        "name": "Chile"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cn.png",
        "name": "China"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cx.png",
        "name": "Christmas Island"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cc.png",
        "name": "Cocos Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/co.png",
        "name": "Colombia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/km.png",
        "name": "Comoros"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cg.png",
        "name": "Republic of the Congo"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cd.png",
        "name": "DR Congo"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ck.png",
        "name": "Cook Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cr.png",
        "name": "Costa Rica"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ci.png",
        "name": "Côte d'Ivoire"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/hr.png",
        "name": "Croatia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cu.png",
        "name": "Cuba"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cw.png",
        "name": "Curaçao"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cy.png",
        "name": "Cyprus"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/cz.png",
        "name": "Czechia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/dk.png",
        "name": "Denmark"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/dj.png",
        "name": "Djibouti"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/dm.png",
        "name": "Dominica"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/do.png",
        "name": "Dominican Republic"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ec.png",
        "name": "Ecuador"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/eg.png",
        "name": "Egypt"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sv.png",
        "name": "El Salvador"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gb-eng.png",
        "name": "England"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gq.png",
        "name": "Equatorial Guinea"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/er.png",
        "name": "Eritrea"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ee.png",
        "name": "Estonia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sz.png",
        "name": "Eswatini"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/et.png",
        "name": "Ethiopia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/fk.png",
        "name": "Falkland Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/fo.png",
        "name": "Faroe Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/fj.png",
        "name": "Fiji"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/fi.png",
        "name": "Finland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/fr.png",
        "name": "France"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gf.png",
        "name": "French Guiana"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pf.png",
        "name": "French Polynesia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tf.png",
        "name": "French Southern and Antarctic Lands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ga.png",
        "name": "Gabon"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gm.png",
        "name": "Gambia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ge.png",
        "name": "Georgia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/de.png",
        "name": "Germany"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gh.png",
        "name": "Ghana"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gi.png",
        "name": "Gibraltar"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gr.png",
        "name": "Greece"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gl.png",
        "name": "Greenland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gd.png",
        "name": "Grenada"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gp.png",
        "name": "Guadeloupe"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gu.png",
        "name": "Guam"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gt.png",
        "name": "Guatemala"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gg.png",
        "name": "Guernsey"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gn.png",
        "name": "Guinea"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gw.png",
        "name": "Guinea-Bissau"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gy.png",
        "name": "Guyana"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ht.png",
        "name": "Haiti"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/hm.png",
        "name": "Heard Island and McDonald Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/hn.png",
        "name": "Honduras"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/hk.png",
        "name": "Hong Kong"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/hu.png",
        "name": "Hungary"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/is.png",
        "name": "Iceland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/in.png",
        "name": "India"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/id.png",
        "name": "Indonesia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ir.png",
        "name": "Iran"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/iq.png",
        "name": "Iraq"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ie.png",
        "name": "Ireland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/im.png",
        "name": "Isle of Man"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/il.png",
        "name": "Israel"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/it.png",
        "name": "Italy"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/jm.png",
        "name": "Jamaica"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/jp.png",
        "name": "Japan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/je.png",
        "name": "Jersey"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/jo.png",
        "name": "Jordan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/kz.png",
        "name": "Kazakhstan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ke.png",
        "name": "Kenya"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ki.png",
        "name": "Kiribati"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/kp.png",
        "name": "North Korea"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/kr.png",
        "name": "South Korea"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/xk.png",
        "name": "Kosovo"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/kw.png",
        "name": "Kuwait"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/kg.png",
        "name": "Kyrgyzstan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/la.png",
        "name": "Laos"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/lv.png",
        "name": "Latvia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/lb.png",
        "name": "Lebanon"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ls.png",
        "name": "Lesotho"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/lr.png",
        "name": "Liberia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ly.png",
        "name": "Libya"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/li.png",
        "name": "Liechtenstein"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/lt.png",
        "name": "Lithuania"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/lu.png",
        "name": "Luxembourg"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mo.png",
        "name": "Macau"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mg.png",
        "name": "Madagascar"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mw.png",
        "name": "Malawi"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/my.png",
        "name": "Malaysia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mv.png",
        "name": "Maldives"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ml.png",
        "name": "Mali"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mt.png",
        "name": "Malta"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mh.png",
        "name": "Marshall Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mq.png",
        "name": "Martinique"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mr.png",
        "name": "Mauritania"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mu.png",
        "name": "Mauritius"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/yt.png",
        "name": "Mayotte"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mx.png",
        "name": "Mexico"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/fm.png",
        "name": "Micronesia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/md.png",
        "name": "Moldova"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mc.png",
        "name": "Monaco"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mn.png",
        "name": "Mongolia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/me.png",
        "name": "Montenegro"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ms.png",
        "name": "Montserrat"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ma.png",
        "name": "Morocco"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mz.png",
        "name": "Mozambique"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mm.png",
        "name": "Myanmar"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/na.png",
        "name": "Namibia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/nr.png",
        "name": "Nauru"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/np.png",
        "name": "Nepal"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/nl.png",
        "name": "Netherlands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/nc.png",
        "name": "New Caledonia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/nz.png",
        "name": "New Zealand"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ni.png",
        "name": "Nicaragua"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ne.png",
        "name": "Niger"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ng.png",
        "name": "Nigeria"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/nu.png",
        "name": "Niue"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/nf.png",
        "name": "Norfolk Island"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mk.png",
        "name": "North Macedonia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gb-nir.png",
        "name": "Northern Ireland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mp.png",
        "name": "Northern Mariana Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/no.png",
        "name": "Norway"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/om.png",
        "name": "Oman"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pk.png",
        "name": "Pakistan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pw.png",
        "name": "Palau"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ps.png",
        "name": "Palestine"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pa.png",
        "name": "Panama"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pg.png",
        "name": "Papua New Guinea"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/py.png",
        "name": "Paraguay"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pe.png",
        "name": "Peru"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ph.png",
        "name": "Philippines"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pn.png",
        "name": "Pitcairn Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pl.png",
        "name": "Poland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pt.png",
        "name": "Portugal"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pr.png",
        "name": "Puerto Rico"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/qa.png",
        "name": "Qatar"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/re.png",
        "name": "Réunion"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ro.png",
        "name": "Romania"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ru.png",
        "name": "Russia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/rw.png",
        "name": "Rwanda"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/bl.png",
        "name": "Saint Barthélemy"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sh.png",
        "name": "Saint Helena, Ascension and Tristan da Cunha"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/kn.png",
        "name": "Saint Kitts and Nevis"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/lc.png",
        "name": "Saint Lucia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/mf.png",
        "name": "Saint Martin"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/pm.png",
        "name": "Saint Pierre and Miquelon"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/vc.png",
        "name": "Saint Vincent and the Grenadines"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ws.png",
        "name": "Samoa"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sm.png",
        "name": "San Marino"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/st.png",
        "name": "São Tomé and Príncipe"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sa.png",
        "name": "Saudi Arabia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gb-sct.png",
        "name": "Scotland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sn.png",
        "name": "Senegal"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/rs.png",
        "name": "Serbia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sc.png",
        "name": "Seychelles"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sl.png",
        "name": "Sierra Leone"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sg.png",
        "name": "Singapore"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sx.png",
        "name": "Sint Maarten"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sk.png",
        "name": "Slovakia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/si.png",
        "name": "Slovenia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sb.png",
        "name": "Solomon Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/so.png",
        "name": "Somalia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/za.png",
        "name": "South Africa"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gs.png",
        "name": "South Georgia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ss.png",
        "name": "South Sudan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/es.png",
        "name": "Spain"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/lk.png",
        "name": "Sri Lanka"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sd.png",
        "name": "Sudan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sr.png",
        "name": "Suriname"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sj.png",
        "name": "Svalbard and Jan Mayen"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/se.png",
        "name": "Sweden"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ch.png",
        "name": "Switzerland"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/sy.png",
        "name": "Syria"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tw.png",
        "name": "Taiwan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tj.png",
        "name": "Tajikistan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tz.png",
        "name": "Tanzania"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/th.png",
        "name": "Thailand"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tl.png",
        "name": "Timor-Leste"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tg.png",
        "name": "Togo"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tk.png",
        "name": "Tokelau"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/to.png",
        "name": "Tonga"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tt.png",
        "name": "Trinidad and Tobago"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tn.png",
        "name": "Tunisia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tr.png",
        "name": "Turkey"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tm.png",
        "name": "Turkmenistan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tc.png",
        "name": "Turks and Caicos Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/tv.png",
        "name": "Tuvalu"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ug.png",
        "name": "Uganda"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ua.png",
        "name": "Ukraine"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ae.png",
        "name": "United Arab Emirates"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gb.png",
        "name": "United Kingdom"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/us.png",
        "name": "United States"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/um.png",
        "name": "United States Minor Outlying Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/uy.png",
        "name": "Uruguay"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/uz.png",
        "name": "Uzbekistan"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/vu.png",
        "name": "Vanuatu"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/va.png",
        "name": "Vatican City"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ve.png",
        "name": "Venezuela"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/vn.png",
        "name": "Vietnam"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/vg.png",
        "name": "British Virgin Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/vi.png",
        "name": "United States Virgin Islands"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/gb-wls.png",
        "name": "Wales"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/wf.png",
        "name": "Wallis and Futuna"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/eh.png",
        "name": "Western Sahara"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/ye.png",
        "name": "Yemen"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/zm.png",
        "name": "Zambia"
    },
    {
        "img": "https://flagpedia.net/data/flags/w702/zw.png",
        "name": "Zimbabwe"
    }
]