const fs = require('fs');
const path = require('path');
const image = fs.readFileSync('./media/rimuru.jpg');
const {
	name
} = require("../catozolala");
const getUcapan = require("../lib/waktuUcapan");

async function getTopCommands(db) {
  const snapshot = await db.ref('top_features').once('value');
  const data = snapshot.val();

  if (!data) return [];

  const commandsArray = Object.entries(data).map(([_, value]) => ({
    command: value.command,
    count: value.count
  }));

  const sorted = commandsArray.sort((a, b) => b.count - a.count);
  const topCommands = sorted.slice(0, 3);

  return topCommands;
}

const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)

module.exports = async (m, {
	conn,
	prefix,
	isCreator,
	dbFire,
	config,
	groupMetadata,
	db
}) => {
    const groupId = dbFire.encodePath(groupMetadata.id);
	global.db.data.groups = global.db.data.groups || {};
	const groupInfo = global.db.data.groups[groupId] || null;
	const data = groupInfo?.bot_public === true;
	
	const pushName = m.pushName || "";
	let simplemenu = '';
	simplemenu += `╭─❖ 𝗛𝗮𝗹𝗼\n`;
	simplemenu += `│❍ *Mode: ${m.isGroup ? data ? "Public" : "Self" : "Private Chat"}*\n`;
	simplemenu += `│❍ *Owner: ${config.name}*\n`;
	simplemenu += `╰─────────────⳹\n\n`;
	simplemenu += `*Hi there! We're a friendly WhatsApp bot created to help make things easier for you. Whether you need quick answers, simple tasks done, or just a bit of guidance — we're here to assist, anytime you need.*`

	const topCommands = await getTopCommands(db);

	const flowActions = [{
		buttonId: `${prefix}menu`,
		buttonText: {
			displayText: '📂 Buka Menu Lengkap'
		},
		type: 4,
		nativeFlowInfo: {
			name: 'single_select',
			paramsJson: JSON.stringify({
				title: '📂 Options Menu',
				sections: [{
						title: "Top 3 Most Used Features",
						highlight_label: 'Top Features',
						rows: topCommands.map(cmd => ({
							header: `Command: ${cmd.command}`,
							title: `Already Used ${cmd.count} times`,
							id: `${prefix}${cmd.command}`
						}))
					},
					{
						title: 'Menu Options',
						highlight_label: 'Rimuru',
						rows: [{
								title: 'Main Menu',
								description: 'See all the awesome features available',
								id: `${prefix}mainmenu`
							},
							{
								title: 'Bug Menu',
								description: `Check out all the features under the bug menu`,
								id: `${prefix}bugmenu`
							},
							{
								title: 'All Menu',
								description: 'see all bot features',
								id: `${prefix}allmenu`
							}
						]
					}
				]
			})
		},
		viewOnce: true
	}];

	const buttonMessage = {
		document: fs.readFileSync("./package.json"),
		fileName: getUcapan(),
		fileLength: Infinity,
		pageCount: Infinity,
		mimetype: 'application/pdf',
		caption: simplemenu,
		jpegThumbnail: global.media,
		footer: `Powered by ${name}`,
		buttons: flowActions,
		headerType: 6,
		viewOnce: true,
		forwardingScore: 99999,
		isForwarded: true,
		mentionedJid: [m?.sender],
		contextInfo: {
		    thumbnail: image,
		    forwardingScore: 99999,
		    isForwarded: true,
		    mentionedJid: [m?.sender],
			externalAdReply: {
			    sourceUrl: `instagram.com`,
				containsAutoReply: true,
				mediaType: 1,
				thumbnail: global.media,
				renderLargerThumbnail: true,		
				title: config.nameBots,
				body: 'Powered by whatsapp'
			}
		}
	};

	return conn.sendMessage(m.chat, buttonMessage, {
		quoted: conn.packSticker
	});
};

module.exports.command = ['menu', 'rimuru'];
module.exports.tags = ["menu"];

/*

const mimeTypes = [
  'image/jpeg', // JPG
  'image/png', // PNG
  'image/gif', // GIF
  'application/pdf', // PDF
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // Word .docx
  'application/msword', // Word .doc
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // Excel .xlsx
  'application/vnd.ms-excel', // Excel .xls
  'application/vnd.openxmlformats-officedocument.presentationml.presentation', // PowerPoint .pptx
  'application/vnd.ms-powerpoint', // PowerPoint .ppt
  'text/plain', // TXT
  'application/json', // JSON
  'application/zip', // ZIP
  'application/x-7z-compressed', // 7Z
  'application/x-rar-compressed', // RAR
  'application/vnd.rar', // RAR alternatif
  'application/x-tar', // TAR
  'application/x-bzip2', // BZ2
  'application/x-gzip', // GZ
  'application/vnd.android.package-archive', // APK
  'application/x-msdownload', // EXE
  'audio/mpeg', // MP3
  'audio/ogg', // OGG
  'audio/wav', // WAV
  'video/mp4', // MP4
  'video/x-matroska', // MKV
  'video/x-msvideo', // AVI
  'video/3gpp', // 3GP
  'text/html', // HTML
  'application/xml', // XML
  'text/csv' // CSV
];

*/