let handler = async (m, { conn, prefix, command, text }) => {
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false
    
    if (!target) return conn.sendMessage(m.chat, {
        text: `Reply atau tag orangnya! \n\nContoh : \n${prefix + command} @${m.sender.split("@")[0]}`,
        mentions: [m.sender]
    }, { quoted: m })

    if (target == m.sender) return m.reply("Tidak bisa kick diri sendiri")

    await conn.groupParticipantsUpdate(m.chat, [target], 'remove')
    await delay(2000)
    await conn.sendMessage(m.chat, {
        text: `Sukses mengeluarkan @${target.split("@")[0]} dari group!`,
        mentions: [target]
    }, { quoted: m })
}

handler.help = ['reply/kick']
handler.tags = ['group']
handler.command = ["kick"]
handler.admin = true
handler.group = true
handler.botAdmin = true

module.exports = handler

let delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))