const linkRegex = /chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i

let handler = async (m, {
	text: txt,
	config,
	conn
}) => {
	global.db.data.users[m.sender] = global.db.data.users[m.sender] || {}
	global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}

	let user = global.db.data.users[m.sender]
	let chat = global.db.data.chats[m.chat]

	user.afk = +new Date
	let isGroupLink = linkRegex.exec(txt)
	let text = chat.antiLinkGc && isGroupLink ? 'KAMU TERDETEKSI MENGIRIM LINK' : txt
	user.afkReason = text
	
	conn.sendAds(m.chat, {text: `@${m.sender.split("@")[0]} is now AFK

Reason ➠ ${text ? text : 'Tanpa Alasan'}`, title:`Powered by ${config.name}`})

}

handler.help = ['afk'];
handler.tags = ['group', 'main'];
handler.command = ["afk"];
handler.group = true;

module.exports = handler;