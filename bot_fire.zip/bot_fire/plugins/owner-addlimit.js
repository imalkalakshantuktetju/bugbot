const { message } = require("../catozolala");

let handler = async (m, { command, conn, text, prefix, dbFire}) => {

  if (!text) {
    return m.reply(`*\`Example:\`* ${prefix + command} 62xxx, 10`);
  }

  let [teks1, teks2] = text.split(',').map(x => x.trim());
  if (!teks1 || !teks2 || isNaN(teks2)) {
    return m.reply(`Format salah!\n\nContoh: *${prefix + command} 62xxx, 10*`);
  }

  const nmrnya = teks1.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  const onWa = await conn.onWhatsApp(nmrnya);
  if (!onWa.length) return m.reply('❌ Nomor tersebut tidak terdaftar di WhatsApp!');

  dbFire.tambahLimit(nmrnya, parseInt(teks2));

  let msg = `╭─「 *✅ Sukses* 」
│⿻ *Phone* : @${nmrnya.split('@')[0]}
│⿻ *Total* : limit ditambahkan
╰─────────────────────`;

  let msgSend = `╭─「 *✅ Sukses* 」
│⿻ *Phone* : @${nmrnya.split('@')[0]}
│⿻ *Total* : limit ditambahkan
╰─────────────────────`;

  await conn.sendMessage(m.chat, { text: msg, mentions: [nmrnya] }, { quoted: m });
  await conn.sendMessage(nmrnya, { text: msgSend, mentions: [nmrnya] }, { quoted: m });
};

handler.command = ["addlimit"];
handler.tags = ["owner"];
handler.owner = true;

module.exports = handler;