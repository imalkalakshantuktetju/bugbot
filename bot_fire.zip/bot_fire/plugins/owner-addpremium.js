const fs = require('fs');
const { message } = require("../catozolala");
const {
  addPremiumUser,
  checkPremiumUser,
  getAllPremiumUser,
  getPremiumExpired,
  getPremiumPosition
} = require('../lib/premium_feature');

let handler = async (m, { command, conn, text, prefix }) => {

  if (!text) {
    return m.reply(`*\`Example:\`* ${prefix + command} 62xxx, 30d\n\n` +
                   `*Format Durasi*: \`s\` = detik, \`m\` = menit, \`h\` = jam, \`d\` = hari`);
  }

  let [teks1, teks2] = text.split(',').map(x => x.trim());
  const nmrnya = teks1.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  const onWa = await conn.onWhatsApp(nmrnya);
  if (!onWa.length) return m.reply('❌ Nomor tersebut tidak terdaftar di WhatsApp!');

  const validDurasi = /^(?:\d+)(s|m|h|d)$/i;
  if (!teks2 || !validDurasi.test(teks2)) {
    return m.reply(`❌ Durasi tidak valid!\nGunakan format: \`10s\`, \`5m\`, \`2h\`, atau \`30d\``);
  }

  let premium = JSON.parse(fs.readFileSync('./database/premium.json'));
  if (checkPremiumUser(nmrnya, premium)) {
    return m.reply('⚠️ Pengguna tersebut sudah menjadi premium!');
  }

  await addPremiumUser(nmrnya, teks2, premium);
  
  let msg = `╭─「 *✅ Sukses add* 」
│⿻ *Phone* : @${nmrnya.split('@')[0]}
│⿻ *Selama*   : ${teks2}
│⿻ *Fitur* : VVIP
╰─────────────────────`;

  let msgSend = `╭─「 *✅ Anda Telah Premium* 」
│⿻ *Phone* : @${nmrnya.split('@')[0]}
│⿻ *Selama*   : ${teks2}
│⿻ *Fitur* : VVIP
╰─────────────────────`;

  await conn.sendMessage(m.chat, { text: msg, mentions: [nmrnya] }, {quoted:m});
  await conn.sendMessage(nmrnya, { text: msgSend, mentions: [nmrnya] }, {quoted:m});
};

handler.command = ["addpremium", "addprem"];
handler.tags = ["owner"];
handler.owner = true

module.exports = handler;