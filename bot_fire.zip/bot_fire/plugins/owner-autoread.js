let handler = async (m, {conn, cmd, command, text, config}) => {
  
  if (!text) return conn.sendAds(m.chat, {text: `*Example:* ${cmd} on/off`.trim(), title:`Powered by ${config.name}`});
  
  if (text === "on") {
  
    global.db.data.settings.autoread = true;
    conn.sendAds(m.chat, {text: `Succesfully set the bot *${cmd} on* `.trim(), title:`Powered by ${config.name}`})
    
  } else if (text === "off") {
  
    global.db.data.settings.autoread = false;
    conn.sendAds(m.chat, {text: `Succesfully set the bot *${cmd} off* `.trim(), title:`Powered by ${config.name}`})
    
  } else {
    conn.sendAds(m.chat, {text: `Pilihan hanya on atau off`.trim(), title:`Powered by ${config.name}`});
  }
  
}

handler.help = ["on/off"];
handler.tags = ["owner"];
handler.command = ["autoread", "readmessage"];
handler.owner = true

module.exports = handler;