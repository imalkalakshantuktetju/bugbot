let _1 = async (m, { conn, cmd, text }) => {
  if (!text) {
    m.reply(
      `📌 *Contoh Penggunaan:*\n` +
      `\`${cmd} <teks>\`\n\n` +
      `💡 *Contoh:* \`${cmd} Halo semuanya!\`\n\n` +
      `📎 Bisa juga digunakan dengan *reply* gambar/video atau *caption*!`
    )
    return
  }

  let quotedMsg = m.quoted ? (m.quoted.message || m.quoted) : m.message?.imageMessage || null
  let messageMedia = quotedMsg || m.message
  let mime = messageMedia?.mimetype || ''

  const isImage = mime.startsWith('image/')
  const isVideo = mime.startsWith('video/')

  let chats = await conn.chats.all()

  let fromObject = Object.values(chats[2] || {})
    .map(v => v.id)
    .filter(id => id && id.endsWith('@s.whatsapp.net'))

  let fromArray = (chats[3] || [])
    .map(v => v.id)
    .filter(id => id && id.endsWith('@s.whatsapp.net'))

  let allPrivateIds = [...new Set([...fromObject, ...fromArray])]
  
  await conn.sendMessage(m.chat, {
			react: {
				text: "🕘",
				key: m.key
			}
		});
		
  for (let id of allPrivateIds) {
    try {
      if (isImage || isVideo) {
        const data = await conn.downloadMediaMessage(messageMedia)
        await conn.sendMessage(id, {
          [isImage ? 'image' : 'video']: data,
          caption: text
        })
      } else {
        await conn.sendMessage(id, { text })
      }
    } catch (err) {
      console.error(`❌ Gagal kirim pesan ke chat ${id}:`, err)
    }

    await delay(3000)
  }

  m.reply(`✅ Sukses kirim ke *${allPrivateIds.length}* chat pribadi`)
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

_1.tags = ["owner"]
_1.command = ["bcpv", "broadcastpv"]
_1.owner = true

module.exports = _1