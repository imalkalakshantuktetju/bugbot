let handler = async (m, { conn, args }) => {
  try {
    
    let allChats = Object.values(conn.chats);
    let privateChats = allChats.filter(chat => chat.id.endsWith('@s.whatsapp.net')).map(chat => chat.id);
    let groupChats = allChats.filter(chat => chat.id.endsWith('@g.us')).map(chat => chat.id);

    let chatsToDelete = [];

    if (args[0] === '--pc') {
      chatsToDelete = privateChats;
    } else if (args[0] === '--gc') {
      chatsToDelete = groupChats;
    } else if (args[0] === '--all') {
      chatsToDelete = [...privateChats, ...groupChats];
    } else {
      return await m.reply('❌ Gunakan perintah dengan:\n\n`.clearchat --pc` untuk chat pribadi\n`.clearchat --gc` untuk chat grup\n`.clearchat --all` untuk semua chat.');
    }

    const totalChatsToDelete = chatsToDelete.length;

    for (let id of chatsToDelete) {
      try {
        await conn.chatModify({ delete: true }, id);
      } catch (error) {
        console.error(`❌ Gagal menghapus chat ${id}:`, error);
      }
    }

    await m.reply(`✅ Berhasil menghapus ${totalChatsToDelete} chat!`)
  } catch (error) {
    console.error('❌ Error dalam handler:', error);
    await m.reply('❌ Terjadi kesalahan dalam menghapus chat.')
  }
};

handler.help = ['clearchat'];
handler.tags = ['owner'];
handler.owner = true;
handler.command = ["clearchat"];

module.exports = handler;