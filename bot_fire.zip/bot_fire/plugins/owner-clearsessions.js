let handler = async (m,{conn}) => {
   const {
		clearSessions
	} = require("../lib/clearsessions.js");
	clearSessions("../sessions");
	m.reply("Sukses");
}

handler.tags = ["owner"];
handler.command = ["clearsessions", "clears"];
handler.owner = true;

module.exports = handler;