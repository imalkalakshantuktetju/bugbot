const { createCanvas, loadImage } = require('canvas');
const os = require('os');
const speed = require('performance-now');
const { exec } = require('child_process');

const handler = async (m, { conn }) => {
    let timestamp = speed();
    let latensi = speed() - timestamp;

    exec(`neofetch --stdout`, async (error, stdout) => {
        let child = stdout.toString("utf-8");
        let ssd = child.replace(/Memory:/, "Ram:");

        let usedMemory = process.memoryUsage().heapUsed / 1024 / 1024;
        let totalMemory = os.totalmem() / 1024 / 1024;

        let canvas = createCanvas(1000, 800);
        let ctx = canvas.getContext('2d');

        // Background Gradient
        let gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, '#141e30');
        gradient.addColorStop(1, '#243b55');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Decorative Circles
        ctx.fillStyle = 'rgba(255,255,255,0.05)';
        ctx.beginPath();
        ctx.arc(150, 150, 100, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(850, 650, 80, 0, Math.PI * 2);
        ctx.fill();

        // Title with shadow
        ctx.font = 'bold 48px Sans';
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 10;
        ctx.fillText('System Monitor', canvas.width / 2 - ctx.measureText('System Monitor').width / 2, 80);

        ctx.shadowBlur = 0; // Remove shadow for normal texts
        ctx.font = '28px Sans';

        // Info box background
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.fillRect(100, 120, 800, 480);
        ctx.strokeStyle = 'rgba(255,255,255,0.2)';
        ctx.strokeRect(100, 120, 800, 480);

        // System Info Text
        const infoTexts = [
            `📦 CPU Info:`,
            `${ssd.split('\n').slice(0, 6).join('\n')}`,
            `⚡ Speed: ${latensi.toFixed(4)} MS`,
            `🧠 Memory: ${usedMemory.toFixed(2)} MB / ${totalMemory.toFixed(2)} MB`,
            `🖥️ OS: ${os.version()}`,
            `💻 Platform: ${os.platform()}`,
            `📡 Hostname: ${os.hostname()}`
        ];

        ctx.fillStyle = '#ffffff';
        let yText = 170;
        for (let text of infoTexts) {
            const lines = text.split('\n');
            for (let line of lines) {
                ctx.fillText(line, 130, yText);
                yText += 30;
            }
        }

        // Speed Bar
        const speedBarWidth = 700;
        const speedBarHeight = 30;
        const maxLatency = 0.01;
        const speedPercent = Math.max(1 - latensi / maxLatency, 0);
        const speedColor = latensi < 0.005 ? '#00ff00' : latensi < 0.008 ? '#ffff00' : '#ff0000';

        ctx.fillStyle = '#333';
        ctx.fillRect(150, 550, speedBarWidth, speedBarHeight);
        ctx.fillStyle = speedColor;
        ctx.fillRect(150, 550, speedBarWidth * speedPercent, speedBarHeight);
        ctx.fillStyle = '#ffffff';
        ctx.font = '20px Sans';
        ctx.fillText('Network Speed', 150, 540);

        // Memory Bar
        const memPercent = usedMemory / totalMemory;
        const memColor = memPercent < 0.5 ? '#00ff00' : memPercent < 0.8 ? '#ffff00' : '#ff0000';

        ctx.fillStyle = '#333';
        ctx.fillRect(150, 620, speedBarWidth, speedBarHeight);
        ctx.fillStyle = memColor;
        ctx.fillRect(150, 620, speedBarWidth * memPercent, speedBarHeight);
        ctx.fillStyle = '#ffffff';
        ctx.fillText('Memory Usage', 150, 610);

        // Footer
        ctx.fillStyle = '#ffffff';
        ctx.font = 'italic 18px Sans';
        ctx.fillText('Powered by Catozolala - Catozolala', canvas.width / 2 - ctx.measureText('Powered by Catozolala - Your Trusted Bot').width / 2, 750);

        // Send as image
        let buffer = canvas.toBuffer();
        let caption = `*Speed:* *${latensi.toFixed(4)} MS*\n*Memory:* *${usedMemory.toFixed(2)}MB / ${totalMemory.toFixed(2)}MB*\n*OS:* *${os.version()}*\n*Platform:* *${os.platform()}*\n*Hostname:* *${os.hostname()}*`;

        conn.sendMessage(m.chat, {
            image: buffer,
            caption,
            footer: "Powered by Catozolala",
            buttons: [
                { buttonId: '.menu', buttonText: { displayText: 'Kembali Awal' }, type: 1 },
                { buttonId: '.owner', buttonText: { displayText: 'Owner Bot' }, type: 1 }
            ],
            headerType: 1,
            viewOnce: true
        }, { quoted: m });
    });
};

handler.command = ['os'];
handler.tags = ['main'];
handler.owner = true;

module.exports = handler;