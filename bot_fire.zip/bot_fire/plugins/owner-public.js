let handler = async (m, {conn, command, config, text}) => {

  if (command === "self") {
    conn.public = true;
    conn.sendAds(m.chat, {text: `Succesfully set the bot *Self* `.trim(), title:`Powered by ${config.name}`})
  } else if (command === "public") {
    conn.public = false;
    conn.sendAds(m.chat, {text: `Succesfully set the bot *public* `.trim(), title:`Powered by ${config.name}`})
  }
  
}

handler.tags = ["owner"];
handler.command = ["self", "public"];
handler.owner = true;

module.exports = handler;