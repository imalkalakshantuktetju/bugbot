const cron = require('node-cron');
const { spawn } = require('child_process');
const fs = require('fs');

let handler = async (m, { conn }) => {
  await m.reply('♻️ Restarting bot...');
  
  fs.writeFileSync('restart.json', JSON.stringify({
    jid: m.chat,
    name: await conn.getName(m.sender)
  }));

  setTimeout(() => process.exit(0), 1000);
};

handler.help = ['restart'];
handler.tags = ['owner'];
handler.command = ["restart"];
handler.owner = true;

module.exports = handler;