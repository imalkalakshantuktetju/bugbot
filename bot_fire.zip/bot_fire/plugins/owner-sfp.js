const fs = require('fs');

let handler = async (m, { text, command }) => {
    if (!text) return m.reply(`📣 \`ᴄᴀʀᴀ ᴘᴇɴɢɢᴜɴᴀᴀɴ\`\n\>  .sғᴘ ᴍᴇɴᴜ`)
    try {
    if (!m.quoted.text) return m.reply(`ᴍᴀɴᴀ ᴄᴏᴅᴇ`)
    let path = `plugins/${text}.js`
    await fs.writeFileSync(path,m.quoted.text);
  await m.reply(`*tersimpan di ${path}*`)
  } catch (error) {
    console.log(error)
    m.reply("reply code fitur nya kak")
  }
}

handler.help = ['sfp'].map(v => v + ' <path>')
handler.tags = ['owner']
handler.command = ['sfp']
handler.owner = true;

module.exports = handler