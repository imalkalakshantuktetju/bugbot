
let handler = async (m, {conn, text, cmd}) => {

const sender = m.key.fromMe ? (conn.user.id.split(':')[0]+'@s.whatsapp.net' || conn.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`

try {
  if (!text) return m.reply(`*\`Example:\`* < ${cmd} rimuru >\n\nContoh: ${cmd} rimuru`)
  //try {
  let { key } = await conn.sendMessage(m.chat, {text:"*`[ ʟᴏᴀᴅɪɴɢ ]`* ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ",}, {quoted:{ key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: `Search`}}});

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: conn.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let data = await pins(text);
  let res = data

  shuffleArray(res);
  let ult = res.splice(0, 10);
  let i = 1;

  for (let pus of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `ᴘɪɴsʟɪᴅᴇ ᴀᴅᴀʟᴀʜ ᴘʟᴀᴛғᴏʀᴍ ᴍᴇᴅɪᴀ sᴏsɪᴀʟ ʏᴀɴɢ ᴍᴇᴍᴜɴɢᴋɪɴᴋᴀɴ ᴘᴇɴɢɢᴜɴᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴍᴇɴʏɪᴍᴘᴀɴ ᴅᴀɴ ᴍᴇɴɢᴏʀɢᴀɴɪsɪʀ ɢᴀᴍʙᴀʀ,`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: "yo"
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: "*`ʜᴀsɪʟ`* "+ `10/${i++}`,
        hasMediaAttachment: true,
        imageMessage: await createImage(pus)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: `{"display_text":"url","Klik disini":"${pus}","merchant_url":"${pus}"}`
          }
        ]
      })
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `ʜᴀɪ ${pushname}\nɪɴɪ ᴀᴅᴀʟᴀʜ ʜᴀsɪʟ ᴘᴇɴᴄᴀʀɪᴀɴ ᴋᴀᴍᴜᴜ..`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "halo"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {});

  await conn.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
  
} catch (error) {
    console.error('Error:', error);
    throw `*ERROR*`;
  }

}

handler.help = ['pinterest *<text>*'];
handler.tags = ['internet', 'search'];
handler.command = ['pinterest','pin'];
module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}

const pins = async function (judul) {
  const link = `https://id.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(judul)}%26rs%3Dtyped&data=%7B%22options%22%3A%7B%22applied_unified_filters%22%3Anull%2C%22appliedProductFilters%22%3A%22---%22%2C%22article%22%3Anull%2C%22auto_correction_disabled%22%3Afalse%2C%22corpus%22%3Anull%2C%22customized_rerank_type%22%3Anull%2C%22domains%22%3Anull%2C%22dynamicPageSizeExpGroup%22%3A%22control%22%2C%22filters%22%3Anull%2C%22journey_depth%22%3Anull%2C%22page_size%22%3Anull%2C%22price_max%22%3Anull%2C%22price_min%22%3Anull%2C%22query_pin_sigs%22%3Anull%2C%22query%22%3A%22${encodeURIComponent(judul)}%22%2C%22redux_normalize_feed%22%3Atrue%2C%22request_params%22%3Anull%2C%22rs%22%3A%22typed%22%2C%22scope%22%3A%22pins%22%2C%22selected_one_bar_modules%22%3Anull%2C%22seoDrawerEnabled%22%3Afalse%2C%22source_id%22%3Anull%2C%22source_module_id%22%3Anull%2C%22source_url%22%3A%22%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(judul)}%26rs%3Dtyped%22%2C%22top_pin_id%22%3Anull%2C%22top_pin_ids%22%3Anull%7D%2C%22context%22%3A%7B%7D%7D`;
  const headers = {
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'priority': 'u=1, i',
    'referer': 'https://id.pinterest.com/',
    'screen-dpr': '1',
    'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133")',
    'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Google Chrome";v="133.0.6943.142", "Chromium";v="133.0.6943.142")',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-model': '""',
    'sec-ch-ua-platform': '"Windows"',
    'sec-ch-ua-platform-version': '"10.0.0"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/133.0.0.0 Safari/537.36',
    'x-app-version': 'c056fb7',
    'x-pinterest-appstate': 'active',
    'x-pinterest-pws-handler': 'www/index.js',
    'x-pinterest-source-url': '/',
    'x-requested-with': 'XMLHttpRequest'
  };

  try {
    const res = await axios.get(link, { headers });
    let items = [];
    if (res.data?.resource_response?.data?.results) {
      res.data.resource_response.data.results.forEach(item => {
        if (item.images) items.push(item.images.orig.url);
      });
    }
    return items;
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    return [];
  }
};