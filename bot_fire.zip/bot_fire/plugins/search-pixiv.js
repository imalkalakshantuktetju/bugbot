const axios = require('axios');

let handler = async (m, { conn, command, text }) => {
    if (!text) return m.reply('Masukkan query, contoh: pixiv rem');

    try {
        await conn.sendMessage(m.chat, { 
            react: { 
                text: "🔍", 
                key: m.key 
            }
        });

        let image = await getPixivRandomImage(text);

        await conn.sendMessage(
            m.chat,
            {
                image,
                caption: `✅ Hasil untuk: *${text}*`
            },
            {
                quoted: m
            }
        );
    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal mengambil gambar.');
    }
};

handler.command = ['pixiv'];
handler.tags = ['search', 'internet', 'nsfw'];
handler.group = true;
handler.limit = true;
handler.nsfw = true;
module.exports = handler;

async function getPixivRandomImage(keyword) {
    const res = await axios.get('https://api.lolicon.app/setu/v2', {
        params: {
            keyword,
            r18: 2
        }
    });

    const result = res.data?.data?.[0];
    if (!result) throw 'Gambar tidak ditemukan.';

    const imageUrl = result.urls.original;
    const image = await axios.get(imageUrl, {
        responseType: 'arraybuffer'
    });

    return image.data;
}