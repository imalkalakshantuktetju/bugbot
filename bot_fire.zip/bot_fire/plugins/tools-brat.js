const fs = require('fs');
const { createCanvas } = require('canvas');
const path = require('path')
const os = require('os')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const { Image } = require('node-webpmux')
const axios = require('axios')

async function imageToWebp(mediaBuffer) {
  const tmpIn = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.png')
  const tmpOut = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')

  fs.writeFileSync(tmpIn, mediaBuffer)

  await new Promise((resolve, reject) => {
    ffmpeg(tmpIn)
      .on('error', reject)
      .on('end', resolve)
      .outputOptions([
        '-vcodec', 'libwebp',
        '-vf', "scale=iw*min(512/iw\\,512/ih):ih*min(512/iw\\,512/ih),pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000",
        '-lossless', '1',
        '-preset', 'default',
        '-pix_fmt', 'yuva420p',
        '-an',
        '-vsync', '0'
      ])
      .toFormat('webp')
      .save(tmpOut)
  })

  const buff = fs.readFileSync(tmpOut)
  fs.unlinkSync(tmpIn)
  fs.unlinkSync(tmpOut)
  return buff
}


async function writeExifImg(media, metadata = {}) {
  const wMedia = await imageToWebp(media)
  const tmpIn = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')
  const tmpOut = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')

  fs.writeFileSync(tmpIn, wMedia)

  if (metadata.packname || metadata.author) {
    const img = new Image()
    const json = {
      'sticker-pack-id': 'https://github.com/catozolala',
      'sticker-pack-name': metadata.packname || '',
      'sticker-pack-publisher': metadata.author || '',
      'emojis': metadata.categories || ['']
    }
    const exifAttr = Buffer.from([
      0x49, 0x49, 0x2A, 0x00,
      0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57,
      0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00,
      0x00, 0x00
    ])
    const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8')
    const exif = Buffer.concat([exifAttr, jsonBuff])
    exif.writeUIntLE(jsonBuff.length, 14, 4)

    await img.load(tmpIn)
    img.exif = exif
    await img.save(tmpOut)
    fs.unlinkSync(tmpIn)
    return fs.readFileSync(tmpOut)
  } else {
    return wMedia
  }
}


async function sendImageAsSticker(conn, jid, media, quoted, options = {}) {
  let buffer
  if (Buffer.isBuffer(media)) {
    buffer = media
  } else if (typeof media === 'string') {
    if (/^data:.*?\/.*?;base64,/i.test(media)) {
      buffer = Buffer.from(media.split(',')[1], 'base64')
    } else if (/^https?:\/\//.test(media)) {
      buffer = await getBuffer(media)
    } else if (fs.existsSync(media)) {
      buffer = fs.readFileSync(media)
    } else {
      throw new Error('Media string tidak valid')
    }
  } else {
    throw new Error('Media tidak valid')
  }

  const webpSticker = await writeExifImg(buffer, {
    packname: options.packname || 'Sticker Pack',
    author: options.author || 'by Catozolala',
    categories: options.categories || ['']
  })

  await conn.sendMessage(jid, { sticker: webpSticker, ...options }, { quoted })
  return webpSticker
}

async function getBuffer(url) {
  const res = await axios.get(url, { responseType: 'arraybuffer' })
  return Buffer.from(res.data, 'binary')
}

const tempPath = `../tmp/brat_image_${Date.now()}.png`;
let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("Contoh penggunaan: .brat ikan patin nelen paku, yakin nih ga kangen aku?");
  try {
    conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    async function BratGenerator(text) {
  const width = 1024;
  const height = 1024;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, width, height);

  const words = text.split(' ');

  // Ukuran font berdasarkan jumlah kata
  let fontSize;
  if (words.length <= 3) fontSize = 72;
  else if (words.length <= 6) fontSize = 54;
  else if (words.length <= 9) fontSize = 42;
  else fontSize = 32;
  ctx.font = `${fontSize}px Arial`;
  ctx.fillStyle = 'black';
  ctx.textAlign = 'left';

  // Tulis kata per kolom
  let x = 60;
  let y = 100;
  let maxCol = 3;
  let spacingX = 300;
  let spacingY = fontSize + 20;

  words.forEach((word, i) => {
    ctx.fillText(word, x + (i % maxCol) * spacingX, y + Math.floor(i / maxCol) * spacingY);
  });

  const rawBuffer = canvas.toBuffer('image/png');

  // Burikkan gambar dengan resize
  const { createCanvas: resizeCanvas, loadImage } = require('canvas');
  const smallCanvas = resizeCanvas(512, 512);
  const smallCtx = smallCanvas.getContext('2d');
  const loaded = await loadImage(rawBuffer);
  smallCtx.drawImage(loaded, 0, 0, 512, 512);

  const buffer = smallCanvas.toBuffer('image/png');
  fs.writeFileSync(tempPath, buffer);

  await sendImageAsSticker(conn, m.chat, buffer, m, {
    packname: "Sticker By",
    author: "Catozolala"
  });

  fs.unlinkSync(tempPath);
}

    await BratGenerator(text);
  } catch (error) {
    console.log(error);
    m.reply("Terjadi kesalahan saat membuat gambar.");
  }
};

handler.command = ["brat"];
handler.tags = ["tools"];

module.exports = handler;