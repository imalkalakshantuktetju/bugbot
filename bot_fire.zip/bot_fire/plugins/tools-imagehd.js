const FormData = require("form-data");
const sharp = require("sharp");

async function processing(buffer, method) {
  return new Promise((resolve, reject) => {
    const allowed = ["enhance", "recolor", "dehaze"];
    method = allowed.includes(method) ? method : "enhance";

    const form = new FormData();
    const url = `https://inferenceengine.vyro.ai/${method}`;

    form.append("model_version", 1);
    form.append("image", Buffer.from(buffer), {
      filename: "image.jpg",
      contentType: "image/jpeg",
    });

    form.submit(
      {
        url,
        host: "inferenceengine.vyro.ai",
        path: "/" + method,
        protocol: "https:",
        headers: {
          "User-Agent": "okhttp/4.9.3",
          Connection: "Keep-Alive",
          "Accept-Encoding": "gzip",
        },
      },
      (err, res) => {
        if (err) return reject(err);
        const chunks = [];
        res.on("data", chunk => chunks.push(chunk));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
  });
}

let handler = async (m, { conn, command }) => {
  const sessions = {
    hd: "enhancer",
    color: "recolor",
    hdr: "hdr"
  };

  const sessionKey = sessions[command] || "enhancer";
  conn[sessionKey] = conn[sessionKey] || {};

  if (m.sender in conn[sessionKey]) {
    return m.reply("⏳ Masih ada proses gambar sebelumnya. Mohon tunggu ya kak.");
  }

  const q = m.quoted || m;
  const mime = (q.msg || q).mimetype || q.mediaType || "";

  if (!mime) return m.reply("🖼️ Kirim atau reply gambar dulu kak.");
  if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`⚠️ Format gambar *${mime}* tidak didukung.`);

  conn[sessionKey][m.sender] = true;
  m.reply("🔧 Sedang memproses gambar...");

  try {
    const imageBuffer = await q.download?.();
    if (!imageBuffer) return m.reply("❌ Gagal mengunduh gambar.");

    const enhancedBuffer = await processing(imageBuffer, command);

    // ✨ Tingkatkan saturasi dan ketajaman
    const finalBuffer = await sharp(enhancedBuffer)
      .modulate({
        saturation: 1.3     // +30% warna
      })
      .sharpen()            // pertajam otomatis
      .jpeg({ quality: 100 })
      .toBuffer();
      
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const enhancedBuffer2 = await processing(finalBuffer, command);
    
    const finalBuffer2 = await sharp(enhancedBuffer2)
      .modulate({
        saturation: 1.3     // +30% warna
      })
      .sharpen()            // pertajam otomatis
      .jpeg({ quality: 100 })
      .toBuffer();
      
    await conn.sendMessage(m.chat, {
      image: finalBuffer2,
      caption: "✅ Nih Kak! Sudah di-HD-kan, disaturasi & dipertajam ✨"
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    await m.reply("❌ Gagal memproses gambar. Coba lagi ya kak.");
  } finally {
    delete conn[sessionKey][m.sender];
  }
};

handler.help = ["reply/caption"];
handler.tags = ["tools"];
handler.command = ["hd", "hdr", "color"];

module.exports = handler;