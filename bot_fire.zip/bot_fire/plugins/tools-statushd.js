const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

let handler = async (m, { conn, quoted }) => {
    const mime = (quoted.msg || quoted).mimetype || "";
    const qmsg = (quoted.msg || quoted);
    const isDocument = quoted?.mtype === "documentMessage";

    if (!m.quoted) {
        return m.reply(`❌ Harap reply file *gambar/video* dalam bentuk *document*.\nContoh: *reply gambar lalu ketik .statushd*`);
    }

    if (!isDocument) {
        return m.reply("❌ File harus berupa *document* (gambar/video), bukan kiriman langsung.");
    }

    m.reply("*`[ WAIT ]`* Sedang memproses file Anda...");

    if (/image/.test(mime) || /video/.test(mime)) {
        try {
            const size = Number(qmsg.fileLength || 0);
            if (!size || size > 7340032) {
                return m.reply("❌ Error: Ukuran file *maksimal* adalah 7MB!");
            }

            const media = await conn.downloadMediaMessage(qmsg);
            const tmpDir = path.join(__dirname, "../all/tmp");
            if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

            const ext = mime.includes("image") ? "jpg" : "mp4";
            const tempFile = path.join(tmpDir, `${Date.now()}.${ext}`);
            fs.writeFileSync(tempFile, media);

            if (/video/.test(mime)) {
                const compressedFile = tempFile.replace(".mp4", "-compressed.mp4");

                try {
                    await compressVideoHD(tempFile, compressedFile);

                    if (!fs.existsSync(compressedFile)) {
                        return m.reply("❌ Gagal memproses file video (hasil tidak ditemukan).");
                    }

                    await conn.sendMessage(m.chat, {
                        video: fs.readFileSync(compressedFile),
                        caption: "✅ *Video Tanpa Kompres WhatsApp*\n\nSilakan bagikan ke status tanpa kehilangan kualitas.",
                    });
                } catch (err) {
                    console.error("❌ Error saat kompresi video:", err);
                    return m.reply("❌ Gagal mengompresi video.");
                } finally {
                    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                    if (fs.existsSync(compressedFile)) fs.unlinkSync(compressedFile);
                }
            } else if (/image/.test(mime)) {
                try {
                    await conn.sendMessage(m.chat, {
                        image: fs.readFileSync(tempFile),
                        caption: "✅ *Gambar Tanpa Kompres WhatsApp*\n\nSilakan bagikan ke status tanpa kehilangan kualitas.",
                    });
                } catch (err) {
                    console.error("❌ Error saat kirim gambar:", err);
                    return m.reply("❌ Gagal mengirim gambar.");
                } finally {
                    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                }
            }
        } catch (e) {
            console.error("❌ ERROR UMUM:", e);
            m.reply("❌ Terjadi kesalahan saat memproses file.");
        }
    } else {
        return m.reply(`❌ Harap reply file *gambar/video* dalam bentuk *document*.\nMaksimal *7MB*`);
    }
};

handler.help = ["reply"];
handler.tags = ["tools"];
handler.command = ["statushd"];
module.exports = handler;

async function compressVideoHD(inputPath, outputPath) {
    return new Promise((resolve, reject) => {
        const ffmpeg = "ffmpeg";
        const args = [
            "-i", inputPath,
            "-c:v", "libx264",
            "-preset", "medium",
            "-crf", "18",
            "-c:a", "aac",
            "-b:a", "192k",
            "-movflags", "+faststart",
            outputPath,
        ];

        const process = spawn(ffmpeg, args);

        process.on("close", (code) => {
            if (code === 0) resolve();
            else reject(new Error(`ffmpeg exited with code ${code}`));
        });

        process.on("error", (err) => reject(err));
    });
}