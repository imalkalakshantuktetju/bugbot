const fs = require('fs')
const path = require('path')
const os = require('os')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const { Image } = require('node-webpmux')
const axios = require('axios')

async function videoToWebp(mediaBuffer) {
  const tmpIn = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.mp4')
  const tmpOut = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')

  fs.writeFileSync(tmpIn, mediaBuffer)

  await new Promise((resolve, reject) => {
    ffmpeg(tmpIn)
      .inputOptions(['-t 10']) 
      .videoFilters([
        'scale=iw*min(512/iw\\,512/ih):ih*min(512/iw\\,512/ih)',
        'pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000'
      ])
      .outputOptions([
        '-vcodec', 'libwebp',
        '-lossless', '1',
        '-preset', 'default',
        '-an',
        '-vsync', '0',
        '-s', '512:512',
        '-loop', '0',
        '-ss', '0'
      ])
      .toFormat('webp')
      .on('end', resolve)
      .on('error', reject)
      .save(tmpOut)
  })

  const buff = fs.readFileSync(tmpOut)
  fs.unlinkSync(tmpIn)
  fs.unlinkSync(tmpOut)
  return buff
}

async function imageToWebp(mediaBuffer) {
  const tmpIn = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.png')
  const tmpOut = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')

  fs.writeFileSync(tmpIn, mediaBuffer)

  await new Promise((resolve, reject) => {
    ffmpeg(tmpIn)
      .on('error', reject)
      .on('end', resolve)
      .outputOptions([
        '-vcodec', 'libwebp',
        '-vf', "scale=iw*min(512/iw\\,512/ih):ih*min(512/iw\\,512/ih),pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000",
        '-lossless', '1',
        '-preset', 'default',
        '-pix_fmt', 'yuva420p',
        '-an',
        '-vsync', '0'
      ])
      .toFormat('webp')
      .save(tmpOut)
  })

  const buff = fs.readFileSync(tmpOut)
  fs.unlinkSync(tmpIn)
  fs.unlinkSync(tmpOut)
  return buff
}

async function writeExifVid(mediaBuffer, metadata = {}) {
  const webpBuffer = await videoToWebp(mediaBuffer)
  const tmpIn = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')
  const tmpOut = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')

  fs.writeFileSync(tmpIn, webpBuffer)

  const json = {
    'sticker-pack-id': 'https://github.com/catozolala',
    'sticker-pack-name': metadata.packname || '',
    'sticker-pack-publisher': metadata.author || '',
    'emojis': metadata.categories || ['']
  }
  const exifAttr = Buffer.from([
    0x49, 0x49, 0x2A, 0x00,
    0x08, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x41, 0x57,
    0x07, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x16, 0x00,
    0x00, 0x00
  ])
  const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8')
  const exif = Buffer.concat([exifAttr, jsonBuff])
  exif.writeUIntLE(jsonBuff.length, 14, 4)

  const img = new Image()
  await img.load(tmpIn)
  img.exif = exif
  await img.save(tmpOut)
  fs.unlinkSync(tmpIn)
  return fs.readFileSync(tmpOut)
}

async function writeExifImg(media, metadata = {}) {
  const wMedia = await imageToWebp(media)
  const tmpIn = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')
  const tmpOut = path.join(os.tmpdir(), crypto.randomBytes(6).toString('hex') + '.webp')

  fs.writeFileSync(tmpIn, wMedia)

  if (metadata.packname || metadata.author) {
    const img = new Image()
    const json = {
      'sticker-pack-id': 'https://github.com/catozolala',
      'sticker-pack-name': metadata.packname || '',
      'sticker-pack-publisher': metadata.author || '',
      'emojis': metadata.categories || ['']
    }
    const exifAttr = Buffer.from([
      0x49, 0x49, 0x2A, 0x00,
      0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57,
      0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00,
      0x00, 0x00
    ])
    const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8')
    const exif = Buffer.concat([exifAttr, jsonBuff])
    exif.writeUIntLE(jsonBuff.length, 14, 4)

    await img.load(tmpIn)
    img.exif = exif
    await img.save(tmpOut)
    fs.unlinkSync(tmpIn)
    return fs.readFileSync(tmpOut)
  } else {
    return wMedia
  }
}

const sendVideoAsSticker = async (conn, jid, path, quoted, options = {}) => {
  let buff = Buffer.isBuffer(path)
    ? path
    : /^data:.*?\/.*?;base64,/i.test(path)
    ? Buffer.from(path.split(',')[1], 'base64')
    : /^https?:\/\//.test(path)
    ? await getBuffer(path)
    : fs.existsSync(path)
    ? fs.readFileSync(path)
    : Buffer.alloc(0)

  let buffer
  if (options && (options.packname || options.author)) {
    buffer = await writeExifVid(buff, options)
  } else {
    buffer = await videoToWebp(buff)
  }

  await conn.sendMessage(jid, { sticker: buffer, ...options }, { quoted })
  return buffer
}

async function sendImageAsSticker(conn, jid, media, quoted, options = {}) {
  let buffer
  if (Buffer.isBuffer(media)) {
    buffer = media
  } else if (typeof media === 'string') {
    if (/^data:.*?\/.*?;base64,/i.test(media)) {
      buffer = Buffer.from(media.split(',')[1], 'base64')
    } else if (/^https?:\/\//.test(media)) {
      buffer = await getBuffer(media)
    } else if (fs.existsSync(media)) {
      buffer = fs.readFileSync(media)
    } else {
      throw new Error('Media string tidak valid')
    }
  } else {
    throw new Error('Media tidak valid')
  }

  const webpSticker = await writeExifImg(buffer, {
    packname: options.packname || 'Sticker Pack',
    author: options.author || 'by Catozolala',
    categories: options.categories || ['']
  })

  await conn.sendMessage(jid, { sticker: webpSticker, ...options }, { quoted })
  return webpSticker
}

async function getBuffer(url) {
  const res = await axios.get(url, { responseType: 'arraybuffer' })
  return Buffer.from(res.data, 'binary')
}

let handler = async (m, {conn, cmd}) => {
  try {
  
    let quotedMsg = m.quoted ? (m.quoted.message || m.quoted) : m.message.imageMessage || null
    let messageMedia = quotedMsg || m.message

    let mime = messageMedia.mimetype || ''

    const isImage = mime.startsWith('image/')
    const isVideo = mime.startsWith('video/')

    if (isImage) {
      const data = await conn.downloadMediaMessage(messageMedia)
      await sendImageAsSticker(conn, m.chat, data, m, {
        packname: 'Anime Pack',
        author: 'Catozolala',
        categories: ['🔥', '✨']
      })
    } else if (isVideo) {
      if (quotedMsg.seconds > 10) return m.reply('*Maksimal Durasi 10 detik!*')

      const data = await conn.downloadMediaMessage(messageMedia)
      await sendVideoAsSticker(conn, m.chat, data, m, {
        packname: 'Anime Pack',
        author: 'Catozolala',
        categories: ['🔥', '✨']
      })
    } else {
      copyMessage(m, conn, `<reply gambar/video/gif>\nDurasi Video/Gif 1-10 Detik`, cmd)
    }
  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: `Error: ${err.message}` }, { quoted: m })
  }
}

async function copyMessage(m, conn, teks, copyTeks) {
  let msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: teks
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_copy",
                  buttonParamsJson: `{\"display_text\":\"Copy Command\",\"id\":\"123456789\",\"copy_code\":\"${copyTeks}\"}`
                }
              ]
            }
          }
        }
      }
    },
    { quoted: m }
  );

  await conn.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id,
  });
}

handler.command = ['sticker', 's'];
handler.tags = ['tools'];

module.exports = handler;