const convertESMtoCJS = (esmCode) => {
    esmCode = esmCode.replace(/import\s+([\w${}*,\s]+)\s+from\s+['"](.+?)['"];?/g, (match, p1, p2) => {
        return `const ${p1.trim()} = require('${p2}');`;
    });

    esmCode = esmCode.replace(/export\s+default\s+/g, 'module.exports = ');

    esmCode = esmCode.replace(/export\s+const\s+(\w+)\s+=/g, 'exports.$1 =');

    return esmCode;
};

const handler = async (m, { text }) => {
    if (!text && !m.quoted?.text) {
        return m.reply('Masukkan Code ESM Yang Ingin Di Convert Ke CJS.');
    }

    try {
        const cjsCode = convertESMtoCJS(text || m.quoted.text);
        m.reply(`${cjsCode}`);
    } catch (error) {
        console.error('Error Convert Code ESM To CJS:', error);
        m.reply('Ada Yang Error Om, Cek Lagi Code-nya.');
    }
};

handler.tags = ['tools'];
handler.command = ['tocjs'];
handler.help = ['tocjs'];

module.exports = handler;