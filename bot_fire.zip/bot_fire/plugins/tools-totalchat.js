const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

function getGroupAndPrivateChats(store) {
  const chats = Object.values(store.chats || {});
  
  const groupChats = chats.filter(chat => chat.id && chat.id.endsWith('@g.us'));
  const privateChats = chats.filter(chat => chat.id && chat.id.endsWith('@s.whatsapp.net'));
  
  return { groupChats, privateChats };
}

let handler = async (m, { conn, store }) => {
  try {
    const { groupChats, privateChats } = getGroupAndPrivateChats(store);

    const response = `*[ CHAT STATISTIK BOT ]*\n\n` +
      `• Grup: ${groupChats.length}\n` +
      `• Pribadi: ${privateChats.length}\n` +
      `• Total: ${groupChats.length + privateChats.length}`;

    await conn.sendMessage(m.chat, { text: response }, { quoted: m });
  } catch (error) {
    console.error('Error:', error);
    await conn.sendMessage(m.chat, { text: 'Terjadi kesalahan saat menghitung total chat.' }, { quoted: m });
  }
};

handler.help = ['totalchat'];
handler.tags = ['info'];
handler.command = ["totalchat"];

module.exports = handler;