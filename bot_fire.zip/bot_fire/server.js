const express = require('express')
const http = require('http')
const { toBuffer } = require('qrcode')
const fetch = require('node-fetch')

function connect(conn, PORT, opts = {}) {
    const app = global.app = express()
    const server = global.server = http.createServer(app)
    let _qr = 'invalid'

    conn.ev.on('connection.update', function appQR({ qr }) {
        if (qr) _qr = qr
    })

    app.use(async (req, res) => {
        res.setHeader('content-type', 'image/png')
        res.end(await toBuffer(_qr))
    })

    // Uncomment untuk aktifkan Socket.IO
    // const { Server } = require('socket.io')
    // const io = new Server(server)
    // io.on('connection', socket => {
    //     const { unpipeEmit } = pipeEmit(conn, socket, 'conn-')
    //     socket.on('disconnect', unpipeEmit)
    // })

    server.listen(PORT, () => {
        console.log('App listened on port', PORT)
        if (opts.keepalive) keepAlive()
    })
}

function pipeEmit(event, event2, prefix = '') {
    const old = event.emit
    event.emit = function (eventName, ...args) {
        old.call(event, eventName, ...args)
        event2.emit(prefix + eventName, ...args)
    }
    return {
        unpipeEmit() {
            event.emit = old
        }
    }
}

function keepAlive() {
    const url = `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
    if (/(\/\/|\.)undefined\./.test(url)) return
    setInterval(() => {
        fetch(url).catch(console.error)
    }, 5 * 60 * 1000)
}

module.exports = connect