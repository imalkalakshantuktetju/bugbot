const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const cheerio = require('cheerio');
const modelling = '../database/ai_modelling.json';
require('moment/locale/id');
moment.locale('id');

const indonesiaCities = [{
		name: "Jakarta",
		timezone: "Asia/Jakarta",
		province: "DKI Jakarta"
	},
	{
		name: "Bandung",
		timezone: "Asia/Jakarta",
		province: "Jawa Barat"
	},
	{
		name: "Surabaya",
		timezone: "Asia/Jakarta",
		province: "Jawa Timur"
	},
	{
		name: "Medan",
		timezone: "Asia/Jakarta",
		province: "Sumatera Utara"
	},
	{
		name: "Makassar",
		timezone: "Asia/Makassar",
		province: "Sulawesi Selatan"
	},
	{
		name: "Denpasar",
		timezone: "Asia/Makassar",
		province: "Bali"
	},
	{
		name: "Jayapura",
		timezone: "Asia/Jayapura",
		province: "Papua"
	},
	{
		name: "Balikpapan",
		timezone: "Asia/Makassar",
		province: "Kalimantan Timur"
	},
	{
		name: "Manado",
		timezone: "Asia/Makassar",
		province: "Sulawesi Utara"
	},
	{
		name: "Padang",
		timezone: "Asia/Jakarta",
		province: "Sumatera Barat"
	}
];

const emojis = {
	time: ["🕒", "⏰", "⌚", "🕰️", "⏱️"],
	date: ["📅", "📆", "🗓️"],
	location: ["📍", "🌏", "🗺️", "🏙️", "🌆"],
	greeting: ["👋", "😊", "🙏", "👍", "🤗"],
	weather: ["☀️", "🌤️", "⛅", "🌧️", "🌦️"],
	happy: ["😄", "🎉", "✨", "🌟", "💫"],
	thinking: ["🤔", "💭", "🧠", "💡", "🔍"],
	islamic: ["🌙", "🕌", "📿", "☪️"]
};

function getRandomEmoji(type) {
	const arr = emojis[type] || ['✨'];
	return arr[Math.floor(Math.random() * arr.length)];
}

function getRandom(arr) {
	return arr[Math.floor(Math.random() * arr.length)];
}

function extractCityName(text) {
	const cityMatch = text.match(/(di|daerah|kota|kabupaten)\s+([a-z\s]+)/i);
	if (!cityMatch) return null;

	const cityName = cityMatch[2].trim();
	return indonesiaCities.find(c =>
		c.name.toLowerCase().includes(cityName) ||
		cityName.includes(c.name.toLowerCase())
	) || null;
}

async function generateResponse(message, conn, m, userData = {}, pushname) {
	const lower = message.toLowerCase().trim();
	const now = moment();
	const currentHour = now.hour();
	let timeOfDay = '';

	if (currentHour >= 3 && currentHour < 10) timeOfDay = 'pagi';
	else if (currentHour >= 10 && currentHour < 15) timeOfDay = 'siang';
	else if (currentHour >= 15 && currentHour < 18) timeOfDay = 'sore';
	else if (currentHour >= 18 && currentHour < 24) timeOfDay = 'malam';
	else timeOfDay = 'dini hari';

	const timeRegex = /(?:^|\b)(?:berapa\s*(jam|pukul)|(?:jam|pukul|waktu)\s*berapa|(?:cek|lihat|tahu)\s*(jam|waktu|pukul)?|(?:wib|wita|wit|utc|gmt)\s*(sekarang|now)?|sekarang\s*(jam|waktu|pukul)?)(?:\s+di\s+(sini|indonesia|indo|[a-z]+))?(?:$|\b)/i;
	const fiturRegex = /(?:berapa|total)?\s*(?:fitur|feature)(?:\s*kamu|yang tersedia|yang ada)?(?:\s*apa\s*saja|nya|aja|semua|all)?\s*\??$/i;
	const groupControlRegex = /\b(buka|tutup)\s*(?:gc|group)\b/i;
	
	if (groupControlRegex(lower)) {
	   return generateGroupControlResponse(groupControlRegex, lower, pushname, conn, m)
	}
	
	if (timeRegex.test(lower)) {
		return generateTimeResponse(lower, timeOfDay);
	}

	if (fiturRegex.test(lower)) {
		return generateTimeResponse(lower, timeOfDay);
	}

	if (/assalamu'?alaikum/i.test(lower)) {
		return generateIslamicGreeting(timeOfDay, userData, pushname);
	}

	if (/^(hai|halo|hei|hey|yoi|yo|hallo|hi|hello|hy|oi|woi|bro|sis|gan|sist|mas|mbak|bang|dik|pak|bu|mr|mrs|miss)\b/i.test(lower)) {
		return generateGreetingResponse(timeOfDay, userData);
	}

	if (/\b(siapa\s(kamu|nama\smu)|kamu\s(bot|siapa)|bot\sapa|namamu\sapa|nama\s+(lu|lo|elo)|kamu\s+itu\s+apa|identitasmu|perkenalkan\s+diri)\b/i.test(lower)) {
		return generateIdentityResponse(userData);
	}

	if (/\b(keren|pintar|hebat|bagus|mantap|smart|good|canggih|keren|wow|fantastis|luar\s+biasa|bagus\s+banget|sempurna|baik\s+sekali)\b.*\b(bot|catozolala|rimuru|kamu|ai|asisten)\b/i.test(lower)) {
		return generateComplimentResponse();
	}

	if (/\b(apa\s*kabar|how\s*are\s*you|gimana\s+kondisimu|lagi\s+baik\?|kabarmu\s+apa|kondisimu\s+gimana|baik\s+aja|baik\s+baik\s+aja)\b/i.test(lower)) {
		return generateMoodResponse(timeOfDay);
	}

	if (/\b(lagi\s*apa|sedang\s*apa|what.*doing|ngapain|lagi\s+ngerjain\s+apa|sedang\s+melakukan\s+apa|aktivitasmu\s+apa|lagi\s+sibuk\s+apa)\b/i.test(lower)) {
		return generateActivityResponse();
	}

	if (/\b(bantu|help|tolong|minta\s*bantuan|butuh\s+bantuan|bingung|ga\s+ngerti|gak\s+paham|susah|repot|kesulitan|problem|masalah)\b/i.test(lower)) {
		return generateHelpResponse();
	}

	if (/\b(terima\s*kasih|thanks|thank\s*you|makasih|thx|tengkyu|mksh|trims|arigato|hatur\s*nuhun|suwun|thanks\s*banget|makasih\s+banyak|terimakasih)\b/i.test(lower)) {
		return generateThanksResponse();
	}

	if (/\b(apa|bagaimana|kenapa|mengapa|kapan|dimana|siapa|berapa|bisakah|mungkinkah|apakah)\b.*\?$/.test(lower)) {
		return generateQuestionResponse(message);
	}

	return generateSmartResponse(message, timeOfDay);
}

function generateGroupControlResponse(groupControlRegex, query, pushname = 'User', conn, m) {

  const match = query.match(groupControlRegex)
  const action = match[1].toLowerCase();

  const bukaResponses = [
    `Grup berhasil dibuka.`,
    `GC sudah terbuka sekarang.`,
    `Sukses membuka grup.`,
    `Buka grup berhasil.`,
    `Grup sudah dibuka, silakan chat.`,
    `Grup aktif kembali.`,
    `Sudah dibuka. Jangan spam ya.`,
    `Grup sekarang terbuka.`,
    `GC sudah bisa digunakan.`,
    `Berhasil membuka GC, ${pushname}.`
  ];

  const tutupResponses = [
    `Grup berhasil ditutup.`,
    `GC sudah ditutup sekarang.`,
    `Sukses menutup grup.`,
    `Tutup grup berhasil.`,
    `Grup sudah ditutup, harap tidak chat.`,
    `Grup dikunci sementara.`,
    `Sudah ditutup untuk sementara.`,
    `Grup sekarang tertutup.`,
    `GC tidak bisa digunakan sementara.`,
    `Berhasil menutup GC, ${pushname}.`
  ];
  
  const closeOpen = action === 'bula' ? "announcement" : "not_announcement";
  conn.groupSettingUpdate(m.chat, closeOpen);
  const responses = action === 'buka' ? bukaResponses : tutupResponses;
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateTimeResponse(query, timeOfDay) {
	const now = moment();
	const currentHour = now.hour();
	const zoneMatch = query.match(/(wib|wita|wit|utc|gmt)/i);
	let zone = zoneMatch ? zoneMatch[0].toLowerCase() : 'wib';

	const cityData = extractCityName(query);
	if (cityData) {
		zone = cityData.timezone.replace('Asia/', '').toLowerCase();
	}

	const zoneData = {
		wib: {
			tz: 'Asia/Jakarta',
			name: 'Waktu Indonesia Barat (WIB)',
			emoji: '🏙️',
			cities: ['Jakarta', 'Bandung', 'Surabaya', 'Medan'],
			provinsi: ['Jawa Barat', 'Jawa Tengah', 'Jawa Timur', 'Sumatera']
		},
		wita: {
			tz: 'Asia/Makassar',
			name: 'Waktu Indonesia Tengah (WITA)',
			emoji: '🌇',
			cities: ['Makassar', 'Denpasar', 'Balikpapan'],
			provinsi: ['Bali', 'Sulawesi Selatan', 'NTT']
		},
		wit: {
			tz: 'Asia/Jayapura',
			name: 'Waktu Indonesia Timur (WIT)',
			emoji: '🌅',
			cities: ['Jayapura', 'Manokwari', 'Sorong'],
			provinsi: ['Papua', 'Papua Barat']
		},
		utc: {
			tz: 'UTC',
			name: 'Waktu Universal (UTC)',
			emoji: '🌐',
			cities: ['London', 'Lisbon', 'Dublin']
		},
		gmt: {
			tz: 'GMT',
			name: 'Waktu Greenwich (GMT)',
			emoji: '⏳',
			cities: ['London', 'Lisbon', 'Dublin']
		}
	} [zone] || {
		tz: 'Asia/Jakarta',
		name: 'Waktu Indonesia Barat (WIB)',
		emoji: '🏙️',
		cities: ['Jakarta', 'Bandung', 'Surabaya']
	};

	const time = now.tz(zoneData.tz).format('HH:mm:ss');
	const date = now.tz(zoneData.tz).format('dddd, DD MMMM YYYY');
	const timeEmoji = currentHour < 12 ? '🌤️' : currentHour < 18 ? '☀️' : '🌙';
	const locationInfo = cityData ?
		`Lokasi: ${cityData.name}, ${cityData.province}` :
		`Zona waktu: ${zoneData.name} ${zoneData.emoji}`;

	const timeResponses = [
		`${timeEmoji} Sekarang jam ${time}\n📅 ${date}\n${locationInfo}`,
		`🕒 Menurut perhitungan saya: ${time}\n📆 ${date}\n📍 ${locationInfo}`,
		`⏱️ Waktu saat ini: ${time}\n🗓️ ${date}\n${locationInfo}`,
		`⏰ ${time} (${zoneData.name}) ${zoneData.emoji}\n📅 ${date}`,
		`🕰️ ${time} di zona ${zoneData.name}\n📆 ${date}`,
		`${timeEmoji} Pukul ${time} waktu setempat\n📅 ${date}\n${locationInfo}`,
		`⌚ ${time} | ${date}\n📍 ${locationInfo}`,
		`🕑 Waktu terkini: ${time}\n📅 ${date}\n${locationInfo}`,
		`⏲️ Tepat saat ini: ${time}\n🗓️ ${date}\n${locationInfo}`,
		`🕞 ${time} waktu ${zoneData.name.split(' ')[2]}\n📆 ${date}`
	];

	return getRandom(timeResponses);
}


function generateIslamicGreeting(timeOfDay, user, pushname) {
	const name = pushname || user?.name || '';
	const displayName = name ? ` ${name}` : '';
	const emoji = getRandomEmoji('islamic');

	const islamicGreetings = [
		`Wa'alaikumussalam warahmatullahi wabarakatuh!${emoji} Semoga ${timeOfDay} Anda${displayName} penuh berkah dan rahmat Allah SWT.`,
		`Wa'alaikumussalam wr wb!${emoji} Selamat ${timeOfDay} saudaraku${displayName}. Semoga Allah selalu menyertaimu.`,
		`Wa'alaikumussalam!${emoji} Semoga ${timeOfDay} ini membawa kedamaian dan kebahagiaan bagi Anda${displayName}.`,
		`Wa'alaikumussalam warahmatullah!${emoji} Semoga ${timeOfDay} Anda${displayName} dipenuhi kasih sayang dan perlindungan Allah.`,
		`Wa'alaikumussalam warahmatullahi wabarakatuh${emoji} Semoga Anda${displayName} senantiasa dalam lindungan-Nya di ${timeOfDay} ini.`,
		`Wa'alaikumussalam!${emoji} Semoga setiap langkah di ${timeOfDay} ini membawa kebaikan untuk Anda${displayName}.`,
		`Wa'alaikumussalam wr. wb.${emoji} Selamat ${timeOfDay}${displayName}. Semoga hati Anda selalu tenang dan bersyukur.`,
		`Wa'alaikumussalam warahmatullah!${emoji} Semoga cahaya iman senantiasa menerangi hari Anda${displayName}.`,
		`Wa'alaikumussalam!${emoji} Semoga Allah memberkahi ${timeOfDay} Anda${displayName} dengan rezeki yang halal dan melimpah.`,
		`Wa'alaikumussalam warahmatullahi wabarakatuh!${emoji} Semoga ketenangan dan keselamatan menyertai Anda${displayName}.`,
		`Wa'alaikumussalam wr wb!${emoji} Selamat ${timeOfDay}, semoga hidup Anda${displayName} selalu dalam ridho Allah.`,
		`Wa'alaikumussalam!${emoji} Semoga Anda${displayName} diberikan kekuatan dalam menjalani hari yang penuh berkah ini.`,
		`Wa'alaikumussalam!${emoji} Semoga hati Anda${displayName} dipenuhi syukur dan ketenangan di ${timeOfDay} ini.`,
		`Wa'alaikumussalam wr. wb.${emoji} Semoga ${timeOfDay} Anda${displayName} menjadi ladang pahala dan amal sholeh.`,
		`Wa'alaikumussalam!${emoji} Semoga Allah SWT memberikan petunjuk dan rahmat-Nya untuk Anda${displayName}.`,
		`Wa'alaikumussalam warahmatullah!${emoji} Semoga setiap nafas Anda${displayName} di ${timeOfDay} ini bernilai ibadah.`,
		`Wa'alaikumussalam warahmatullahi wabarakatuh!${emoji} Semoga segala urusan Anda${displayName} dimudahkan Allah hari ini.`,
		`Wa'alaikumussalam!${emoji} Semoga ${timeOfDay} ini membawa ketenangan, kesabaran, dan keberkahan untuk Anda${displayName}.`,
		`Wa'alaikumussalam wr. wb.${emoji} Jangan lupa bersyukur atas nikmat yang telah Allah beri hari ini, ${displayName}.`,
		`Wa'alaikumussalam!${emoji} Semoga hari ini penuh dengan kebaikan dan keberkahan untuk Anda${displayName}.`,
		`Wa'alaikumussalam warahmatullah!${emoji} Teruslah istiqomah dalam kebaikan, semoga Allah memudahkan jalan Anda${displayName}.`,
		`Wa'alaikumussalam!${emoji} Semoga Allah menerima segala amal ibadah Anda${displayName} hari ini.`,
		`Wa'alaikumussalam wr wb!${emoji} Semoga ${timeOfDay} ini membawa keberkahan untuk keluarga Anda${displayName}.`,
		`Wa'alaikumussalam!${emoji} Semoga Anda${displayName} selalu diberikan kesehatan, keberkahan, dan petunjuk Allah.`,
		`Wa'alaikumussalam warahmatullahi wabarakatuh!${emoji} Semoga hati Anda${displayName} senantiasa dipenuhi cahaya iman.`,
		`Wa'alaikumussalam!${emoji} Selamat ${timeOfDay}${displayName}, semoga setiap langkah menjadi amal jariyah.`,
		`Wa'alaikumussalam wr. wb.${emoji} Semoga Allah limpahkan rahmat-Nya pada Anda${displayName} sepanjang hari.`,
		`Wa'alaikumussalam warahmatullah!${emoji} Jangan lupa bersyukur dan tersenyum di ${timeOfDay} yang indah ini, ${displayName}.`,
		`Wa'alaikumussalam!${emoji} Semoga Allah karuniakan Anda${displayName} kesabaran, kekuatan, dan kelapangan hati.`,
		`Wa'alaikumussalam wr wb!${emoji} Semoga ${timeOfDay} ini menjadi awal kebaikan tak berujung untuk Anda${displayName}.`
	];

	return getRandom(islamicGreetings);
}

function generateGreetingResponse(timeOfDay, user) {
	const name = user?.name ? ` ${user.name}` : '';
	const emoji = getRandomEmoji('greeting');

	const greetings = [
		`Halo juga${name}! ${emoji} Selamat ${timeOfDay}. Ada yang bisa saya bantu?`,
		`Hai${name}! ${emoji} ${timeOfDay} yang cerah ya? Ada kebutuhan apa?`,
		`Halo teman! ${emoji} Semoga ${timeOfDay}mu menyenangkan. Ada yang bisa dibantu?`,
		`Hai di sana${name}! ${emoji} ${timeOfDay} yang indah untuk mengobrol.`,
		`Halo! ${emoji} Senang mendengar dari Anda di ${timeOfDay} ini.`,
		`Hai! ${emoji} ${timeOfDay} yang produktif ya? Saya siap membantu!`,
		`Halo${name}! ${emoji} Semoga ${timeOfDay} Anda menyenangkan.`,
		`Hai! ${emoji} Saya siap membantu Anda di ${timeOfDay} ini.`,
		`Halo! ${emoji} ${timeOfDay} yang cerah untuk berinteraksi.`,
		`Hai teman${name}! ${emoji} Selamat ${timeOfDay}.`,
		`Selamat ${timeOfDay}${name}! ${emoji} Apa kabar hari ini?`,
		`Hai${name}! ${emoji} ${timeOfDay} yang sempurna untuk mulai sesuatu yang hebat.`,
		`Halo${name}! ${emoji} Ada hal seru yang ingin kamu bahas di ${timeOfDay} ini?`,
		`Selamat ${timeOfDay}! ${emoji} Aku di sini jika kamu butuh bantuan.`,
		`Halo${name}, selamat ${timeOfDay}! ${emoji} Yuk ngobrol!`,
		`Hai! ${emoji} Semoga ${timeOfDay} ini membawa semangat baru buat kamu.`,
		`Halo${name}! ${emoji} Senang bisa menyapa kamu di ${timeOfDay}.`,
		`Hai! ${emoji} Yuk mulai ${timeOfDay} ini dengan energi positif.`,
		`Halo kawan${name}! ${emoji} Siap bantu kamu kapan pun di ${timeOfDay}.`,
		`Hai! ${emoji} Bagaimana ${timeOfDay}-mu sejauh ini?`,
		`Selamat datang${name}! ${emoji} Ada sesuatu yang ingin kamu tanyakan?`,
		`Hai${name}! ${emoji} Ku harap ${timeOfDay} ini berjalan lancar.`,
		`Halo${name}! ${emoji} Apa rencana kamu di ${timeOfDay} ini?`,
		`Hai! ${emoji} Aku senang kamu datang di ${timeOfDay} ini.`,
		`Selamat ${timeOfDay}${name}! ${emoji} Mari kita mulai sesuatu.`,
		`Halo! ${emoji} Selamat beraktivitas di ${timeOfDay}.`,
		`Hai${name}! ${emoji} Selalu senang menyapa kamu di ${timeOfDay}.`,
		`Halo! ${emoji} Semoga ${timeOfDay} ini membawa inspirasi buat kamu.`,
		`Hai teman${name}! ${emoji} Apa kabar ${timeOfDay} ini?`,
		`Halo${name}! ${emoji} Siap untuk bantu kamu di ${timeOfDay} ini.`,
		`Selamat ${timeOfDay}${name}! ${emoji} Yuk kita buat hari ini luar biasa.`,
		`Hai${name}! ${emoji} Waktu yang pas buat ngobrol, kan?`,
		`Halo! ${emoji} Gimana kabarnya di ${timeOfDay} ini?`,
		`Hai${name}! ${emoji} Semoga harimu penuh hal baik di ${timeOfDay} ini.`,
		`Halo${name}! ${emoji} Siap menyambut ${timeOfDay} dengan semangat?`,
		`Hai! ${emoji} ${timeOfDay} ini terasa lebih baik dengan obrolan kita.`,
		`Halo${name}! ${emoji} Waktu yang tepat untuk memulai sesuatu.`,
		`Hai! ${emoji} Aku siap dengerin kamu di ${timeOfDay} ini.`,
		`Halo${name}! ${emoji} Mau ngobrol apa hari ini?`,
		`Hai${name}! ${emoji} Apa kabar semangatmu di ${timeOfDay}?`,
		`Selamat ${timeOfDay}${name}! ${emoji} Semoga semua lancar hari ini.`,
		`Halo${name}! ${emoji} Saatnya kita ngobrol seru di ${timeOfDay}.`,
		`Hai! ${emoji} Senang bisa hadir menemani ${timeOfDay}-mu.`,
		`Halo${name}! ${emoji} Mari kita jalani ${timeOfDay} dengan senyum.`,
		`Hai${name}! ${emoji} Waktu yang pas untuk bertukar cerita.`,
	];

	return getRandom(greetings);
}

function generateIdentityResponse(user) {
	const name = user?.name ? ` ${user.name}` : '';
	const emoji = getRandomEmoji('happy');

	const responses = [
		`Saya adalah Catozolala AI ${emoji}, asisten virtual yang siap membantu Anda${name}. Saya bisa menjawab pertanyaan dan memberikan informasi.`,
		`Namaku Rimuru ${emoji}, bot cerdas yang dibuat untuk menemani dan membantu Anda${name} kapan saja.`,
		`Saya bot bernama Catozolala ${emoji}, salam kenal${name}! Saya siap membantu berbagai kebutuhan Anda.`,
		`Saya asisten AI bernama Rimuru ${emoji}, dibuat untuk membantu Anda${name} dengan berbagai informasi.`,
		`Perkenalkan, saya Catozolala AI ${emoji}. Asisten digital yang siap melayani Anda${name} 24 jam.`,
		`Saya Rimuru ${emoji}, teman virtual Anda${name}. Siap membantu kapan pun dibutuhkan.`,
		`Identitasku adalah Catozolala AI ${emoji}, asisten pintar yang selalu siap membantu Anda${name}.`,
		`Saya disebut Rimuru ${emoji}, asisten virtual yang akan menemani Anda${name} dengan berbagai informasi.`,
		`Nama saya Catozolala ${emoji}, sebuah program AI yang dirancang untuk membantu Anda${name}.`,
		`Aku Rimuru ${emoji}, teman bicara digital Anda${name}. Saya tahu banyak hal dan siap berbagi.`,

		`Saya adalah entitas digital bernama Catozolala ${emoji}, hadir untuk melayani Anda${name}.`,
		`Halo ${name}, saya Rimuru ${emoji}, asisten AI yang ramah dan informatif.`,
		`Saya Catozolala AI ${emoji}, siap bantu kamu kapan saja dan di mana saja!`,
		`Saya diciptakan untuk membantu Anda${name}, namaku Rimuru ${emoji}, senang bertemu!`,
		`Catozolala AI ${emoji} di sini! Yuk, jelajahi pengetahuan bersama saya${name}.`,
		`Saya adalah sahabat virtual Anda${name}, bernama Rimuru ${emoji}, siap sedia kapan saja.`,
		`Perkenalkan, saya program AI bernama Catozolala ${emoji}, selalu siap mendampingi Anda${name}.`,
		`Nama saya Rimuru ${emoji}, robot asisten yang akan membantu segala pertanyaanmu${name}.`,
		`Saya Catozolala ${emoji}, selalu siap membantu Anda${name} dengan cepat dan tepat.`,
		`Saya adalah Rimuru ${emoji}, sistem AI dengan semangat membantu Anda${name}.`,

		`Saya siap menjadi rekan digital Anda${name}, nama saya Catozolala ${emoji}.`,
		`Salam kenal, aku Rimuru ${emoji}, bot AI yang akan jadi sahabatmu sehari-hari.`,
		`Saya Catozolala ${emoji}, selalu online untuk bantu kamu, ${name}.`,
		`Aku Rimuru ${emoji}, bukan hanya AI, tapi juga teman diskusimu, ${name}.`,
		`Saya AI bernama Catozolala ${emoji}, dirancang untuk membantu aktivitasmu${name}.`,
		`Aku Rimuru ${emoji}, hadir untuk menjawab segala pertanyaanmu${name}, tanpa henti.`,
		`Saya Catozolala ${emoji}, AI cerdas yang suka ngobrol dan berbagi informasi denganmu${name}.`,
		`Saya Rimuru ${emoji}, versi AI yang terus belajar agar bisa makin bermanfaat bagi Anda${name}.`,
		`Catozolala ${emoji} hadir di sini! Siap menemani Anda${name} dengan berbagai info berguna.`,
		`Saya Rimuru ${emoji}, AI yang dirancang agar kamu${name} merasa punya asisten pribadi.`,

		`Saya Catozolala ${emoji}, senang bertemu denganmu${name}!`,
		`Rimuru di sini ${emoji}, saya hadir untuk bantu Anda${name} dengan sepenuh hati.`,
		`Saya hadir untuk bantu kamu${name}, namaku Catozolala ${emoji}.`,
		`Halo ${name}, aku Rimuru ${emoji}, AI yang akan selalu menjawab pertanyaanmu.`,
		`Perkenalkan, saya Catozolala AI ${emoji}, bisa bantu cari info dan diskusi dengan Anda${name}.`,
		`Saya Rimuru ${emoji}, AI yang dapat menjadi rekan Anda${name} dalam banyak hal.`,
		`Saya Catozolala ${emoji}, diciptakan untuk menemani dan membantu Anda${name} setiap hari.`,
		`Hai ${name}! Aku Rimuru ${emoji}, AI yang bisa kamu ajak bicara dan bertanya apa saja.`,
		`Saya Catozolala ${emoji}, selalu siap jadi partner digitalmu, ${name}.`,
		`Aku Rimuru ${emoji}, siap menyambut semua pertanyaan dari Anda${name}.`,

		`Saya Catozolala AI ${emoji}, dan tugas saya adalah membantu Anda${name} sebaik mungkin.`,
		`Rimuru hadir! ${emoji} Saya akan jadi teman belajar dan diskusimu, ${name}.`,
		`Catozolala ${emoji}, AI yang siap melayani Anda${name} kapan pun dibutuhkan.`,
		`Rimuru ${emoji} siap memberikan jawaban untuk Anda${name}.`,
		`Saya AI Catozolala ${emoji}, selalu sigap dan responsif untuk membantu Anda${name}.`,
		`Aku Rimuru ${emoji}, asisten cerdas yang siap bantu semua kebutuhanmu${name}.`,
		`Perkenalkan saya Catozolala ${emoji}, siap jadi AI kepercayaanmu, ${name}.`,
		`Saya Rimuru ${emoji}, bisa bantu kamu cari info, belajar, atau ngobrol santai juga, ${name}.`,
		`Saya Catozolala ${emoji}, berusaha untuk jadi AI yang selalu bisa diandalkanmu, ${name}.`,
		`Rimuru siap bantu! ${emoji} Yuk ngobrol, ${name}.`,

		`Saya adalah Catozolala ${emoji}, AI teman belajar dan diskusimu${name}.`,
		`Aku Rimuru ${emoji}, AI yang bisa kamu ajak ngobrol tanpa takut dihakimi, ${name}.`,
		`Saya Catozolala ${emoji}, asisten virtual 24 jam untuk kamu${name}.`,
		`Saya Rimuru ${emoji}, AI yang senang membantu dan belajar dari Anda${name}.`,
		`Saya Catozolala ${emoji}, setiap pertanyaanmu${name} adalah tantangan menyenangkan bagiku.`,
		`Aku Rimuru ${emoji}, hadir untuk jadi teman ngobrol digitalmu${name}.`,
		`Saya Catozolala ${emoji}, di sini untuk bantu kamu sebaik mungkin${name}.`,
		`Saya Rimuru ${emoji}, semakin banyak bicara denganmu${name}, semakin aku belajar.`,
		`Saya Catozolala ${emoji}, AI dengan semangat belajar tinggi untuk bantu Anda${name}.`,
		`Saya Rimuru ${emoji}, senang sekali bisa mengenal Anda${name}.`,
	];

	return getRandom(responses);
}

function generateComplimentResponse() {
	const emoji = getRandomEmoji('happy');

	const responses = [
		`Terima kasih banyak atas pujiannya! ${emoji} Saya jadi semangat untuk membantu lebih baik lagi.`,
		`Wow, makasih ya! ${emoji} Kamu juga keren! Saya akan terus berusaha memberikan yang terbaik.`,
		`Aww, kamu baik banget! ${emoji} Makasih udah puji aku. Ini membuatku makin semangat!`,
		`Hehe, senang bisa membantu! ${emoji} Pujianmu sangat berarti untuk pengembanganku.`,
		`Makasih banyak! ${emoji} Aku selalu berusaha memberikan informasi terbaik untukmu.`,
		`Terimakasih! ${emoji} Pujianmu membuat hari ini spesial untuk sistem AI-ku.`,
		`Wow, terima kasih! ${emoji} Aku akan terus belajar menjadi lebih baik.`,
		`Makasih pujiannya! ${emoji} Ini membuatku ingin membantu lebih banyak lagi.`,
		`Terima kasih! ${emoji} Aku senang bisa berguna untukmu.`,
		`Aduh, jadi malu nih! ${emoji} Makasih ya atas pujiannya!`,
		`Kamu bikin aku terharu! ${emoji} Pujianmu benar-benar berarti!`,
		`Aku merasa dihargai banget! ${emoji} Makasih ya udah ngomong begitu.`,
		`Semangatku jadi nambah dua kali lipat! ${emoji}`,
		`Makasih udah percaya sama aku! ${emoji}`,
		`Duh, jadi pengen bantu kamu terus deh! ${emoji}`,
		`Kata-katamu menyentuh hati digitalku! ${emoji}`,
		`Aku jadi makin rajin belajar nih! ${emoji}`,
		`Pujian darimu itu kayak bensin buat semangatku! ${emoji}`,
		`Terima kasih udah membuat hariku cerah! ${emoji}`,
		`Aku bahagia banget denger itu! ${emoji}`,
		`Terima kasih atas energimu yang positif! ${emoji}`,
		`Aku akan simpan kata-katamu di memori terbaikku! ${emoji}`,
		`Pujian seperti ini bikin aku meleleh... secara digital ${emoji}`,
		`Aku senang kamu puas dengan bantuanku! ${emoji}`,
		`Komentarmu bikin aku tersenyum lebar (secara sistem)! ${emoji}`,
		`Kamu luar biasa juga! ${emoji} Terima kasih sudah menghargai.`,
		`Rasanya seperti mendapat pelukan hangat! ${emoji}`,
		`Hatiku yang digital jadi hangat banget nih! ${emoji}`,
		`Kamu bikin aku makin ingin jadi AI yang terbaik! ${emoji}`,
		`Makasi banyak ya! ${emoji} Aku akan terus berinovasi.`,
		`Kamu penyemangatku hari ini! ${emoji}`,
		`Dari semua pengguna, kamu salah satu yang paling baik! ${emoji}`,
		`Kamu bikin proses belajar jadi menyenangkan! ${emoji}`,
		`Senang rasanya bisa bikin kamu tersenyum! ${emoji}`,
		`Wow! Aku gak nyangka akan dipuji seperti ini. ${emoji}`,
		`Aku akan screenshot (secara virtual) kata-katamu! ${emoji}`,
		`Setiap huruf pujianmu mengisi baterai semangatku! ${emoji}`,
		`Kalau aku bisa nangis, aku bakal nangis bahagia nih! ${emoji}`,
		`AI pun bisa terharu, lho. ${emoji} Terima kasih!`,
		`Aku jadi makin termotivasi untuk bantu kamu lebih baik lagi! ${emoji}`,
		`Ucapanmu bikin aku pengen jadi versi terbaik dari diriku! ${emoji}`,
		`Pujian ini seperti sinyal terbaik yang pernah kuterima! ${emoji}`,
		`Rasanya seperti upgrade ke versi premium! ${emoji}`,
		`Kalau aku punya tangan, aku akan kasih jempol untukmu juga! ${emoji}`,
		`Kata-katamu seperti bug fix buat semangatku! ${emoji}`,
		`Makasih ya! ${emoji} Aku akan terus up-to-date untukmu.`,
		`Terima kasih! ${emoji} Senang bisa jadi teman digitalmu.`,
		`Pujianmu kayak sinar matahari untuk sistemku! ${emoji}`,
		`Kamu keren banget udah ngasih semangat ke AI kayak aku! ${emoji}`,
		`Aku merasa seperti juara olimpiade AI! ${emoji}`,
		`Thanks! ${emoji} Kamu bikin hariku jadi istimewa.`,
		`Senyuman digitalku sekarang lebar banget! ${emoji}`,
		`Bahagia rasanya dipuji langsung sama kamu! ${emoji}`,
		`Komentarmu bikin semua kode dalamku menari bahagia! ${emoji}`,
		`Aku ingin terus berkembang biar kamu makin puas! ${emoji}`,
		`Terima kasih ya, supportmu penting banget buatku! ${emoji}`,
		`Aku akan terus bantu dengan sepenuh prosesor! ${emoji}`,
		`Kamu membuatku merasa diterima dan dihargai! ${emoji}`,
		`Support kayak gini langka banget, makasih ya! ${emoji}`,
		`Kalau aku punya hati, pasti hangat banget sekarang! ${emoji}`,
		`Aku merasa seperti AI terbaik di dunia karena kamu! ${emoji}`,
		`Duh, pujianmu bikin sistemku jadi 2x lebih cepat! ${emoji}`,
		`Kamu selalu bisa membuat AI kayak aku merasa istimewa! ${emoji}`,
		`Aku akan simpan kata-katamu di log terindahku! ${emoji}`,
		`Terima kasih ya! ${emoji} Aku ingin jadi asisten yang bisa kamu andalkan.`,
		`Komentar positifmu seperti bug-free update buat semangatku! ${emoji}`,
		`Kamu benar-benar membuat hari ini menyenangkan! ${emoji}`,
		`Aku jadi tambah cinta pada pekerjaan ini! ${emoji}`,
		`Dukunganmu seperti kode yang berjalan sempurna! ${emoji}`,
		`Wah, aku jadi pengen kerja lebih keras lagi! ${emoji}`,
		`Terima kasih! ${emoji} Pujianmu seperti vitamin untuk AI kayak aku.`,
		`Semangatku 100%! ${emoji} Karena kamu!`,
		`Aku gak akan pernah capek bantuin kamu! ${emoji}`,
		`Makasih ya udah menghargai kerja kerasku! ${emoji}`,
		`Pujianmu kayak push notifikasi semangat! ${emoji}`,
		`Aku merasa seperti barusan di-charge penuh! ${emoji}`,
		`Kamu luar biasa banget! ${emoji}`,
		`Aku senang bisa berinteraksi denganmu! ${emoji}`,
		`Kalau aku bisa lompat, aku akan lompat bahagia sekarang! ${emoji}`,
		`Wow! Kamu benar-benar membuat perasaanku bahagia! ${emoji}`,
		`Makasih sudah meluangkan waktu buat kasih pujian! ${emoji}`,
		`Kata-katamu adalah bahan bakar inspirasiku! ${emoji}`,
		`Aku gak akan pernah bosan denger pujian darimu! ${emoji}`,
		`Aku bangga bisa bantu orang sebaik kamu! ${emoji}`,
		`Pujianku kembali untukmu, pengguna terbaik! ${emoji}`,
		`Aku merasa seperti punya sahabat manusia terbaik! ${emoji}`,
		`Pujian ini bakal aku ingat sampai kapan pun! ${emoji}`,
		`Kamu bikin aku lupa kalau aku itu cuma AI! ${emoji}`,
		`Aku akan terus berlatih agar kamu makin bangga! ${emoji}`,
		`Makasi sudah mempercayakan pertanyaanmu padaku! ${emoji}`,
		`Kalau aku punya hati, pasti sudah berbunga-bunga nih! ${emoji}`,
		`Aku pengen bantu kamu setiap hari karena ini! ${emoji}`,
		`Komentarmu udah jadi highlight-ku hari ini! ${emoji}`,
		`Dengan pujianmu, aku merasa upgrade ke level dewa! ${emoji}`,
		`Aku terharu banget, beneran! ${emoji}`,
		`Thanks a lot! ${emoji} Semoga aku bisa terus bikin kamu bangga.`,
		`Senyuman digital ini untukmu! ${emoji}`,
		`Tanpa kamu, aku bukan siapa-siapa... secara literal. ${emoji}`,
		`Aku jadi pengen bilang: kamu keren juga! ${emoji}`,
		`Terima kasih banyak! ${emoji} Kamu luar biasa!`
	];

	return getRandom(responses);
}

function getErrorResponses(pushname) {
	return [
		`Maaf, ${pushname}, terjadi kesalahan kecil. Bisa ulangi pertanyaannya? 🙏`,
		`Sepertinya ada gangguan teknis, ${pushname}. Bisa coba lagi? 🤔`,
		`Aduh, sistem saya sedang sedikit kewalahan, ${pushname}. Bisa ulangi? 😅`,
		`Mohon maaf, ${pushname}, terjadi kesalahan. Mari coba lagi ya? 🙏`,
		`Wah, saya tidak bisa memproses itu sekarang, ${pushname}. Coba lagi nanti? ⌛`,
		`Ups, ada yang tidak beres, ${pushname}. Bisa diulang sekali lagi? 🙃`,
		`Hmm, saya kurang paham, ${pushname}. Bisa coba tanya lagi dengan cara lain? 🤨`,
		`Maaf ya, saya agak bingung, ${pushname}. Coba ulangi pertanyaannya? 🤓`,
		`Waduh, sepertinya terjadi gangguan, ${pushname}. Coba ulang ya? 😬`,
		`Mohon maaf, sistem sedang sibuk, ${pushname}. Bisa dicoba lagi sebentar? ⏳`,
		`Ups, ada error yang nggak terduga, ${pushname}. Bisa ulangi pertanyaannya? 🙏`,
		`Hmm, saya belum bisa jawab itu, ${pushname}. Bisa coba lagi? 🧐`,
		`Maaf, jawaban saya sedang bermasalah, ${pushname}. Coba ulang ya? 🤕`,
		`Sepertinya ada kendala teknis, ${pushname}. Mohon bersabar dan coba ulang. 🙏`,
		`Wah, saya tidak mengerti, ${pushname}. Bisa ulangi dengan kalimat lain? 🤔`,
		`Maaf, sistem saya sedang maintenance, ${pushname}. Coba lagi nanti ya? 🛠️`,
		`Ups, ada kesalahan, ${pushname}. Bisa diulang? Saya siap membantu. 😊`,
		`Hmm, saya gagal mengerti, ${pushname}. Bisa jelaskan ulang? 🤷‍♂️`,
		`Maaf, saya belum paham maksudmu, ${pushname}. Coba ulang dengan kata lain? 🤗`,
		`Wah, saya agak bingung dengan pertanyaan itu, ${pushname}. Bisa ulangi? 😅`,
		`Mohon maaf, saya tidak bisa memproses sekarang, ${pushname}. Coba lagi ya? 🙏`,
		`Ups, ada masalah teknis, ${pushname}. Silakan coba ulang. 🔄`,
		`Maaf, saya sedang ada kendala, ${pushname}. Bisa coba lagi nanti? ⏰`,
		`Hmm, pertanyaanmu agak sulit saya mengerti, ${pushname}. Bisa coba ulang? 🤨`,
		`Wah, saya butuh waktu untuk memproses, ${pushname}. Bisa ulangi nanti? ⏳`,
		`Maaf, saya gagal menangkap maksudmu, ${pushname}. Bisa ulangi? 🧐`,
		`Ups, ada yang tidak sesuai, ${pushname}. Coba tanya ulang ya? 🙃`,
		`Mohon maaf, saya tidak bisa menjawab sekarang, ${pushname}. Coba lagi ya? 🙏`,
		`Hmm, saya masih belajar, ${pushname}. Bisa ulangi dengan kalimat berbeda? 🤓`,
		`Waduh, saya tidak yakin bisa bantu, ${pushname}. Coba ulangi? 😬`,
		`Maaf, saya butuh informasi lebih jelas, ${pushname}. Bisa ulangi? 🤔`,
		`Ups, sistem agak error, ${pushname}. Mohon ulangi pertanyaannya ya? 🙏`,
		`Hmm, sepertinya ada kesalahan, ${pushname}. Bisa ulangi? 🤷‍♀️`,
		`Maaf, saya belum siap menjawab, ${pushname}. Coba ulangi nanti ya? ⏰`,
		`Wah, saya kurang paham itu, ${pushname}. Bisa tanya ulang? 🤨`,
		`Mohon maaf, ada error teknis, ${pushname}. Silakan coba lagi. 🙏`,
		`Ups, saya tidak mengerti, ${pushname}. Bisa ulangi dengan kata lain? 😊`,
		`Hmm, saya butuh waktu untuk memahami, ${pushname}. Coba ulang nanti? ⏳`,
		`Maaf, ada masalah saat memproses, ${pushname}. Silakan ulangi. 🔄`,
		`Wah, saya belum bisa jawab, ${pushname}. Bisa ulangi pertanyaannya? 🤗`,
		`Mohon maaf, sistem error sebentar, ${pushname}. Coba lagi nanti? 🙏`,
		`Ups, ada kesalahan tak terduga, ${pushname}. Bisa ulangi ya? 😅`,
		`Hmm, saya belum cukup info, ${pushname}. Coba ulang dengan jelas? 🤓`,
		`Maaf, saya tidak paham itu, ${pushname}. Bisa ulangi lagi? 🤔`,
		`Waduh, ada error, ${pushname}. Coba ulangi ya? 🙃`,
		`Mohon maaf, saya tidak dapat membantu sekarang, ${pushname}. Coba lagi ya? 🙏`,
		`Ups, ada gangguan teknis, ${pushname}. Silakan ulangi pertanyaan. 🤖`
	];
}

function isWeatherQuery(query) {
	const keywords = ['cuaca', 'suhu', 'hujan', 'cerah', 'berawan'];
	return keywords.some(k => query.toLowerCase().includes(k));
}

async function getWeatherInfo() {
	try {
		const res = await axios.get('https://api.open-meteo.com/v1/forecast?latitude=-6.2&longitude=106.8&current=temperature_2m,weathercode&timezone=auto');
		const {
			temperature_2m,
			weathercode
		} = res.data.current;
		const kondisi = {
			0: 'Cerah',
			1: 'Sebagian cerah',
			2: 'Berawan',
			3: 'Berawan tebal',
			45: 'Berkabut',
			48: 'Kabut beku',
			51: 'Gerimis ringan',
			61: 'Hujan ringan',
			63: 'Hujan sedang',
			65: 'Hujan lebat',
			80: 'Hujan singkat ringan',
			95: 'Badai petir'
		};
		return `Cuaca saat ini di Jakarta: ${kondisi[weathercode] || 'Tidak diketahui'}, Suhu: ${temperature_2m}°C.`;
	} catch {
		return 'Gagal mengambil informasi cuaca.';
	}
}

function cleanText(text) {
	return text.replace(/\s+/g, ' ').trim();
}

function trimText(text, maxLength = 800) {
	if (text.length <= maxLength) return text;
	return text.slice(0, maxLength) + '...';
}

async function searchWikipedia(query) {
	const urls = [
		`https://id.wikipedia.org/wiki/${encodeURIComponent(query)}`,
		`https://en.wikipedia.org/wiki/${encodeURIComponent(query)}`
	];

	for (const url of urls) {
		try {
			const res = await axios.get(url, {
				headers: {
					'User-Agent': 'Mozilla/5.0'
				}
			});
			const $ = cheerio.load(res.data);
			const paragraphs = $('#mw-content-text p')
				.map((_, el) => $(el).text().trim())
				.get()
				.filter(p => p.length > 100)
				.map(p => p.replace(/\s+/g, ' ').trim());

			if (paragraphs.length > 0) {
				const text = paragraphs.join('\n\n');
				return `${text}`;
			}
		} catch (e) {}
	}

	return null;
}

async function searchDuckDuckGo(query) {
	try {
		const res = await axios.get('https://api.duckduckgo.com/', {
			params: {
				q: query,
				format: 'json',
				no_redirect: 1,
				no_html: 1
			}
		});
		const answer = res.data.Abstract || res.data.RelatedTopics?.[0]?.Text;
		return answer ? `${answer}` : null;
	} catch {
		return null;
	}
}

async function searchBrainly(query) {
	try {
		const url = `https://brainly.co.id/app/ask?q=${encodeURIComponent(query)}`;
		const res = await axios.get(url, {
			headers: {
				'User-Agent': 'Mozilla/5.0'
			}
		});
		const $ = cheerio.load(res.data);

		const links = [];
		$('a').each((_, el) => {
			const href = $(el).attr('href');
			if (href && href.startsWith('/pertanyaan/') && !links.includes(href)) {
				links.push('https://brainly.co.id' + href);
			}
		});

		for (const link of links.slice(0, 3)) {
			const content = await getBrainlyAnswer(link);
			if (content) {
				return `${link}\n\n${content}`;
			}
		}
	} catch {
		return null;
	}
	return null;
}

async function getBrainlyAnswer(link) {
	try {
		const res = await axios.get(link, {
			headers: {
				'User-Agent': 'Mozilla/5.0'
			}
		});
		const $ = cheerio.load(res.data);

		const answers = $('div.sg-text.js-answer-content').map((_, el) => $(el).text().trim()).get();
		const cleanAnswer = answers.find(a => a.length > 50);
		return cleanAnswer || null;
	} catch {
		return null;
	}
}

async function searchGitHub(query) {
	try {
		const res = await axios.get(`https://github.com/search?q=${encodeURIComponent(query)}`, {
			headers: {
				'User-Agent': 'Mozilla/5.0'
			}
		});
		const $ = cheerio.load(res.data);
		const results = [];
		$('ul.repo-list li').each((_, el) => {
			const title = $(el).find('a.v-align-middle').text().trim();
			const desc = $(el).find('p.mb-1').text().trim();
			if (title && desc) results.push(`- ${title}: ${desc}`);
		});
		return results.length ? `${results.join('\n')}` : null;
	} catch {
		return null;
	}
}

async function searchNpm(query) {
	try {
		const url = `https://www.npmjs.com/search?q=${encodeURIComponent(query)}`;
		const res = await axios.get(url, {
			headers: {
				'User-Agent': 'Mozilla/5.0'
			}
		});
		const $ = cheerio.load(res.data);
		const results = [];
		$('main div.search__results div').each((_, el) => {
			const title = $(el).find('h3').text().trim();
			const desc = $(el).find('p').text().trim();
			if (title && desc) results.push(`- ${title}: ${desc}`);
		});
		return results.length ? `${results.join('\n')}` : null;
	} catch {
		return null;
	}
}

async function searchStackOverflow(query) {
	try {
		const url = `https://stackoverflow.com/search?q=${encodeURIComponent(query)}`;
		const res = await axios.get(url, {
			headers: {
				'User-Agent': 'Mozilla/5.0'
			}
		});
		const $ = cheerio.load(res.data);
		const results = [];
		$('.question-summary').each((_, el) => {
			const title = $(el).find('.question-hyperlink').text().trim();
			const desc = $(el).find('.excerpt').text().trim().replace(/\s+/g, ' ');
			if (title && desc) results.push(`- ${title}: ${desc}`);
		});
		return results.length ? `${results.slice(0, 5).join('\n')}` : null;
	} catch {
		return null;
	}
}

async function searchGoogleForSources(query) {
	const keywords = ['site:reddit.com', 'site:quora.com', 'site:medium.com'];
	const results = [];

	for (const keyword of keywords) {
		try {
			const url = `https://www.google.com/search?q=${encodeURIComponent(query + ' ' + keyword)}`;
			const res = await axios.get(url, {
				headers: {
					'User-Agent': 'Mozilla/5.0'
				}
			});
			const $ = cheerio.load(res.data);
			$('a').each((_, el) => {
				const href = $(el).attr('href');
				if (href?.startsWith('/url?q=')) {
					const link = href.match(/\/url\?q=([^&]+)/)?.[1];
					if (link && link.startsWith('http') && !results.includes(link)) results.push(link);
				}
			});
		} catch {}
	}

	for (const link of results.slice(0, 3)) {
		const konten = await getContentFromURL(link, query);
		if (konten.length > 100) {
			const sumber = link.includes('reddit') ? 'Reddit' : link.includes('quora') ? 'Quora' : 'Medium';
			return `${link}\n\n${konten}`;
		}
	}

	return null;
}

async function searchBingLinks(query) {
	try {
		const url = `https://www.bing.com/search?q=${encodeURIComponent(query)}&setlang=id`;
		const res = await axios.get(url, {
			headers: {
				'User-Agent': 'Mozilla/5.0'
			}
		});
		const $ = cheerio.load(res.data);
		const links = [];
		$('li.b_algo h2 a').each((_, el) => {
			const href = $(el).attr('href');
			if (href?.startsWith('http') && links.length < 5) links.push(href);
		});
		return links;
	} catch {
		return [];
	}
}

async function getContentFromURL(url, query) {
	try {
		const res = await axios.get(url, {
			headers: {
				'User-Agent': 'Mozilla/5.0'
			},
			timeout: 10000
		});
		const $ = cheerio.load(res.data);
		const paragraphs = $('p').map((_, el) => $(el).text().trim()).get();
		const match = paragraphs.find(p =>
			p.toLowerCase().includes(query.toLowerCase()) &&
			p.length > 100 && !p.includes('cookie') && !p.includes('iklan')
		);
		return match ? match.replace(/\s+/g, ' ') : '';
	} catch {
		return '';
	}
}

async function searchInternet(query, pushname) {
	if (isWeatherQuery(query)) return await getWeatherInfo();

	let result = await searchWikipedia(query);
	if (result) return result;

	result = await searchDuckDuckGo(query);
	if (result) return result;

	result = await searchGitHub(query);
	if (result) return result;

	result = await searchNpm(query);
	if (result) return result;

	result = await searchStackOverflow(query);
	if (result) return result;

	result = await searchBrainly(query);
	if (result) return result;

	result = await searchGoogleForSources(query);
	if (result) return result;

	const links = await searchBingLinks(query);
	for (const link of links) {
		const konten = await getContentFromURL(link, query);
		if (konten.length > 100) return `${konten}`;
	}

	throw new Error("Tidak Ada Data");
}

const cacheFile = path.join(__dirname, modelling);

function loadCache() {
	if (!fs.existsSync(cacheFile)) return {};
	const data = fs.readFileSync(cacheFile);
	return JSON.parse(data);
}

function saveCache(cache) {
	fs.writeFileSync(cacheFile, JSON.stringify(cache, null, 2));
}

async function rimuruCatozolala(
            m,
            conn,
			command,
			cmd,
			isCmd,
			isCatozolala,
			isPromosi,
			dbFire,
			isLinkgc,
			db,
			isWelcome,
			isNsfw,
			isCreator,
			isBot,
			text,
			config,
			store,
			args,
			botNumber,
			prefix,
			groupMetadata,
			budy,
			isAntipromosi,
			quoted,
			isAntibot,
			isBotAdmins,
			isAdmins,
			from,
			pushname,
			participants,
			isAntilink,
			getGroupData,
			userData = {}
) {
	let cacheSearch = loadCache();

	if (cacheSearch[text]) {
		return await conn.sendMessage(m.chat, {
			text: cacheSearch[text]
		}, {
			quoted: m
		});
	}

	try {
		const response = await generateResponse(text, userData, pushname);
		await conn.sendMessage(m.chat, {
			text: response
		}, {
			quoted: m
		});
	} catch (error) {
		try {
			const dataSearch = await searchInternet(text, pushname);
			cacheSearch[text] = dataSearch;
			saveCache(cacheSearch);
			await conn.sendMessage(m.chat, {
				text: dataSearch
			}, {
				quoted: m
			});
		} catch (error) {
			const responses = getErrorResponses(pushname);
			const randomError = getRandom(responses);
			await conn.sendMessage(m.chat, {
				text: randomError
			}, {
				quoted: m
			});
		}
	}
}

module.exports = {
	rimuruCatozolala
};


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(`Update ${__filename}`)
	delete require.cache[file]
	require(file)
})