require("../module");
const PhoneNumber = require('awesome-phonenumber');
const fs = require('fs');
const config = require("../catozolala");

function smsg(client, m, store) {
	client.chats = {}

	client.downloadMediaMessage = async (message) => {
		let mime = (message.msg || message).mimetype || ''
		let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
		const stream = await downloadContentFromMessage(message, messageType)
		let buffer = Buffer.from([])
		for await (const chunk of stream) {
			buffer = Buffer.concat([buffer, chunk])
		}
		return buffer
	}

	client.decodeJid = (jid) => {
		if (!jid) return jid
		if (/:\d+@/gi.test(jid)) {
			let decode = jidDecode(jid) || {}
			return decode.user && decode.server && decode.user + '@' + decode.server || jid
		} else return jid
	}

	client.sendAds = async (chatId, options = {}) => {
		const {
			text = '',
				image = './media/logo.jpg',
				title = '',
				body = '',
				link = config.linkGroupSaluran,
				newsletterName = config.nameBots,
				newsletterJid = config.saluranId,
				botNumber = '6281938830020@s.whatsapp.net'
		} = options;

		const message = {
			text,
			contextInfo: {
				externalAdReply: {
					containsAutoReply: true,
					mediaType: 1,
					renderLargerThumbnail: false,
					thumbnail: Buffer.isBuffer(image) ? image : fs.readFileSync(image),
					title,
					body,
					sourceUrl: link
				},
				forwardingScore: 99999,
				isForwarded: true,
				mentionedJid: [m?.sender],
				...(botNumber && {
					businessMessageForwardInfo: {
						businessOwnerJid: botNumber
					}
				}),
				...(newsletterJid && newsletterName && {
					forwardedNewsletterMessageInfo: {
						newsletterJid,
						newsletterName
					}
				})
			}
		};

		await client.sendMessage(chatId, message, {
			quoted: {
				key: {
					remoteJid: "status@broadcast",
					fromMe: false,
					id: m.id,
					participant: "0@s.whatsapp.net"
				},
				message: {
					conversation: m.text || "By Catozolala"
				}
			}
		});
	}
	
    client.packSticker = {
        key: {
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "120363400662819774@g.us"
        },
        message: {
            stickerPackMessage: {
                stickerPackId: "\000",
                name: config.nameBots,
                publisher: "kkkk"
            }
        }
    }

	client.reply = async (jid, options = {}) => {
		const {
			text = "",
				title = "",
				subtitle = "",
				footer = "Bot",
				quickReplies = []
		} = options;

		const buttons = quickReplies.map(item => ({
			name: "quick_reply",
			buttonParamsJson: JSON.stringify({
				display_text: item.name,
				id: item.rowId
			})
		}));

		const msg = generateWAMessageFromContent(jid, {
			viewOnceMessage: {
				message: {
					messageContextInfo: {
						deviceListMetadata: {},
						deviceListMetadataVersion: 2
					},
					interactiveMessage: proto.Message.InteractiveMessage.create({
						body: proto.Message.InteractiveMessage.Body.create({
							text
						}),
						footer: proto.Message.InteractiveMessage.Footer.create({
							text: footer
						}),
						header: proto.Message.InteractiveMessage.Header.create({
							title,
							subtitle,
							hasMediaAttachment: false
						}),
						nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
							buttons
						})
					})
				}
			}
		}, {});

		const messageId = `msg_${Date.now()}`;

		client.relayMessage(jid, msg.message, {
			messageId
		});
	};

	client.getGroupAdmins = (participants) => {
		let admins = []
		for (let i of participants) {
			i.admin === "superadmin" ? admins.push(i.id) : i.admin === "admin" ? admins.push(i.id) : ''
		}
		return admins || []
	}

	client.countChats = async (client) => {
		return new Promise((resolve, reject) => {
			client.chats.all().then((chats) => {
				const groupChats = chats.filter(chat => chat.id.endsWith('@g.us'));
				const privateChats = chats.filter(chat => chat.id.endsWith('@s.whatsapp.net'));
				resolve({
					total: chats.length,
					group: groupChats.length,
					private: privateChats.length
				});
			}).catch(reject);
		});
	}

	client.chats = {
		all: async () => Object.values(store.chats || {})
	};

	client.getName = async (jid, withoutContact = false) => {
		jid = client.decodeJid(jid)
		withoutContact = client.withoutContact || withoutContact

		let v
		if (jid.endsWith("@g.us")) {
			v = store.contacts[jid] || {}
			if (!(v.name || v.subject)) {
				try {
					v = await client.groupMetadata(jid) || {}
				} catch (e) {
					v = {}
				}
			}
			return v.name || v.subject || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
		} else {
			v = jid === '0@s.whatsapp.net' ? {
					jid,
					name: 'WhatsApp'
				} :
				areJidsSameUser(jid, client.user.id) ? client.user :
				(store.contacts[jid] || {})

			return (
				(withoutContact ? '' : v.name) ||
				v.subject ||
				v.verifiedName ||
				v.notify ||
				v.vname ||
				PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
			)
		}
	}

	client.sendText = (jid, text, quoted = '', options) => client.sendMessage(jid, {
		text: text,
		...options
	}, {
		quoted
	})
	if (!m) return m
	let M = proto.WebMessageInfo
	if (m.key) {
		m.id = m.key.id
		m.from = m.key.remoteJid.startsWith('status') ? jidNormalizedUser(m.key?.participant || m.participant) : jidNormalizedUser(m.key.remoteJid);
		m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16
		m.chat = m.key.remoteJid
		m.fromMe = m.key.fromMe
		m.isGroup = m.chat.endsWith('@g.us')
		m.sender = client.decodeJid(m.fromMe && client.user.id || m.participant || m.key.participant || m.chat || '')
		if (m.isGroup) m.participant = client.decodeJid(m.key.participant) || ''
	}
	if (m.message) {
		m.mtype = getContentType(m.message)
		m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype])
		m.body = m.message?.conversation ||
			m.msg?.caption ||
			m.msg?.text ||
			(m.mtype == 'listResponseMessage' && m.msg?.singleSelectReply?.selectedRowId) ||
			(m.mtype == 'buttonsResponseMessage' && m.msg?.selectedButtonId) ||
			(m.mtype == 'viewOnceMessage' && m.msg?.caption) ||
			m.text;
		let quoted = m.quoted = m.msg?.contextInfo?.quotedMessage ?? null;
		m.mentionedJid = m.msg?.contextInfo?.mentionedJid ?? [];
		if (m.quoted) {
			let type = getContentType(quoted)
			m.quoted = m.quoted[type]
			if (['productMessage'].includes(type)) {
				type = getContentType(m.quoted)
				m.quoted = m.quoted[type]
			}
			if (typeof m.quoted === 'string') m.quoted = {
				text: m.quoted
			}

			m.quoted.key = {
				remoteJid: m.msg?.contextInfo?.remoteJid || m.from,
				participant: jidNormalizedUser(m.msg?.contextInfo?.participant),
				fromMe: areJidsSameUser(jidNormalizedUser(m.msg?.contextInfo?.participant), jidNormalizedUser(client?.user?.id)),
				id: m.msg?.contextInfo?.stanzaId,
			};

			m.quoted.mtype = type
			m.quoted.from = /g\.us|status/.test(m.msg?.contextInfo?.remoteJid) ? m.quoted.key.participant : m.quoted.key.remoteJid;
			m.quoted.id = m.msg.contextInfo.stanzaId
			m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
			m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false
			m.quoted.sender = client.decodeJid(m.msg.contextInfo.participant)
			m.quoted.fromMe = m.quoted.sender === (client.user && client.user.id)
			m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || ''
			m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
			m.getQuotedObj = m.getQuotedMessage = async () => {
				if (!m.quoted.id) return false
				let q = await store.loadMessage(m.chat, m.quoted.id, client)
				return exports.smsg(client, q, store)
			}
			let vM = m.quoted.fakeObj = M.fromObject({
				key: {
					remoteJid: m.quoted.chat,
					fromMe: m.quoted.fromMe,
					id: m.quoted.id
				},
				message: quoted,
				...(m.isGroup ? {
					participant: m.quoted.sender
				} : {})
			})

			m.quoted.delete = () => client.sendMessage(m.quoted.chat, {
				delete: vM.key
			})
			m.quoted.copyNForward = (jid, forceForward = false, options = {}) => client.copyNForward(jid, vM, forceForward, options)
			m.quoted.download = () => client.downloadMediaMessage(m.quoted)
		}
	}
	if (m.msg?.url) m.download = () => client.downloadMediaMessage(m.msg);
	m.text = m.msg?.text ||
		m.msg?.caption ||
		m.message?.conversation ||
		m.msg?.contentText ||
		m.msg?.selectedDisplayText ||
		m.msg?.title ||
		''
	m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? client.sendMedia(chatId, text, 'file', '', m, {
		...options
	}) : client.sendText(chatId, text, m, {
		...options
	})
	m.copy = () => exports.smsg(client, M.fromObject(M.toObject(m)))
	m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => client.copyNForward(jid, m, forceForward, options)

	return m
}

module.exports = {
	smsg
}