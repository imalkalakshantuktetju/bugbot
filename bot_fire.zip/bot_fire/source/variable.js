const { 
  Boom 
} = require('@hapi/boom');

const { 
  name, 
  owner
} = require("../catozolala");

const { 
   color, 
   style, 
   background 
} = require("../lib/chalk");
const { 
   exec 
} = require("child_process");

global.exec = exec;
global.crypto = require('crypto');
global.ff = require('fluent-ffmpeg');
global.os = require('os');
global.moment = require('moment-timezone');
global.waktu = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');
global.util = require("util");
global.color = color;
global.style = style;
global.background = background;
global.Boom = Boom;
global.name = name;
global.owner = owner;
global.pino = require("pino");
global.readline = require("readline");
global.fs = require('fs');
global.path = require('path');
global.axios = require('axios')