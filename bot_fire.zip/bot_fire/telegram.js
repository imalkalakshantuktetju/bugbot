const fs = require('fs');
const path = require('path');
const { Telegraf } = require('telegraf');
const config = require('./catozolala');
const { color, background } = require('./lib/chalk');
const util = require('util');

const bot = new Telegraf(config.telegramToken);
global.media = fs.readFileSync('./media/media.jpg');

function isOwner(ctx) {
	const userId = ctx.from?.id?.toString();
	return config.telegramOwner.includes(userId);
}

const pluginDir = path.resolve('telegram');
const loadedPluginMap = new Map();
const allPlugins = [];

function clearPlugins() {
	allPlugins.length = 0;
}

function loadPlugin(file) {
	const fullPath = path.join(pluginDir, file);
	try {
		delete require.cache[require.resolve(fullPath)];
		const plugin = require(fullPath);

		if (
			typeof plugin === 'function' &&
			plugin.type === 'telegram' &&
			Array.isArray(plugin.trigger)
		) {
			loadedPluginMap.set(file, plugin);
			allPlugins.push(plugin);
		}
	} catch (err) {
		console.error(`[PLUGIN] Failed to load: ${file}`, err);
	}
}

function reloadAllPlugins() {
	clearPlugins();
	const pluginFiles = fs.readdirSync(pluginDir).filter(f => f.endsWith('.js'));
	for (const file of pluginFiles) loadPlugin(file);
}

reloadAllPlugins();

fs.watch(pluginDir, (event, filename) => {
	if (filename?.endsWith('.js')) {
		console.log(`[PLUGIN WATCHER] Detected: ${event} on ${filename}`);
		reloadAllPlugins();
	}
});

const callbackCooldown = new Map();
const callbackViolations = new Map();
const bannedUsers = new Map();

const VIOLATION_WINDOW = 2000;
const BAN_DURATION = 5000;
const SPAM_THRESHOLD = 3;
const CLICK_INTERVAL = 800;

const originalMessages = new Map();

function pluginContext(ctx) {
  const messageText = ctx.message?.text?.trim().toLowerCase() || '';
  const parts = messageText.replace(/^[/!#.\s]*/, '').split(/\s+/);
  const command = parts[0];
  const args = parts.slice(1);
  const text = args.join(' ');
  
  return { 
    config, 
    isOwner,
    username: ctx.from.username || ctx.from.first_name || 'Tidak diketahui',
    userId: ctx.from.id,
    currentDate: new Date().toLocaleDateString(),
    isGroup: ctx.chat.type.endsWith('group'),
    messageText,
    command,
    text,
    args
  };
}

bot.on('text', async (ctx) => {

   const {
     config, 
     isOwner,
     username,
     userId,
     currentDate,
     messageText,
	 command,
	 isGroup,
	 text
   } = pluginContext(ctx);
   
	console.log(color("yellow") + "┌──────────────────────────────────────────" + color("reset"));
	console.log(color("yellow") + "│ " + color("black") + background("cyan") + "         NEW TELEGRAM MESSAGE         " + color("reset"));
	console.log(color("yellow") + "├──────────────────────────────────────────" + color("reset"));
	console.log(color("yellow") + "│ " + color("cyan") + "Username : " + color("reset") + username);
	console.log(color("yellow") + "│ " + color("cyan") + "User ID  : " + color("reset") + userId);
	console.log(color("yellow") + "│ " + color("cyan") + "Message  : " + color("reset") + messageText);
	console.log(color("yellow") + "│ " + color("cyan") + "Date     : " + color("reset") + currentDate);
	console.log(color("yellow") + "└──────────────────────────────────────────\n" + color("reset"));

	for (const plugin of allPlugins) {
		if (!plugin.trigger.includes('text')) continue;

		const cmdList = plugin.command || [];
		if (!cmdList.includes(command)) continue;

		if (plugin.owner && !isOwner(ctx)) {
			await ctx.reply(config.message?.owner || '❌ Hanya owner yang dapat menggunakan perintah ini.');
			continue;
		}
		
		if (plugin.group && !isGroup) {
			await ctx.reply('Perintah ini hanya dapat digunakan di grup.');
			continue;
		}

		try {
			await plugin(ctx, null, pluginContext(ctx));
		} catch (e) {
			console.error(`[PLUGIN ERROR] ${plugin.name}:`, e);
		}
	}
	
	if (command.startsWith('<')) {
      if (!isOwner) return ctx.reply(config.message?.owner);
      try {
        let evaled = await eval(text);
        if (typeof evaled !== 'string') evaled = util.inspect(evaled);
        await ctx.reply(util.format(evaled));
      } catch (e) {
        await ctx.reply(util.format(e));
      }
    }
  
});

bot.on('callback_query', async (ctx) => {
	const callbackData = ctx.callbackQuery?.data || '';
	const userId = ctx.from?.id;
	const now = Date.now();
	const messageId = ctx.callbackQuery?.message?.message_id;
	const chatId = ctx.chat?.id;

	if (bannedUsers.has(userId)) {
		const unbanTime = bannedUsers.get(userId);
		if (now < unbanTime) {
			await ctx.editMessageCaption('🚫 Kamu sedang diblokir sementara karena terlalu cepat menekan tombol.', {
				parse_mode: 'HTML'
			}).catch(() => {});

			setTimeout(() => {
				restoreOriginalMessage(ctx, userId);
			}, 4000);
			return;
		} else {
			bannedUsers.delete(userId);
			callbackViolations.delete(userId);
		}
	}

	if (!originalMessages.has(userId)) {
		const caption = ctx.callbackQuery?.message?.caption;
		const reply_markup = ctx.callbackQuery?.message?.reply_markup;
		originalMessages.set(userId, { caption, reply_markup });
	}

	if (callbackCooldown.has(userId)) {
		const lastClick = callbackCooldown.get(userId);
		const delta = now - lastClick;

		if (delta < CLICK_INTERVAL) {
			const violations = callbackViolations.get(userId) || [];
			violations.push(now);

			const recent = violations.filter(t => now - t < VIOLATION_WINDOW);
			callbackViolations.set(userId, recent);

			if (recent.length >= SPAM_THRESHOLD) {
				bannedUsers.set(userId, now + BAN_DURATION);
				await ctx.editMessageCaption('🚫 Kamu diblokir sementara karena spam tombol.', {
					parse_mode: 'HTML'
				}).catch(() => {});

				setTimeout(() => restoreOriginalMessage(ctx, userId), 4000);
				return;
			} else {
				await ctx.editMessageCaption('⚠️ Terlalu cepat! Harap tunggu sebentar.', {
					parse_mode: 'HTML'
				}).catch(() => {});

				setTimeout(() => restoreOriginalMessage(ctx, userId), 3000);
				return;
			}
		}
	}

	callbackCooldown.set(userId, now);

	for (const plugin of allPlugins) {
		if (!plugin.trigger.includes('callback_query')) continue;
		if (plugin.owner && !isOwner(ctx)) {
			await ctx.answerCbQuery('❌ Hanya owner yang bisa akses ini.', { show_alert: true });
			continue;
		}

		try {
			await plugin(ctx, callbackData, pluginContext(ctx));
		} catch (e) {
			console.error(`[PLUGIN ERROR] ${plugin.name}:`, e);
		}
	}

	await ctx.answerCbQuery().catch(() => {});
});

function restoreOriginalMessage(ctx, userId) {
	const original = originalMessages.get(userId);
	if (!original) return;

	ctx.editMessageCaption(original.caption, {
		parse_mode: 'HTML',
		reply_markup: original.reply_markup
	}).catch(() => {});

	originalMessages.delete(userId);
}

bot.launch()
	.then(() => {
		console.log('[Telegram] Bot started');
		process.send?.('[telegram] ready');
	})
	.catch((err) => {
		console.error('[Telegram] Gagal start:', err);
	});

process.on('message', (msg) => {
	if (msg === 'uptime') {
		process.send?.(`[telegram] uptime: ${process.uptime()} detik`);
	} else if (msg === 'reset') {
		process.exit(1);
	}
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
	delete require.cache[file];
	require(file);
});