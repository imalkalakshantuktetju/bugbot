let handler = async (ctx, arg, { config }) => {
	const userId = ctx.from.id;
	await ctx.reply('🔄 Bot akan direstart...');
	setTimeout(() => process.exit(0), 1000);
};

handler.name = 'restart';
handler.type = 'telegram';
handler.trigger = ['text'];
handler.tags = ["owner"];
handler.command = ['restart'];
handler.owner = true;

module.exports = handler;