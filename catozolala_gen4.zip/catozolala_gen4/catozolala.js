module.exports = {

/*============== Module ==============*/
	get module() {
		return require("./module");
	},
	get variable() {
		return require("./source/variable");
	},
	
/*============== Settings ==============*/
	
	nomerPairing: "94712379940",
	name: "Catozolala",
	nameBots: "Catozolala 乂 Nero",
	owner: ["94712379940", "94752051639"],
	saluranId: "120363259883647670@newsletter",
	linkGroupWhatsapp: "https://chat.whatsapp.com/BQ7P7OQtIcp1pnfjl4JrqN",
	linkGroupsSaluran: "https://whatsapp.com/channel/0029VaVKIxBKQuJK32uAi33W",

/*============== Telegram ==============*/

    telegramToken: "7465612838:AAEUZHX6-fIenbONpEQy9sX9zPTNTC0FqlM",
    telegramOwner: ["6066724720", "1087968824"],
    telegramBullet: "◦",
    
/*============== Message ==============*/

	message: {
		premium: "⛔ [ Premium ] This feature is only for premium users. Please contact the owner to get premium access",
		owner: "🔒 [ Owner Only ] This feature is only for the owner.",
		admin: "⛔ [ Admin Only ] This feature is only for group admins.",
		botAdmins: "❗ [ Admin Required ] The bot is not an admin. Please make the bot an admin to use this feature.",
		group: "👥 [ Group Only ] This feature can only be used in group chats.",
		limit: "🎟️ [ Limit Reached ] You've used up your limit. Contact the owner to get more, or wait until 11 PM for reset.",
		plugin: "⛔ [ Feature Disabled ] This feature is currently disabled due to an error.",
		nsfw: "🔞 [ NSFW ] Please ask the admin to enable NSFW features before using this.",
		ban: "⚠️ [ Banned ] You are banned from using the bot. Contact the owner to request unban."
	},
	
	database: {
		groupOnly: true,
		public: true
	}
}