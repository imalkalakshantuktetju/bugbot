module.exports = async (m, {
  conn,
  budy,
  isAdmins,
  isCreator,
  isBotAdmins,
  groupMetadata,
  isAntipromosi,
  isLinkgc
}) => {
  
  if (!m.isGroup) return;
  if (m.fromMe) return;
  if (!isBotAdmins) return;
  if (isAdmins || isCreator) return;

  const text = m.text.toLowerCase();

  if ((await isAntipromosi(groupMetadata))) {
    const senderId = m?.sender || m?.key?.participant;
    if (
      text.includes('panel') || text.includes('account') ||
      text.includes('join') || text.includes('discount') ||
      text.includes('promo') || text.includes('interest') ||
      text.includes('pm') || text.includes('testimony') ||
      text.includes('list') || text.includes('ready') ||
      text.includes('open')
    ) {
      await conn.sendMessage(m.chat, {
        text: `\`\`\`「 Promotion Detected 」\`\`\`\n\n@${senderId?.split("@")[0]}, you are detected promoting something and will be removed!`,
        contextInfo: {
          mentionedJid: [senderId]
        }
      });

      await conn.sendMessage(m.chat, { delete: m.key });
    }
  }
}