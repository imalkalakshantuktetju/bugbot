module.exports = async (m, {
	conn,
	budy,
	isAdmins,
	isCreator,
	isBotAdmins,
	isAntilink,
	groupMetadata
}) => {
	if (!m.isGroup) return;
	if (!budy) return;

	const isLink = /https?:\/\/[^\s]+/.test(budy);

	if ((await isAntilink(groupMetadata)) && isLink) {
		if (!isBotAdmins) return;
		if (isAdmins || isCreator) return;

		const senderId = m?.sender || m?.key?.participant;

		if (m?.key?.id && senderId) {
			await conn.sendMessage(m.chat, {
				delete: {
					remoteJid: m.chat,
					fromMe: false,
					id: m.key.id,
					participant: senderId
				}
			});
		}

		await conn.sendMessage(m.chat, {
			text: `\`\`\`「 Link Detected 」\`\`\`\n\n@${senderId?.split("@")[0]} your message has been deleted.`,
			contextInfo: {
				mentionedJid: [senderId]
			}
		});
	}
}