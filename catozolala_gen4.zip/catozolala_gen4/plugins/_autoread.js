module.exports = async (m, {conn} ) => {
  if (global.db.data.settings.autoread) conn.readMessages([m.key]);
}