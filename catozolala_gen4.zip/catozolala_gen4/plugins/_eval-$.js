const {
	exec
} = require("child_process");

module.exports = async (m, {
	conn,
	isCreator,
	text,
	budy,
	command
}) => {
	if (budy.startsWith('$')) {
		if (!isCreator) return;
		const command = budy.slice(1).trim();
		exec(command, (err, stdout, stderr) => {
			if (err) return m.reply(`Error: ${err.message}`);
			if (stderr) return m.reply(`Stderr: ${stderr}`);
			if (stdout) return m.reply(stdout);
		});
	}
};