const fs = require('fs');
const image = fs.readFileSync('./media/logo.jpg');
const {
	name,
	message
} = require("../catozolala");
const getUcapan = require("../lib/waktuUcapan");
const path = require('path');
const more = String.fromCharCode(8206);
const readmore = more.repeat(500);

let handler = async (m, {
	conn,
	prefix,
	command,
	dbFire,
	groupMetadata,
	config,
	isCreator
}) => {
	const fitur = await loadCommandsByTags();
	const groupId = dbFire.encodePath(groupMetadata.id);
	global.db.data.groups = global.db.data.groups || {};
	const groupInfo = global.db.data.groups[groupId] || null;
	const data = groupInfo?.bot_public === true;

	let dekorasi = "◦"
	let dekorasiTeks = ["「 *", "* 」"]
	let sections = [];
	let options, dataMenu, list, com;
	if (command === "mainmenu") {
		sections = [{
			title: 'Menu Options',
			rows: [{
					title: 'Category: All Menu',
					description: 'show all menu contents',
					id: `${prefix}allmenu`
				},
				{
					title: 'Category: Group Menu',
					description: 'Complete features for group needs',
					id: `${prefix}groupmenu`
				},
				{
					title: 'Category: Game Menu',
					description: 'A collection of fun and entertaining games',
					id: `${prefix}gamemenu`
				},
				{
					title: 'Category: Tools Menu',
					description: 'Versatile tools ready to use',
					id: `${prefix}toolsmenu`
				},
				{
					title: 'Category: Owner Menu',
					description: 'Exclusive features for the bot owner',
					id: `${prefix}ownermenu`
				},
				{
					title: 'Category: Bug Menu',
					description: 'Experimental and quirky features',
					id: `${prefix}bugmenu`
				},
				{
					title: 'Category: Anime Menu',
					description: 'All the best features about anime',
					id: `${prefix}animemenu`
				},
				{
					title: 'Category: Internet Menu',
					description: 'Features special internet',
					id: `${prefix}internetmenu`
				},
				{
					title: 'Category: NSFW Menu',
					description: 'Special content for adult users',
					id: `${prefix}nsfwmenu`
				}
			]
		}];

		options = "viewOnce";

	} else if (command === "groupmenu") {

		const group = 'group';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});

		options = "documentTeks";
		list = dataMenu.map(x => x.com).join('\n');
		
	}  else if (command === "allmenu") {
	     const semuaGroup = Object.keys(fitur).sort();
	     dataMenu = [];

	     for (const group of semuaGroup) {
		    const judul = `*📁 ${kapitalAwal(group)} Menu*`;
		     const subMenu = (fitur[group] || []).map(cmd => {
			    let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			    commandName = typeof commandName === 'string' ? commandName : '';
			    const help = cmd.help ? `${dekorasiTeks[0]}${cmd.help}${dekorasiTeks[1]}` : '';
			    return `${dekorasi} ${kapitalAwal(commandName)} ${help}`;
		     }).join('\n');

		     if (subMenu.trim()) {
			     dataMenu.push(`\n${judul}\n${subMenu}`);
		     }
	    }

	options = "documentTeks";
	list = dataMenu.join('\n');
	
	} else if (command === "ownermenu") {

		const group = 'owner';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});

		options = "documentTeks";
		list = dataMenu.map(x => x.com).join('\n');
		
	} else if (command === "toolsmenu") {


		const group = 'tools';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});

		options = "documentTeks";
		list = dataMenu.map(x => x.com).join('\n');
		
	} else if (command === "animemenu") {


		const group = 'anime';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});


		options = "documentTeks";
		list = dataMenu.map(x => x.com).join('\n');
		
	} else if (command === "nsfwmenu") {

		const group = 'nsfw';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});

		options = "documentTeks";
		list = dataMenu.map(x => x.com).join('\n');
		
	} else if (command === "gamemenu") {


		const group = 'game';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});

		options = "documentTeks";
		list = dataMenu.map(x => x.com).join('\n');
		
	} else if (command === "bugmenu") {


		const group = 'bug';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});

		options = "documentTeks";
		list = dataMenu.map(x => x.com).join('\n');
		
	} else if (command === "internetmenu") {

		const group = 'internet';
		dataMenu = (fitur[group] || []).map(cmd => {
			let commandName = Array.isArray(cmd.command) ? cmd.command[0] : cmd.command;
			commandName = typeof commandName === 'string' ? commandName : '';
			return {
				com: `${dekorasi} ${kapitalAwal(commandName)} ${cmd.help ? dekorasiTeks[0] + cmd.help + dekorasiTeks[1] : ''}`
			};
		});

	}

	if (options === "documentTeks") {

		const pushName = m.pushName || ""
		let input = command.split("menu")[0].trim();
		let hasil = kapitalAwal(input);
		
		let simplemenu = ``;
		simplemenu += `*Hi there! We're a friendly WhatsApp bot created to help make things easier for you. Whether you need quick answers, simple tasks done, or just a bit of guidance — we're here to assist, anytime you need.*\n\n`;
		simplemenu += readmore;
		simplemenu += `📂 *${hasil} Menu:*\n\n`;
		simplemenu += list;

		const buttonMessage = {
			document: fs.readFileSync("./package.json"),
			fileName: getUcapan() + ".pdf",
			fileLength: Infinity,
			pageCount: Infinity,
			mimetype: 'application/pdf',
			caption: simplemenu,
			jpegThumbnail: global.media,
			forwardingScore: 99999,
			isForwarded: true,
			mentions: [m.sender],
			contextInfo: {
				thumbnail: image,
				forwardingScore: 99999,
				isForwarded: true,
				mentionedJid: [m.sender],
				externalAdReply: {
					containsAutoReply: true,
					sourceUrl: `instagram.com`,
					mediaType: 1,
					thumbnail: global.media,
					renderLargerThumbnail: true,
					title: config.nameBots,
					body: 'Powered by whatsapp'
				}
			}
		};

		return conn.sendMessage(m.chat, buttonMessage, {
			quoted: conn.packSticker
		});

	} else if (options === "doxumentButton") {
		const flowActions = [{
			buttonId: `${prefix}menu`,
			buttonText: {
				displayText: '📂 Buka Menu Lengkap'
			},
			type: 4,
			nativeFlowInfo: {
				name: 'single_select',
				paramsJson: JSON.stringify({
					title: '📂 Pilih Menu',
					sections: sections
				})
			},
			viewOnce: true
		}];

		const buttonMessage = {
			text: `Halo ${pushName} 👋\nSelamat datang di bot ${name}!`,
			footer: `Klick button di bawah ini`,
			buttons: flowActions,
			headerType: 1,
			viewOnce: true
		};

		return conn.sendMessage(m.chat, buttonMessage, {
			quoted: m
		});

	} else if (options === "viewOnce") {

		let listMessage = {
			title: 'View Fitur',
			sections
		};

		const Shirokuu = generateWAMessageFromContent(m.from, {
			viewOnceMessage: {
				message: {
					messageContextInfo: {
						deviceListMetadata: {},
						deviceListMetadataVersion: 2
					},
					interactiveMessage: proto.Message.InteractiveMessage.create({
						body: proto.Message.InteractiveMessage.Body.create({
							text: null
						}),
						footer: proto.Message.InteractiveMessage.Footer.create({
							text: ``
						}),
						header: proto.Message.InteractiveMessage.Header.create({
							title: `Halo @${m.sender.split("@")[0]} 👋\nWelcome to bot ${name}`,
							hasMediaAttachment: false,
						}),
						contextInfo: {
							mentionedJid: [m.sender]
						},
						nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
							buttons: [{
								name: "single_select",
								buttonParamsJson: JSON.stringify(listMessage)
							}]
						})
					})
				}
			}
		}, {
			quoted: m
		});

		return conn.relayMessage(m.key.remoteJid, Shirokuu.message, {
			messageId: m.key.id
		});
	}
};

const fsv2 = require('fs/promises');

async function loadCommandsByTags(dirPath = path.join(__dirname, '../plugins')) {
	const files = await fsv2.readdir(dirPath);
	const commandGroups = Object.create(null);

	await Promise.all(
		files
		.filter(file => file.endsWith('.js'))
		.map(async (file) => {
			try {
				const pluginPath = path.join(dirPath, file);
				delete require.cache[require.resolve(pluginPath)];
				const plugin = require(pluginPath);

				if (!plugin || !plugin.command || !plugin.tags) return;

				const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
				const tags = Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags];

				let helps = [];

				if (Array.isArray(plugin.help)) {
					// jika help lebih pendek, isi sisanya dengan help[0]
					if (plugin.help.length < commands.length) {
						helps = Array(commands.length).fill(plugin.help[0]);
					} else {
						helps = plugin.help;
					}
				} else if (typeof plugin.help === 'string') {
					helps = Array(commands.length).fill(plugin.help);
				} else {
					// fallback: isi help sama dengan command (nama saja)
					helps = Array(commands.length).fill('');
				}

				for (const tag of tags) {
					if (!commandGroups[tag]) commandGroups[tag] = [];

					for (let i = 0; i < commands.length; i++) {
						commandGroups[tag].push({
							command: commands[i],
							help: helps[i] || '',
							file: file
						});
					}
				}
			} catch (e) {
				console.error(`❌ Gagal load plugin: ${file}\n`, e);
			}
		})
	);

	return commandGroups;
}

function kapitalAwal(kalimat) {
	return kalimat.charAt(0).toUpperCase() + kalimat.slice(1).toLowerCase();
}

handler.command = ['allmenu', "allmenu", "internetmenu", "bugmenu", "mainmenu", "groupmenu", "ownermenu", "toolsmenu", "animemenu", "nsfwmenu", "gamemenu"];
handler.tags = ["menu"];

module.exports = handler;