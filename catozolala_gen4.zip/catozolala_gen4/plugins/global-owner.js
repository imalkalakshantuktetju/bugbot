const { name, owner } = require("../catozolala");
const fs = require('fs');

let handler = async (m, { conn }) => {
  conn.sendContact = async (jid, numbers = [], desk = "Powered by", quoted = '', opts = {}) => {
    let list = numbers.map(i => ({
      displayName: name,
      vcard: 'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        `N:;${name};;;\n` +
        `FN:${name}\n` +
        `ORG:${desk}\n` +
        'TITLE:\n' +
        `item1.TEL;waid=${i}:${i}\n` +
        'item1.X-ABLabel:Ponsel\n' +
        `X-WA-BIZ-DESCRIPTION:${desk}\n` +
        `X-WA-BIZ-NAME:${name}\n` +
        'END:VCARD'
    }));

    await conn.sendMessage(jid, {
      contacts: {
        displayName: `${list.length} Kontak`,
        contacts: list
      },
      ...opts
    }, { quoted });
  };

  // Cek file thumbnail
  const thumbnail = fs.existsSync('./media/rimuru.jpg') ? fs.readFileSync('./media/rimuru.jpg') : null;

  await conn.sendContact(m.chat, owner, "Powered by WhatsApp", m, {
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        title: `© Copyright ${name}`,
        sourceUrl: `https://wa.me/${owner[0]}`, // pakai owner pertama untuk link
        mediaType: 1,
        thumbnail
      }
    }
  });
};

handler.command = ["owner"];
handler.tags = ["menu"];
handler.help = ["owner"];

module.exports = handler;