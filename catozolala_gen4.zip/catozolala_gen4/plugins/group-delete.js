let handler = async (m, { conn }) => {
    if (!m.quoted) return m.reply("Reply ke pesan yang ingin dihapus!");

    await conn.sendMessage(m.chat, {
        delete: {
            remoteJid: m.quoted.chat,
            fromMe: false,
            id: m.quoted.key.id,
            participant: m.quoted.key.participant
        }
    });
}

handler.help = ["reply"];
handler.tags = ["group", "owner"];
handler.command = ["delete", "del"];
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;