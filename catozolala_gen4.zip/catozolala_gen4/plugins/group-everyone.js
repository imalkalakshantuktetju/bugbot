const { message } = require("../catozolala");

let handler = async (m, { conn, isCreator, isBotAdmins, groupAdmins, isAdmins, text }) => {

    const groupMetadata = await conn.groupMetadata(m.chat).catch(e => {});
    const mem = groupMetadata?.participants?.map(a => a.id) || [];

    conn.sendMessage(m.chat, {
        text: `@${m.chat} ${text}`,
        contextInfo: {
            mentionedJid: mem,
            groupMentions: [
                {
                    groupSubject: "everyone",
                    groupJid: m.chat,
                },
            ],
        },
    });
};

handler.help = ["teks"];
handler.command = ["everyone"];
handler.tags = ["group"];
handler.admin = true;
handler.group = true;

module.exports = handler;