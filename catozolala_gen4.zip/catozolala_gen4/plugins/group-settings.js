const fs = require('fs');
const path = require('path');
const {
	message
} = require("../catozolala");

let handler = async (m, {
	conn,
	isNsfw,
	prefix,
	isWelcome,
	isBot,
	isCatozolala,
	isPromosi,
	isLinkgc,
	filePath,
	command,
	dataGroup,
	text,
	db,
	isAdmins,
	isAntibot,
	isAntipromosi,
	getGroupData,
	isAntilink,
	cmd,
	dbFire,
	groupMetadata
}) => {
	try {

		const groupId = await dbFire.encodePath(groupMetadata.id);
		const groupRef = db.ref(`groups/${groupId}`);
		const snapshot = await groupRef.once('value');
		const groupData = snapshot.val();
		if (!groupData) return await m.reply('*Group belum terdaftar di database.*');

		let fitur, statusKey;

		if (command === 'antipromosi') {
			fitur = 'antipromosi';
			statusKey = 'Fitur Anti Promosi';
		} else if (command === 'antilinkgc') {
			fitur = 'antilinkgc';
			statusKey = 'Fitur Anti Link Grup';
		} else if (command === "catozolala") {
			fitur = 'catozolala';
			statusKey = 'Fitur Ai Bot';
		} else if (command === 'bot') {
			fitur = 'bot_public';
			statusKey = 'Fitur Bot';
		} else if (command === 'welcome') {
			fitur = 'welcome';
			statusKey = 'Fitur Welcome Group';
		} else if (command === 'nsfw') {
			fitur = 'nsfw';
			statusKey = 'Fitur Nsfw Group';
		} else if (command === "antibot") {
			fitur = 'antibot';
			statusKey = 'Fitur Antibot Group';
		} else if (command === "antipromosi") {
			fitur = 'antipromosi';
			statusKey = 'Fitur Antipromosi Groups';
		} else if (command === "antilinkall") {
			fitur = 'antilink';
			statusKey = 'Fitur Antilinkall Groups';
		} else if (command === 'groupsettings') {
			let djs = [];

			djs.push({
				name: "Anti Promosi",
				cmd: "antipromosi",
				status: await isPromosi(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: "Anti Link GC",
				cmd: "antilinkgc",
				status: await isLinkgc(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: "Catozolala",
				cmd: "catozolala",
				status: await isCatozolala(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: "Bot",
				cmd: "bot",
				status: await isBot(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: "Welcome",
				cmd: "welcome",
				status: await isWelcome(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: "NSFW",
				cmd: "nsfw",
				status: await isNsfw(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: 'Antibot',
				cmd: 'antibot',
				status: await isAntibot(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: 'Antipromosi',
				cmd: 'antipromosi',
				status: await isAntipromosi(groupMetadata) ? "on" : "off"
			});
			djs.push({
				name: 'Antilinkall',
				cmd: 'antilinkall',
				status: await isAntilink(groupMetadata) ? "on" : "off"
			});

			const rows = djs.map(item => ({
				header: `Silahkan Pilih Fitur`,
				title: `${item.name}`,
				description: `Status: ${item.status}`,
				id: `${prefix + item.cmd}`
			}));

			const buttonParams = {
				title: "Select Options",
				sections: [{
					"catozolala": "catozolala",
					rows: rows
				}]
			};

			const buttonParamsJson = JSON.stringify(buttonParams);
			sendButtonParams(m, conn, buttonParamsJson, "*Silahkan pilih untuk settings group*", "Klick button di bawah")
			return
		} else {
			return await m.reply(`Fitur *${command}* tidak ditemukan.`);
		}

		if (!text) {
			const status = groupData[fitur] ? 'AKTIF' : 'NONAKTIF';
			return await conn.reply(m.chat, {
				text: "",
				title: `Status *${statusKey}* saat ini: *${status}*.\n\nGunakan perintah:\n- ${cmd} on\n- ${cmd} off`,
				subtitle: "",
				footer: "",
				quickReplies: [{
						name: "on",
						rowId: cmd + " on"
					},
					{
						name: "off",
						rowId: cmd + " off"
					},
				]
			});
		}

		const lower = text.trim().toLowerCase();
		if (lower !== 'on' && lower !== 'off') {
			return await conn.reply(m.chat, {
				text: "",
				title: `Pilihan hanya *on* atau *off*.\nContoh: *${cmd} on*`,
				subtitle: "",
				footer: "",
				quickReplies: [{
						name: "on",
						rowId: cmd + " on"
					},
					{
						name: "off",
						rowId: cmd + " off"
					},
				]
			});
		}

		await groupRef.update({
			[fitur]: lower === 'on'
		});

		global.db.data.groups = global.db.data.groups || {};
		global.db.data.groups[groupId] = {
			...global.db.data.groups[groupId],
			[fitur]: lower === 'on'
		};

		await m.reply(`*${statusKey}* sekarang: *${lower === 'on' ? 'AKTIF' : 'NONAKTIF'}*`);

	} catch (e) {
		console.error('Terjadi error saat proses:', e);
		await m.reply('Terjadi kesalahan dalam memproses perintah.');
	}
};

async function copyMessage(m, conn, teks, copyTeks) {
	let msg = generateWAMessageFromContent(
		m.chat, {
			viewOnceMessage: {
				message: {
					interactiveMessage: {
						body: {
							text: teks
						},
						nativeFlowMessage: {
							buttons: [{
								name: "cta_copy",
								buttonParamsJson: `{\"display_text\":\"Copy Command\",\"id\":\"123456789\",\"copy_code\":\"${copyTeks}\"}`
							}]
						}
					}
				}
			}
		}, {
			quoted: m
		}
	);

	await conn.relayMessage(msg.key.remoteJid, msg.message, {
		messageId: msg.key.id,
	});
}

async function sendButtonParams(m, conn, buttonParamsJson, teks, proto1) {

	let msg = generateWAMessageFromContent(m.chat, {
		viewOnceMessage: {
			message: {
				messageContextInfo: {
					deviceListMetadata: {},
					deviceListMetadataVersion: 2
				},
				interactiveMessage: proto.Message.InteractiveMessage.create({
					body: proto.Message.InteractiveMessage.Body.create({
						text: teks
					}),
					footer: proto.Message.InteractiveMessage.Footer.create({
						text: proto1
					}),
					nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
						buttons: [{
							name: "single_select",
							buttonParamsJson
						}]
					})
				})
			}
		}
	}, {});

	return conn.relayMessage(msg.key.remoteJid, msg.message, {
		messageId: msg.key.id
	});
}

handler.help = ["on/off"];
handler.command = ['antipromosi', 'nsfw', 'groupsettings', 'welcome', 'catozolala', 'antibot', 'antilinkgc', 'bot', 'antipromosi', 'antilinkall'];
handler.tags = ["group"];
handler.admin = true;
handler.group = true;

module.exports = handler;