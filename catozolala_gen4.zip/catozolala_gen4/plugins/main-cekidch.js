let handler = async (m, {conn, text, command, prefix, cmd}) => {
  if (!text) return m.reply(`\`Example:\` < https://whatsapp.com/channel/ >`)
  if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
  let result = text.split('https://whatsapp.com/channel/')[1]
  let res = await conn.newsletterMetadata("invite", result)
  let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
  m.reply(teks)
}

handler.tags = ["main"];
handler.help = ["link"];
handler.command = ["cekidch"];

module.exports = handler