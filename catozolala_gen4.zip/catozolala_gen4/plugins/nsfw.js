const axios = require('axios');
const fetch = require('node-fetch');
const fs = require('fs');

const handler = async (m, {
	command,
	conn
}) => {
	try {
		const data = global;

		if (command == 'nsfwloli') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfwloli.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'nsfwfoot') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfwfoot.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'nsfwass') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfwass.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'nsfwbdsm') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfwbdsm.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'nsfwcum') {
			const res = `https://api.cafirexos.com/api/nsfw/nsfwcum`;
			conn.sendMessage(m.chat, {
				image: {
					url: res
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'nsfwero') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfwero.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'nsfwfemdom') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfwfemdom.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'nsfwglass') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfwglass.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}


		if (command == 'nsfworgy') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/nsfworgy.json`)).data;
			const haha = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: haha
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'tetas') {
			const resError = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/tetas.json`)).data;
			let res = await conn.getFile(`https://api-fgmods.ddns.net/api/nsfw/boobs?apikey=fg-dylux`).data;
			if (res == '' || !res || res == null) res = await resError[Math.floor(resError.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: res
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'booty') {
			const resError = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/booty.json`)).data;
			let res = await conn.getFile(`https://api-fgmods.ddns.net/api/nsfw/ass?apikey=fg-dylux`).data;
			if (res == '' || !res || res == null) res = await resError[Math.floor(resError.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: res
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'ecchi') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/ecchi.json`)).data;
			const url = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'furro') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/furro.json`)).data;
			const url = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'trapito') {
			const res = await fetch(`https://api.waifu.pics/nsfw/trap`);
			const json = await res.json();
			const url = json.url;
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'imagenlesbians') {
			const resError = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/imagenlesbians.json`)).data;
			let res = await conn.getFile(`https://api-fgmods.ddns.net/api/nsfw/lesbian?apikey=fg-dylux`).data;
			if (res == '' || !res || res == null) res = await resError[Math.floor(resError.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: res
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'panties') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/panties.json`)).data;
			const url = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'pene') {
			const resError = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/pene.json`)).data;
			let res = await conn.getFile(`https://api-fgmods.ddns.net/api/nsfw/penis?apikey=fg-dylux`).data;
			if (res == '' || !res || res == null) res = await resError[Math.floor(resError.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: res
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'porno') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/porno.json`)).data;
			const url = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'randomxxx') {
			const rawjsonn = ['https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/tetas.json', 'https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/booty.json', 'https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/imagenlesbians.json', 'https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/panties.json', 'https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/porno.json'];
			const rawjson = await rawjsonn[Math.floor(rawjsonn.length * Math.random())];
			const res = (await axios.get(rawjson)).data;
			const url = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'pechos') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/pechos.json`)).data;
			const url = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'yaoi') {
			const res = await fetch(`https://nekobot.xyz/api/image?type=yaoi`);
			const json = await res.json();
			const url = json.message;
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'yaoi2') {
			const res = await fetch(`https://purrbot.site/api/img/nsfw/yaoi/gif`);
			const json = await res.json();
			const url = json.link;
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'yuri') {
			const res = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/yuri.json`)).data;
			const url = await res[Math.floor(res.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

		if (command == 'yuri2') {
			const resError = (await axios.get(`https://raw.githubusercontent.com/BrunoSobrino/TheMystic-Bot-MD/master/src/JSON/yuri.json`)).data;
			const res = await fetch(`https://purrbot.site/api/img/nsfw/yuri/gif`);
			const json = await res.json();
			let url = json.link;
			if (url == '' || !url || url == null) url = await resError[Math.floor(resError.length * Math.random())];
			conn.sendMessage(m.chat, {
				image: {
					url: url
				},
				caption: `_${command}_`.trim()
			}, {
				quoted: m
			});
		}

	} catch (err) {
		console.error(`NSFW command error: ${command}`, err);
		conn.sendMessage(m.chat, {
			text: '❌ Gagal mengambil gambar.'
		}, {
			quoted: m
		});
	}

};

handler.command = ['nsfwloli', 'nsfwfoot', 'nsfwass', 'nsfwbdsm', 'nsfwcum', 'nsfwero', 'nsfwfemdom', 'nsfwglass', 'nsfworgy', 'yuri', 'yuri2', 'yaoi', 'yaoi2', 'panties', 'tetas', 'booty', 'ecchi', 'furro', 'trapito', 'imagenlesbians', 'pene', 'porno', 'randomxxx', 'pechos'];
handler.tags = ['nsfw'];
handler.limit = true;
handler.group = true;
handler.nsfw = true;

module.exports = handler;
module.exports = handler;