const fs = require('fs');
const path = require('path');
const {
	message
} = require("../catozolala");

let handler = async (m, {
	conn,
	isNsfw,
	prefix,
	isWelcome,
	isBot,
	isCatozolala,
	isPromosi,
	isLinkgc,
	filePath,
	command,
	dataGroup,
	text,
	db,
	isAdmins,
	isAntibot,
	getGroupData,
	cmd,
	dbFire,
	groupMetadata
}) => {
	try {

		const groupId = await dbFire.encodePath(groupMetadata.id);
		const groupRef = db.ref(`groups/${groupId}`);
		const snapshot = await groupRef.once('value');
		const groupData = snapshot.val();
		if (!groupData) return await m.reply('*Group belum terdaftar di database.*');

		let fitur, statusKey;

		if (command === 'banchat') {
			fitur = 'bot_public';
			statusKey = 'off';
		} else if (command === "unbanchat") {
		    fitur = 'bot_public';
		    statusKey = 'on';
		} else if (command === 'groupsettings') {
			let djs = [];

			djs.push({
				name: "Bot",
				cmd: "bot",
				status: isBot(groupMetadata) ? "on" : "off"
			});
			
		} else {
			return await m.reply(`Fitur *${command}* tidak ditemukan.`);
		}

		const lower = statusKey.trim().toLowerCase();
		if (lower !== 'on' && lower !== 'off') {
			return;
		}

		await groupRef.update({
			[fitur]: lower === 'on'
		});
		
		global.db.data.groups = global.db.data.groups || {};
		global.db.data.groups[groupId] = {
		   ...global.db.data.groups[groupId],
		   [fitur]: lower === 'on'
		};
		
		await m.reply(`*Bot* sekarang: *${lower === 'on' ? 'AKTIF' : 'NONAKTIF'}*`);

	} catch (e) {
		console.error('Terjadi error saat proses:', e);
		await m.reply('Terjadi kesalahan dalam memproses perintah.');
	}
};

async function copyMessage(m, conn, teks, copyTeks) {
	let msg = generateWAMessageFromContent(
		m.chat, {
			viewOnceMessage: {
				message: {
					interactiveMessage: {
						body: {
							text: teks
						},
						nativeFlowMessage: {
							buttons: [{
								name: "cta_copy",
								buttonParamsJson: `{\"display_text\":\"Copy Command\",\"id\":\"123456789\",\"copy_code\":\"${copyTeks}\"}`
							}]
						}
					}
				}
			}
		}, {
			quoted: m
		}
	);

	await conn.relayMessage(msg.key.remoteJid, msg.message, {
		messageId: msg.key.id,
	});
}

async function sendButtonParams(m, conn, buttonParamsJson, teks, proto1) {

	let msg = generateWAMessageFromContent(m.chat, {
		viewOnceMessage: {
			message: {
				messageContextInfo: {
					deviceListMetadata: {},
					deviceListMetadataVersion: 2
				},
				interactiveMessage: proto.Message.InteractiveMessage.create({
					body: proto.Message.InteractiveMessage.Body.create({
						text: teks
					}),
					footer: proto.Message.InteractiveMessage.Footer.create({
						text: proto1
					}),
					nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
						buttons: [{
							name: "single_select",
							buttonParamsJson
						}]
					})
				})
			}
		}
	}, {});

	return conn.relayMessage(msg.key.remoteJid, msg.message, {
		messageId: msg.key.id
	});
}

handler.command = ['banchat', 'unbanchat'];
handler.tags = ["owner"];
handler.owner = true;
handler.group = true;

module.exports = handler;