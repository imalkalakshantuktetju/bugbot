let _1 = async (m, { conn, cmd, text }) => {
  if (!text) {
    m.reply(
      `📌 *Contoh Penggunaan:*\n` +
      `\`${cmd} <teks>\`\n\n` +
      `💡 *Contoh:* \`${cmd} Halo semuanya!\`\n\n` +
      `📎 Bisa juga digunakan dengan *reply* gambar/video atau *caption*!`
    )
    return
  }

  let quotedMsg = m.quoted ? (m.quoted.message || m.quoted) : m.message?.imageMessage || null
  let messageMedia = quotedMsg || m.message
  let mime = messageMedia?.mimetype || ''

  const isImage = mime.startsWith('image/')
  const isVideo = mime.startsWith('video/')

  let getGroups = await conn.groupFetchAllParticipating();
  let groups = Object.entries(getGroups).slice(0).map(entry => entry[1]);
  let allGroupIds = groups.map(v => v.id)
  
  await conn.sendMessage(m.chat, {
			react: {
				text: "🕘",
				key: m.key
			}
		});
			
  for (let id of allGroupIds) {
    try {
      if (isImage || isVideo) {
        const data = await conn.downloadMediaMessage(messageMedia)
        await conn.sendMessage(id, {
          [isImage ? 'image' : 'video']: data,
          caption: text
        })
      } else {
        await conn.sendMessage(id, { text })
      }
    } catch (err) {
      console.error(`❌ Gagal kirim pesan ke grup ${id}:`, err)
    }

    await delay(3000)
  }
  
  m.reply(`Sukses ke kirim ke group total ${allGroupIds.length}`);
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

_1.tags = ["owner"]
_1.command = ["bcgc", "broadcastgc"]
_1.owner = true

module.exports = _1