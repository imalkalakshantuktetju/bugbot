let handler = async (m,{conn}) => {
        var http = require('http')
        http.get({
          'host': 'api.ipify.org',
          'port': 80,
          'path': '/'
        }, function(resp) {
          resp.on('data', function(ip) {
            m.reply("IP : " + ip);
          })
        })
}

handler.tags = ["owner"];
handler.command = ["getip"];
handler.owner = true;

module.exports = handler;