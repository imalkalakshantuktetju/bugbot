let handler = async (m,{conn, cmd, text}) => {
        if (!text) return m.reply(`*\`Example:\`* ${cmd} < link group > `)
        var ini_urrrl = text.split('https://chat.whatsapp.com/')[1]
        var data = await conn.groupAcceptInvite(ini_urrrl).then((res) => m.reply(`Berhasil Join ke grup...`)).catch((err) => m.reply(`Eror.. Munkin bot telah di kick Dari grup tersebut`))
}
handler.tags = ["owner"]
handler.command = ["join"]
handler.owner = true

module.exports = handler