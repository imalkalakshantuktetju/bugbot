const os = require("os");
const fs = require("fs");
const { createCanvas } = require("canvas");
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);

let handler = async (m, { conn, isCreator }) => {
    // helper untuk formatting
    const formatp = bytes => {
        const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
        if (bytes === 0) return "0 Bytes";
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
    };
    const runtime = seconds => {
        const pad = s => (s < 10 ? "0" : "") + s;
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        return `${pad(hours)}:${pad(minutes)}:${pad(secs)}`;
    };

    // Hitung statistik CPU & RAM
    const cpusArr = os.cpus().map(c => {
        c.total = Object.values(c.times).reduce((a, b) => a + b, 0);
        return c;
    });
    const cpuSum = cpusArr.reduce((acc, c) => {
        acc.total += c.total;
        acc.speed += c.speed;
        for (let t in c.times) acc.times[t] += c.times[t];
        return acc;
    }, { speed: 0, total: 0, times: { user:0, nice:0, sys:0, idle:0, irq:0 } });
    const cpuUsageIcon = cpuSum.times.idle / cpuSum.total < 0.85 ? "🟢" : "🔴";
    const ramUsageIcon = (os.totalmem() - os.freemem()) / os.totalmem() < 0.75 ? "🟢" : "🔴";

    // Buat canvas status singkat
    const latensi = new Date() - performance.now();
    const canvas = createCanvas(700, 400);
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#1E1E1E";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#00FF99";
    ctx.font = "bold 24px Arial";
    ctx.fillText("📡 BOT STATUS MONITOR", 20, 40);
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "18px Consolas";
    ctx.fillText(`📶 Respon    : ${latensi} ms`, 20, 80);
    ctx.fillText(`🕐 Runtime   : ${runtime(process.uptime())}`, 20, 115);
    ctx.fillText(`💾 RAM       : ${ramUsageIcon} ${formatp(os.totalmem()-os.freemem())} / ${formatp(os.totalmem())}`, 20, 150);
    ctx.fillText(`🧠 CPU       : ${cpuUsageIcon} ${cpusArr[0].model.trim()} (${(cpuSum.speed/cpusArr.length).toFixed(2)} MHz)`, 20, 185);
    let offsetY = 225;
    for (let [k, v] of Object.entries(cpuSum.times)) {
        ctx.fillText(` - ${k}: ${((v / cpuSum.total)*100).toFixed(2)}%`, 40, offsetY);
        offsetY += 25;
    }
    const buffer = canvas.toBuffer("image/png");
    
        // ======== bagian tambahan: text info lengkap ==========

    const uptimeHours = (os.uptime()/3600).toFixed(2);
    const totalMemGB = (os.totalmem()/1024**3).toFixed(2);
    const freeMemGB = (os.freemem()/1024**3).toFixed(2);
    const net = os.networkInterfaces();
    const userInfo = os.userInfo();
    const tempFiles = fs.readdirSync(os.tmpdir());

    // detail CPU
    const cpuInfo = os.cpus().map((cpu,i)=>(
        `CPU ${i+1}:
  • Model : ${cpu.model}
  • Speed : ${cpu.speed} MHz
  • Times :
    - user : ${cpu.times.user}
    - sys  : ${cpu.times.sys}
    - idle : ${cpu.times.idle}
    - irq  : ${cpu.times.irq}
`
    )).join("\n");

    // detail network
    const networkInfo = Object.entries(net).map(([name, addrs])=>(
        `Interface: ${name}
${addrs.map(a=>
  `  • ${a.family} - ${a.address} (MAC: ${a.mac}) internal: ${a.internal}`
).join("\n")}`
    )).join("\n\n");

    // susun string panjang
    const textInfo = `*📡 OS & System Info Lengkap*
${readmore}
🖥️ Platform      : ${os.platform()}
🔧 Arsitektur    : ${os.arch()}
🗂️ OS Type       : ${os.type()}
📦 Release       : ${os.release()}
🏠 Home Dir      : ${os.homedir()}
📁 Temp Dir      : ${os.tmpdir()}
💾 Total RAM     : ${totalMemGB} GB
📉 Free RAM      : ${freeMemGB} GB
⏱️ Uptime        : ${uptimeHours} jam
🕹️ Hostname      : ${os.hostname()}
👤 User Info     : ${userInfo.username}

====================
*🧠 CPU Info*
${cpuInfo}

====================
*🌐 Network Interfaces*
${networkInfo}

====================
📂 Temp Files (${tempFiles.length}):
${tempFiles.slice(0,10).map((f,i)=>`  ${i+1}. ${f}`).join("\n")}${tempFiles.length>10?`\n  ... (${tempFiles.length-10} lainnya)`:''}
`;

    // kirim text info
    //await m.reply(textInfo);
    
    // Kirim gambar status
    await conn.sendMessage(m.chat, {
        image: buffer,
        caption: `📈 *Status Bot*\n\n🕐 Uptime: ${runtime(process.uptime())}\n📶 Ping: ${latensi} ms\n💾 RAM: ${ramUsageIcon} ${formatp(os.totalmem()-os.freemem())} / ${formatp(os.totalmem())}\n🧠 CPU: ${cpuUsageIcon} ${(cpuSum.speed/cpusArr.length).toFixed(2)} MHz\n\n${textInfo}`,
    }, { quoted: m });

};

handler.tags = ["owner"];
handler.command = ["ping"];
handler.owner = true;

module.exports = handler;

/*const os = require("os");
const { createCanvas } = require("canvas");
const fs = require("fs");

let handler = async (m, { conn, isCreator, readmore }) => {
    if (!isCreator) return m.reply("❌ Khusus owner!");

    const formatp = (bytes) => {
        const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
        if (bytes === 0) return "0 Byte";
        const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
        return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
    };

    const runtime = (seconds) => {
        const pad = (s) => (s < 10 ? "0" : "") + s;
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        return `${pad(hours)}:${pad(minutes)}:${pad(secs)}`;
    };

    const used = process.memoryUsage();
    const cpus = os.cpus().map(cpu => {
        cpu.total = Object.values(cpu.times).reduce((a, b) => a + b, 0);
        return cpu;
    });

    const cpu = cpus.reduce((acc, cpu, _, { length }) => {
        acc.total += cpu.total;
        acc.speed += cpu.speed / length;
        for (const type in cpu.times) acc.times[type] += cpu.times[type];
        return acc;
    }, { speed: 0, total: 0, times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } });

    const latensi = new Date() - performance.now();
    const cpuUsage = cpu.times.idle / cpu.total < 0.85 ? "🟢" : "🔴";
    const ramUsage = (os.totalmem() - os.freemem()) / os.totalmem() < 0.75 ? "🟢" : "🔴";

    const canvas = createCanvas(700, 400);
    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "#1E1E1E";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#00FF99";
    ctx.font = "bold 24px Arial";
    ctx.fillText("📡 BOT STATUS MONITOR", 20, 40);

    ctx.fillStyle = "#FFFFFF";
    ctx.font = "18px Consolas";

    ctx.fillText(`📶 Respon    : ${latensi} ms`, 20, 80);
    ctx.fillText(`🕐 Runtime   : ${runtime(process.uptime())}`, 20, 110);
    ctx.fillText(`💾 RAM       : ${ramUsage} ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}`, 20, 140);

    ctx.fillText(`🧠 CPU       : ${cpuUsage} ${cpus[0].model.trim()} (${cpu.speed.toFixed(2)} MHz)`, 20, 170);

    let offsetY = 210;
    Object.entries(cpu.times).forEach(([k, v]) => {
        const perc = (100 * v / cpu.total).toFixed(2);
        ctx.fillText(` - ${k}: ${perc}%`, 40, offsetY);
        offsetY += 25;
    });

    const buffer = canvas.toBuffer("image/png");

    await conn.sendMessage(m.chat, {
        image: buffer,
        caption: `📈 *Status Bot*\n\n🕐 Uptime: ${runtime(process.uptime())}\n📶 Ping: ${latensi} ms\n💾 RAM: ${ramUsage} ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}\n🧠 CPU: ${cpuUsage} ${cpus[0].model.trim()} (${cpu.speed.toFixed(2)} MHz)`,
    }, { quoted: m });
};

handler.tags = ["owner"];
handler.command = ["ping"];
handler.owner = true;

module.exports = handler;
*/