const axios = require("axios");
const fs = require("fs");
const path = require("path");
const unzipper = require("unzipper");

let created_by_catozoalala_rimuru_6281938830020_nomer_owner = async (m, {
	conn,
	text
}) => {
    if (!text) return m.reply("⚠️ Masukkan link zip GitHub!\nContoh:\n.update https://github.com/username/repo/archive/refs/heads/main.zip");

    const url = text.trim();
    const zipPath = "./temp_update.zip";
    const extractTo = "./temp_update";

    m.reply("Mengunduh update ZIP dari GitHub...");

    try {
        const response = await axios({ method: "GET", url, responseType: "stream" });
        const writer = fs.createWriteStream(zipPath);
        response.data.pipe(writer);
        await new Promise((resolve, reject) => {
            writer.on("finish", resolve);
            writer.on("error", reject);
        });

        if (fs.existsSync(extractTo)) fs.rmSync(extractTo, { recursive: true, force: true });

        await fs.createReadStream(zipPath).pipe(unzipper.Extract({ path: extractTo })).promise();

        const folderName = fs.readdirSync(extractTo)[0];
        const sourceDir = path.join(extractTo, folderName);
        const targetDir = ".";

        const filesInZip = [];

        const copyAndListFiles = (src, dest) => {
            const items = fs.readdirSync(src);
            for (const item of items) {
                const srcPath = path.join(src, item);
                const destPath = path.join(dest, item);
                const relativePath = path.relative(sourceDir, srcPath);

                if (fs.lstatSync(srcPath).isDirectory()) {
                    if (!fs.existsSync(destPath)) fs.mkdirSync(destPath);
                    copyAndListFiles(srcPath, destPath);
                } else {
                    fs.copyFileSync(srcPath, destPath);
                    filesInZip.push(relativePath);
                }
            }
        };

        copyAndListFiles(sourceDir, targetDir);

        const ignore = ["node_modules", ".git", "sessions"];
        const walkAndDelete = (dir) => {
            const items = fs.readdirSync(dir);
            for (const item of items) {
                if (ignore.includes(item)) continue;

                const fullPath = path.join(dir, item);
                const relative = path.relative(".", fullPath);

                if (fs.lstatSync(fullPath).isDirectory()) {
                    walkAndDelete(fullPath);
                    if (fs.existsSync(fullPath) && fs.readdirSync(fullPath).length === 0) {
                        fs.rmdirSync(fullPath);
                    }
                } else {
                    if (!filesInZip.includes(relative)) {
                        fs.unlinkSync(fullPath);
                    }
                }
            }
        };

        walkAndDelete(".");

        fs.unlinkSync(zipPath);
        fs.rmSync(extractTo, { recursive: true, force: true });

        m.reply("✅ Sinkronisasi update berhasil!\nBot akan restart...");
        setTimeout(() => process.exit(), 2000);
    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal update:\n" + e.message);
    }
}

created_by_catozoalala_rimuru_6281938830020_nomer_owner.command = ["update"];
created_by_catozoalala_rimuru_6281938830020_nomer_owner.tags = ["owner"];
created_by_catozoalala_rimuru_6281938830020_nomer_owner.owner = true;

module.exports = created_by_catozoalala_rimuru_6281938830020_nomer_owner;