const yts = require('yt-search');
const fs = require('fs');
const { format } = require('util');

let handler = async (m, {
    conn,
    prefix,
    command,
    text,
    config
}) => {
    let input = `[❗] Masukan Salah

Contoh: /${prefix + command} Dj The Spectre`;
    if (!text) return m.reply(input);

    conn.sendMessage(m.chat, { react: { text: '🔎', key: m.key } });

    let id = m.sender;
    let search = await yts(text);
    if (!search) throw m.reply('Video Not Found, Try Another Title');
    let vid = search.videos[0];
    let { title, thumbnail, timestamp, views, ago, url } = vid;
    
    const safeTitle = sanitizeFileName(title);
    const writableStream = fs.createWriteStream(`./tmp/${safeTitle}.mp3`);

    if (!conn.data) conn.data = {};
    conn.data[id] = {
        user: id,
        title: title,
        times: timestamp,
        views: views,
        ago: ago,
        url: url,
        thumbnail: thumbnail
    };
    
    const hydra = '〘🜲〙';
    const botdate = new Date().toLocaleDateString('id-ID');
    const titlebot = config.nameBots;
    let cap = `*[ Y O U T U B E  P L A Y ]*`;
    let captvid = `

╭─❖ *「 RINCIAN VIDEO 」*
│ *Durasi:* ${timestamp}
│ *Views:* ${views}
│ *Rilis:* ${ago}
│ *Link:* ${url}
╰───────────────⬣
`;

    const buttons = [
        { buttonId: `.ytmp3 ${url}`, buttonText: { displayText: 'audio' }, type: 1 },
        { buttonId: `.ytmp4 ${url}`, buttonText: { displayText: 'video' }, type: 1 },
    ];
       
    const buttonMessage = {
		document: fs.readFileSync("./package.json"),
		fileName: title,
		fileLength: Infinity,
		pageCount: Infinity,
		mimetype: 'application/pdf',
		caption: `       ${cap}
        ${captvid}`,
		jpegThumbnail: global.media,
		footer: `Powered by ${name}`,
		buttons: buttons,
		headerType: 6,
		viewOnce: true,
		forwardingScore: 99999,
		isForwarded: true,
		mentions: [m.sender],
		contextInfo: {
		    thumbnailUrl: thumbnail,
		    forwardingScore: 99999,
		    isForwarded: true,
		    mentionedJid: [m.sender],
			externalAdReply: {
			    sourceUrl: `instagram.com`,
				containsAutoReply: true,
				mediaType: 1,
				thumbnailUrl: thumbnail,
				renderLargerThumbnail: true,
				title: title,
				body: 'Powered by whatsapp'
			}
		}
	};

	return conn.sendMessage(m.chat, buttonMessage, {
		quoted: {
			key: {
				remoteJid: "status@broadcast",
				fromMe: false,
				id: m.id,
				participant: "0@s.whatsapp.net"
			},
			message: {
				conversation: m.text || "By Catozolala"
			}
		}
	});
	
    setTimeout(() => {
        conn.sendMessage(m.chat, { react: { text: '🎶️', key: m.key } });
        delete conn.data[id];
    }, 30000);
};

handler.help = ["search"]
handler.tags = ["downloader"];
handler.command = ["play"]

function sanitizeFileName(name) {
  return name.replace(/[\/\\?%*:|"<>]/g, '-');
}

module.exports = handler;