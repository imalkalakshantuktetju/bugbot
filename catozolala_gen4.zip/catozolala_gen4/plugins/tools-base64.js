let Fruatre = async (m, { conn }) => {
  const q = m.quoted || m;
  const mime = q.mimetype || '';
  const isMedia = /image|video|audio|application|sticker/.test(mime);

  if (isMedia) {
    const buffer = await q.download();
    const base64 = `data:${mime};base64,${buffer.toString('base64')}`;
    return m.reply(base64);
  }

  const text = q.text || m.text;
  if (!text) throw m.reply('masukkan teks atau reply media');

  m.reply(Buffer.from(text, 'utf-8').toString('base64'));
};

Fruatre.help = ['base64'];
Fruatre.tags = ['tools'];
Fruatre.command = ['base64'];

module.exports = Fruatre;