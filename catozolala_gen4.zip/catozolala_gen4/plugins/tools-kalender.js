const { createCanvas } = require('canvas');
const moment = require('moment-timezone');

let handler = async (m, { conn, text }) => {
  const timezone = 'Asia/Jakarta';
  const currentDate = moment.tz(timezone);
  const currentMonth = currentDate.month();
  const currentYear = currentDate.year();
  const today = currentDate.date();

  const months = [
    'januari', 'februari', 'maret', 'april', 'mei', 'juni',
    'juli', 'agustus', 'september', 'oktober', 'november', 'desember',
  ];
  let queryMonth = months.findIndex(month => month.toLowerCase() === (text || '').toLowerCase());
  if (queryMonth === -1) queryMonth = currentMonth;

  const displayDate = moment.tz(timezone).month(queryMonth).year(currentYear).startOf('month');
  const monthName = months[queryMonth];
  const year = currentYear;

  const holidays = [
    { date: '2025-01-01', description: 'Tahun Baru 2025 Masehi' },
    { date: '2025-01-27', description: 'Isra Mikraj Nabi Muhammad SAW' },
    { date: '2025-01-29', description: 'Tahun Baru Imlek 2576 Kongzili' },
    { date: '2025-03-29', description: 'Hari Suci Nyepi Tahun Baru Saka 1947' },
    { date: '2025-03-31', description: 'Hari Raya Idulfitri 1446 Hijriah' },
    { date: '2025-04-01', description: 'Hari Raya Idulfitri 1446 Hijriah' },
    { date: '2025-04-18', description: 'Wafat Yesus Kristus' },
    { date: '2025-05-01', description: 'Hari Buruh Internasional' },
    { date: '2025-05-12', description: 'Hari Raya Waisak 2569 BE' },
    { date: '2025-05-29', description: 'Kenaikan Isa Almasih' },
    { date: '2025-06-01', description: 'Hari Lahir Pancasila' },
    { date: '2025-06-07', description: 'Hari Raya Iduladha 1446 Hijriah' },
    { date: '2025-06-27', description: 'Tahun Baru Islam 1447 Hijriah' },
    { date: '2025-08-17', description: 'Hari Kemerdekaan Republik Indonesia' },
    { date: '2025-09-05', description: 'Maulid Nabi Muhammad SAW' },
    { date: '2025-12-25', description: 'Hari Raya Natal' },
    { date: '2025-01-28', description: 'Cuti Bersama Tahun Baru Imlek' },
    { date: '2025-03-28', description: 'Cuti Bersama Hari Suci Nyepi' },
    { date: '2025-04-02', description: 'Cuti Bersama Idulfitri 1446 Hijriah' },
    { date: '2025-04-03', description: 'Cuti Bersama Idulfitri 1446 Hijriah' },
    { date: '2025-04-04', description: 'Cuti Bersama Idulfitri 1446 Hijriah' },
    { date: '2025-12-26', description: 'Cuti Bersama Hari Raya Natal' },
  ];

  const holidaysThisMonth = holidays.filter(holiday => moment(holiday.date).month() === queryMonth);

  const daysInMonth = displayDate.daysInMonth();
  const firstDayOfMonth = displayDate.day();

  const canvasWidth = 720;
  const canvasHeight = 880;
  const ctx = createCanvas(canvasWidth, canvasHeight).getContext('2d');

  // Background gradasi biru tua ke hitam
  let gradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
  gradient.addColorStop(0, '#0a1f44');
  gradient.addColorStop(1, '#000000');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvasWidth, canvasHeight);

  // Judul bulan dan tahun dengan shadow
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 36px "Segoe UI", Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.shadowColor = 'rgba(0,0,0,0.7)';
  ctx.shadowBlur = 6;
  ctx.fillText(`${monthName.charAt(0).toUpperCase() + monthName.slice(1)} ${year}`, canvasWidth / 2, 60);
  ctx.shadowBlur = 0;

  // Garis pembatas judul
  ctx.strokeStyle = '#3399ff';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(60, 75);
  ctx.lineTo(canvasWidth - 60, 75);
  ctx.stroke();

  // Hari dalam minggu dengan styling modern
  const daysOfWeek = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
  ctx.font = 'bold 22px "Segoe UI", Arial, sans-serif';
  daysOfWeek.forEach((day, i) => {
    ctx.fillStyle = day === 'Min' ? '#ff6f6f' : '#cce0ff'; // Minggu merah lembut, lainnya biru muda
    ctx.textAlign = 'center';
    ctx.fillText(day, 90 + i * 90, 120);
  });

  // Ukuran kotak tanggal
  const boxSize = 90;
  const startX = 50;
  const startY = 160;

  // Kotak hari: grid dengan garis batas tipis
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 6; i++) { // maksimal 6 baris
    for (let j = 0; j < 7; j++) {
      ctx.strokeRect(startX + j * boxSize, startY + i * boxSize, boxSize, boxSize);
    }
  }

  // Fungsi untuk mendapatkan pasaran Jawa (wage, kliwon, legi, pahing, pon)
  // Siklus 5 hari, mulai dari tanggal 1 Januari 2025 sebagai acuan Legi (misal)
  // Sesuaikan sesuai acuan sebenarnya jika ada
  const pasaranJawa = ['Legi', 'Pahing', 'Pon', 'Wage', 'Kliwon'];
  function getPasaranJawa(date) {
    // Hitung selisih hari dari 1 Januari 2025
    const baseDate = moment.tz('2025-01-01', 'YYYY-MM-DD', timezone);
    const diff = moment.tz(`${year}-${(queryMonth + 1).toString().padStart(2, '0')}-${date.toString().padStart(2, '0')}`, 'YYYY-MM-DD', timezone).diff(baseDate, 'days');
    const idx = diff % 5;
    return pasaranJawa[idx];
  }

  ctx.font = '22px "Segoe UI", Arial, sans-serif';

  for (let date = 1; date <= daysInMonth; date++) {
    const dayOfWeek = (firstDayOfMonth + date - 1) % 7;
    const row = Math.floor((firstDayOfMonth + date - 1) / 7);

    const boxX = startX + dayOfWeek * boxSize;
    const boxY = startY + row * boxSize;

    const centerX = boxX + boxSize / 2;
    const centerY = boxY + boxSize / 2;

    const isToday = queryMonth === currentMonth && date === today;
    const holiday = holidaysThisMonth.find(h => moment(h.date).date() === date);

    // Background lingkaran untuk hari libur dan hari ini
    if (holiday) {
      ctx.fillStyle = 'rgba(255, 111, 111, 0.3)';
      ctx.beginPath();
      ctx.arc(centerX, centerY - 12, 30, 0, 2 * Math.PI);
      ctx.fill();
    }
    if (isToday) {
      ctx.fillStyle = '#3399ff';
      ctx.shadowColor = '#3399ff';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(centerX, centerY - 12, 30, 0, 2 * Math.PI);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // Warna teks tanggal
    if (holiday || dayOfWeek === 0) {
      ctx.fillStyle = '#ff6f6f';
    } else if (isToday) {
      ctx.fillStyle = '#ffffff';
    } else {
      ctx.fillStyle = '#cce0ff';
    }

    ctx.textAlign = 'center';

    // Tulis tanggal di tengah kotak, sedikit naik ke atas untuk kasih ruang pasaran di bawah
    ctx.fillText(date.toString(), centerX, centerY - 10);

    // Tulis pasaran Jawa di bawah tanggal, dengan font lebih kecil dan warna khusus
    const pasaran = getPasaranJawa(date);
    ctx.font = 'bold 14px "Segoe UI", Arial, sans-serif';
    ctx.fillStyle = ['Wage', 'Kliwon'].includes(pasaran) ? '#ffd166' : '#06d6a0'; // Warna kuning untuk Wage/Kliwon, hijau untuk lainnya
    ctx.fillText(pasaran.toLowerCase(), centerX, centerY + 15);

    // Kembali font tanggal
    ctx.font = '22px "Segoe UI", Arial, sans-serif';
  }

  // Garis pembatas untuk list libur
  ctx.strokeStyle = '#3399ff';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(40, startY + 6 * boxSize + 20);
  ctx.lineTo(canvasWidth - 40, startY + 6 * boxSize + 20);
  ctx.stroke();

  // List hari libur dengan font putih dan warna merah untuk tanggal
  ctx.font = '18px "Segoe UI", Arial, sans-serif';
  ctx.fillStyle = '#cce0ff';
  ctx.textAlign = 'left';
  let textY = startY + 6 * boxSize + 60;

  if (holidaysThisMonth.length === 0) {
    ctx.fillText('Tidak ada hari libur di bulan ini.', 50, textY);
  } else {
    holidaysThisMonth.forEach(holiday => {
      const holidayDate = moment(holiday.date).format('DD MMMM YYYY');
      ctx.fillStyle = '#ff6f6f';
      ctx.fillText(holidayDate, 50, textY);
      ctx.fillStyle = '#cce0ff';
      ctx.fillText(`- ${holiday.description}`, 180, textY);
      textY += 30;
    });
  }

  const buffer = ctx.canvas.toBuffer();
  await conn.sendMessage(m.chat, {
    image: buffer,
    caption: `${monthName.charAt(0).toUpperCase() + monthName.slice(1)} ${year}`,
  });
};

handler.help = ['kalender [bulan]'];
handler.tags = ['tools'];
handler.command = ['kalender'];

module.exports = handler;