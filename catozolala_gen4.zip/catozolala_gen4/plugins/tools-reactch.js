let handler = async (m, { conn, text }) => {
  if (!text) {
    await m.reply("Masukkan link channel + teks.\nContoh:\n.reactch https://whatsapp.com/channel/abc123/456 aku sayang kamu");
    return;
  }

  const regex = /https:\/\/whatsapp\.com\/channel\/(\w+)(?:\/(\d+))?/;
  const match = text.match(regex);

  if (!match) {
    await m.reply("URL tidak valid. Format seharusnya: https://whatsapp.com/channel/ID/IDPesan");
    return;
  }

  const channelId = match[1];
  const chatId = match[2];

  if (!chatId) {
    await m.reply("ID pesan tidak ditemukan dalam URL.");
    return;
  }

  const afterUrlText = text.replace(regex, '').trim();
  const emojiText = emojiFontFormatted(afterUrlText || 'HI');

  try {
    const data = await conn.newsletterMetadata("invite", channelId);
    if (!data) {
      await m.reply("Gagal mengambil metadata channel.");
      return;
    }

    await conn.newsletterReactMessage(data.id, chatId, emojiText);
    await m.reply(`Sukses kirim reaksi:\n${emojiText}`);

  } catch (err) {
    console.error(err);
    await m.reply("Terjadi kesalahan saat mengirim reaksi.");
  }
};

const emojiFontFormatted = (text) => {
  const separator = '🅭';
  return text.split(' ').map(word => emojiFont(word)).join(separator);
};

const emojiFont = (text) => {
  const map = {
    a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖', h: '🅗',
    i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝', o: '🅞', p: '🅟',
    q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤', v: '🅥', w: '🅦', x: '🅧',
    y: '🅨', z: '🅩',
    A: '🅐', B: '🅑', C: '🅒', D: '🅓', E: '🅔', F: '🅕', G: '🅖', H: '🅗',
    I: '🅘', J: '🅙', K: '🅚', L: '🅛', M: '🅜', N: '🅝', O: '🅞', P: '🅟',
    Q: '🅠', R: '🅡', S: '🅢', T: '🅣', U: '🅤', V: '🅥', W: '🅦', X: '🅧',
    Y: '🅨', Z: '🅩',
    ' ': ' '
  };
  return [...text].map(c => map[c] || c).join('');
};

handler.help = ['reactch <link channel> <teks>'];
handler.tags = ['tools'];
handler.command = ["reactch"];

module.exports = handler;