const fs = require('fs/promises');
const path = require('path');

let handler = async (ctx, arg, {
	config,
	userId,
	username,
	currentDate,
	command
}) => {

	const caption = `<pre><code>╭─〔 Menu Bot ${config.name} 〕
│
│ ${config.telegramBullet} ID     : ${userId}
│ ${config.telegramBullet} Nama   : ${username}
│ ${config.telegramBullet} Tanggal: ${currentDate}
│ ${config.telegramBullet} Status : • Aktif
│ ${config.telegramBullet} Versi  : 1.0.0
│
╰───────────────⭓</code></pre>`;

	const replyMarkup = {
		inline_keyboard: [
			[{
				text: 'Allmenu',
				callback_data: 'allmenu'
			}],
			[{
					text: 'Cek User',
					callback_data: `copy_id_${userId}`
				},
				{
					text: 'Owner',
					callback_data: 'owner'
				}
			]
		]
	};

	if (typeof arg === 'string') {
		arg = arg.toLowerCase();

		if (arg === 'allmenu') {
			const groups = await loadTelegramPluginsByTags();
			let menuText = '';

			for (const tag in groups) {
				menuText += `📁 ${kapitalAwal(tag)} Menu\n`;
				for (const cmd of groups[tag]) {
					menuText += `/${cmd.command}\n`;
				}
				menuText += '\n';
			}

			const captionLimit = 1000;
			const trimmedText = menuText.trim().slice(0, captionLimit);

			await ctx.editMessageCaption(`<b>📋 All Menu</b>\n\n${trimmedText}`, {
				parse_mode: 'HTML',
				reply_markup: {
					inline_keyboard: [
						[{
							text: 'Back',
							callback_data: 'back'
						}],
						[{
							text: 'Cek User',
							callback_data: `copy_id_${userId}`
						}]
					]
				}
			});
			return;
		}

		if (arg.startsWith('copy_id_')) {
			await ctx.editMessageCaption(`ID Kamu:\n<pre><code>${userId}</code></pre>`, {
				parse_mode: 'HTML',
				reply_markup: {
					inline_keyboard: [
						[{
							text: '🔙 Kembali',
							callback_data: 'back'
						}]
					]
				}
			});
			return;
		}

		if (['back', 'menu', 'start', 'back_menu_contact'].includes(arg)) {
			if (
				global.lastSentContactMsg &&
				global.lastSentContactMsg[userId] &&
				Array.isArray(global.lastSentContactMsg[userId]) &&
				global.lastSentContactMsg[userId].length > 0
			) {
				for (const msgId of global.lastSentContactMsg[userId]) {
					await ctx.telegram.deleteMessage(ctx.chat.id, msgId).catch(() => {});
				}
				delete global.lastSentContactMsg[userId];

				let sent = await ctx.replyWithPhoto({
					source: global.media
				}, {
					caption,
					parse_mode: 'HTML',
					reply_markup: replyMarkup
				});
				
				global.lastMenuMsg = global.lastMenuMsg || {};
		        global.lastMenuMsg[userId] = sent.message_id;
				return;
			}

			let sent2 = await ctx.editMessageCaption(caption, {
				parse_mode: 'HTML',
				reply_markup: replyMarkup
			});
			
			global.lastMenuMsg = global.lastMenuMsg || {};
		    global.lastMenuMsg[userId] = sent2.message_id;
		    
			return;
		}
	}

	if (!arg && ['menu', 'start'].includes(command)) {
		const sent = await ctx.replyWithPhoto({
			source: global.media
		}, {
			caption,
			parse_mode: 'HTML',
			reply_markup: replyMarkup
		});
		
		global.lastMenuMsg = global.lastMenuMsg || {};
		global.lastMenuMsg[userId] = sent.message_id;
		return;
	}

};

handler.name = 'menu';
handler.type = 'telegram';
handler.trigger = ['text', 'callback_query'];
handler.tags = ['main'];
handler.command = ['menu', 'start'];

async function loadTelegramPluginsByTags(dirPath = path.join(__dirname, '../telegram')) {
	const files = await fs.readdir(dirPath);
	const commandGroups = {};

	await Promise.all(
		files.filter(f => f.endsWith('.js')).map(async file => {
			try {
				const pluginPath = path.join(dirPath, file);
				delete require.cache[require.resolve(pluginPath)];
				const plugin = require(pluginPath);
				if (!plugin || plugin.type !== 'telegram') return;

				const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
				const tags = Array.isArray(plugin.tags) ? plugin.tags : ['lainnya'];

				for (const tag of tags) {
					if (!commandGroups[tag]) commandGroups[tag] = [];
					for (const cmd of commands) {
						commandGroups[tag].push({
							command: cmd,
							file: file.replace('.js', '')
						});
					}
				}
			} catch {}
		})
	);

	return commandGroups;
}

function kapitalAwal(kalimat) {
	return kalimat.charAt(0).toUpperCase() + kalimat.slice(1).toLowerCase();
}

module.exports = handler;