let handler = async (ctx, arg, { config, command, userId }) => {
	const isTextOwner = ctx.updateType === 'message' &&
		['owner', 'creator'].includes(command);

	const isCallbackOwner = ctx.updateType === 'callback_query' &&
		arg === 'owner';

	if (isTextOwner || isCallbackOwner) {
		if (
			global.lastMenuMsg &&
			global.lastMenuMsg[userId]
		) {
			await ctx.telegram.deleteMessage(ctx.chat.id, global.lastMenuMsg[userId]).catch(() => {});
			delete global.lastMenuMsg[userId];
		}

		const sent = [];

		for (let i = 0; i < config.owner.length; i++) {
			const nomor = config.owner[i]?.replace(/[^0-9]/g, '');
			const nama = config.ownerName || `Owner ${i + 1}`;
			if (nomor) {
				const msg = await ctx.replyWithContact(nomor, nama, {
					reply_markup: {
						inline_keyboard: [[{ text: 'Back', callback_data: 'back_menu_contact' }]]
					}
				});
				sent.push(msg.message_id);
			}
		}

		global.lastSentContactMsg = global.lastSentContactMsg || {};
		global.lastSentContactMsg[userId] = sent;
	}
};

handler.name = 'owner';
handler.type = 'telegram';
handler.trigger = ['text', 'callback_query'];
handler.tags = ['main'];
handler.command = ['owner', 'creator'];

module.exports = handler;